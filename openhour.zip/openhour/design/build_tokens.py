#!/usr/bin/env python3
"""Generate tokens.css (custom properties) and tailwind-theme.css (Tailwind v4 @theme
mapping) from tokens.json. Run: python3 replica/design/build_tokens.py"""
import json, pathlib

here = pathlib.Path(__file__).parent
t = json.loads((here / "tokens.json").read_text())

css = ["/* Generated from tokens.json by build_tokens.py. Do not edit by hand. */", ":root {"]
for k, v in t["color"].items():
    css.append(f"  --color-{k}: {v};")
css.append(f"  --font-sans: {t['font']['sans']};")
css.append(f"  --font-mono: {t['font']['mono']};")
for k, v in t["type"].items():
    css.append(f"  --text-{k}: {v['size']}px;")
    css.append(f"  --text-{k}--line-height: {v['line']}px;")
    css.append(f"  --text-{k}--font-weight: {v['weight']};")
for i, v in enumerate(t["space"]):
    css.append(f"  --space-{i}: {v}px;")
for k, v in t["radius"].items():
    css.append(f"  --radius-{k}: {v}px;")
for k, v in t["shadow"].items():
    css.append(f"  --shadow-{k}: {v};")
for k, v in t["motion"].items():
    css.append(f"  --motion-{k}: {v};")
for k, v in t["layout"].items():
    if isinstance(v, dict):
        for kk, vv in v.items():
            css.append(f"  --bp-{kk}: {vv}px;")
    else:
        css.append(f"  --layout-{k}: {v}px;")
css.append("}")
(here / "tokens.css").write_text("\n".join(css) + "\n")

tw = ["/* Generated from tokens.json by build_tokens.py. Tailwind v4 theme mapping:",
      "   components use bg-surface, text-muted, border-input, never raw hex. */",
      "@theme {", "  --color-*: initial;"]
for k, v in t["color"].items():
    tw.append(f"  --color-{k}: {v};")
tw.append(f"  --font-sans: {t['font']['sans']};")
tw.append(f"  --font-mono: {t['font']['mono']};")
for k, v in t["type"].items():
    tw.append(f"  --text-{k}: {v['size']}px;")
    tw.append(f"  --text-{k}--line-height: {v['line']}px;")
    tw.append(f"  --text-{k}--font-weight: {v['weight']};")
for k, v in t["radius"].items():
    tw.append(f"  --radius-{k}: {v}px;")
for k, v in t["shadow"].items():
    tw.append(f"  --shadow-{k}: {v};")
tw.append(f"  --ease-brand: {t['motion']['ease']};")
tw.append("}")
(here / "tailwind-theme.css").write_text("\n".join(tw) + "\n")
print("wrote tokens.css, tailwind-theme.css")
