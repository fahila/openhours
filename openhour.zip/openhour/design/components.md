# Components

Source of truth for values: `tokens.json`. Regenerate CSS with `python3 replica/design/build_tokens.py`. Contrast gate: `python3 ~/.claude/skills/replica-design/contrast.py replica/design/tokens.json` (27 pairs, 0 AA failures).

No reference screenshots existed (see `recon.md`), so nothing here is measured from the original. Sizes and scales are standard defaults (4px spacing base, 12/14/16/20/28/40 type scale). When screenshots from the user's own account arrive, compare and adjust the tokens, not the components.

Built = implemented in `replica/app/components/ui` and shown at `/design`. Spec = written here, built when the first screen needs it.

All icons are Lucide (ISC licence). No Calendly logos, icons, copy or fonts are used. Font is Inter (open licence). The accent is a neutral placeholder teal, replaced by replica-brand.

## Button (built)

```
Button
  variants  primary, secondary, ghost, danger
  sizes     sm 32px, md 40px, lg 48px
  states    default, hover, active, focus-visible (2px ring, focus-ring), disabled (50%), loading
  tokens    primary: bg accent, hover accent-hover, text on-accent. secondary: border border-input.
            danger: bg danger. radius md. font sm/600 (lg: base)
  a11y      real <button>, type="button" by default, loading sets aria-busy and keeps the label
  used on   S01-S04, S09, S10, S13, S18, S33, S36
```

## Field, Input, Textarea, Select (built)

```
Field
  wraps     Input, Textarea, Select
  states    default, focus-visible, error (border danger + message), disabled, required
  tokens    border border-input (3.3:1 on bg), text text, placeholder text-muted, radius md, height 40px
  a11y      label bound by id, hint and error linked with aria-describedby, aria-invalid on error,
            error text has role="alert", required marks the control and shows a visible asterisk
  used on   S01, S04, S05, S17, S33, S36, S39
```
Select is the native element on purpose: type-to-search and mobile pickers work on every platform. Revisit only if a design needs something native cannot do.

## Month calendar (built)

```
MonthCalendar
  states    day: available, selected, today, unavailable (aria-disabled, focusable), other-month (blank)
            month: loading (aria-busy), no slots
  tokens    available: accent-subtle bg + accent text. selected: accent bg + on-accent. today: 1px ring border-input.
            unavailable: text-muted. day button 40px circle, grid 7 columns
  a11y      role grid; each day is a button with a full-date label ("Wednesday, November 4"),
            plus ", no times available" and ", today". aria-pressed on selected.
            Roving tabindex: arrows move 1 day / 1 week, Home to start of week, PageUp/PageDown change month,
            month heading is aria-live. Unavailable days stay focusable so arrow keys never lose focus.
  data      dates are "YYYY-MM-DD" strings in the viewer's zone, never instants
  used on   S31, S35, S11 (date overrides, later)
```

## Slot list (built)

```
SlotList
  states    available, selected, taken, 12h and 24h
  tokens    available: outline accent. selected: accent fill. taken: surface bg, text-muted, line-through
  a11y      list with an accessible name; buttons use aria-pressed; taken slots are disabled and carry
            a screen-reader-only "(no longer available)"
  data      takes UTC ISO instants and formats in the chosen zone with Intl.DateTimeFormat
  used on   S32, S35, S37
```

## Time zone select (built)

Native select fed by `Intl.supportedValuesOf("timeZone")`, always includes the current value, labelled "Time zone". Used on S31, S17.

## Event type card (built)

```
EventTypeCard
  states    active, off; one-on-one, group
  tokens    4px top border in event-N colour, dot in the same colour (decorative, aria-hidden), shadow card, radius lg
  a11y      article with an h3; kind and status are text, never colour alone
  used on   S03, S30
```
Event colours event-1..8 each meet 3:1 as UI parts on bg.

## Badge (built)

Tones neutral, accent, success, warning, danger. Always text. Used for booking and link status (S07, S10): Created, Viewed, Booked, Confirmed, Cancelled, Pending payment.

## Switch (built)

Radix Switch. States on, off, focus-visible, disabled. Needs a label via the `label` prop. Used on S03, S13, S14.

## Dialog (built)

Radix Dialog. Overlay text/40, panel bg with shadow pop, radius lg, max width 448px. Focus is trapped, Escape closes, focus returns to the trigger (verified in a browser). Title required, description optional. Used for cancel confirm, delete, workflow edits.

## Tabs (built)

Radix Tabs, underline style. Arrow keys move between tabs. Used on S10 (Upcoming / Past), S03.

## Empty state (built)

Dashed border, surface bg, title (lg), one-line body, one primary action. Every list screen needs one (S03, S07, S09, S10, S13, S16).

## Spec only

```
Toast
  variants  success, error
  states    entering, visible, leaving (reduced motion: no slide)
  tokens    bg text, text bg, radius md, shadow pop; 5s auto dismiss, error stays until dismissed
  a11y      role=status for success, role=alert for error, never the only place an error appears
  used on   host app
  build     with a Radix Toast or Sonner when S04 needs "Saved"

Data table
  variants  sortable, filterable
  states    loading (skeleton rows), empty (EmptyState), filled, row selected
  tokens    header surface, row border, 40px rows, text sm
  a11y      real <table>, th scope, sortable headers are buttons with aria-sort
  used on   S10, S18, S21

Menu / dropdown
  build with Radix DropdownMenu; used for row actions on S03 and S10

Drawer (booking details on S10)
  build as Dialog variant anchored right, 420px

Checkbox, radio group, question builder, workflow step builder, form route builder,
color picker, image upload, embed code block
  build when their screens (S05, S13, S15, S20, S40) come up
```

## Layout

Booking card max width 880px, host content max width 1120px, host sidebar 240px, header 56px. Breakpoints 640 / 768 / 1024. Tested at 1280 and 375 with no horizontal scroll.

## Motion

120ms for hover and toggles, 200ms for panels, one easing curve. `prefers-reduced-motion` collapses all durations to near zero (global rule in `globals.css`).
