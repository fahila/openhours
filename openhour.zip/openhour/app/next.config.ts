import path from "node:path";
import type { NextConfig } from "next";

const isProd = process.env.NODE_ENV === "production";

/** A subset of CSP that needs no per-request nonce: no framing, no plugins, forms only post to this site. */
const CSP = "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'";

const base = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Content-Security-Policy", value: CSP },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=(), usb=()" },
  ...(isProd ? [{ key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" }] : []),
];

/** Pages whose address is a secret (the guest's manage token): never leak it in a Referer header, never cache it. */
const privateLinks = [
  { key: "Referrer-Policy", value: "no-referrer" },
  { key: "Cache-Control", value: "no-store" },
  { key: "X-Robots-Tag", value: "noindex, nofollow" },
];

/** The host app and sign-in have nothing for a search engine. */
const notForSearch = [{ key: "X-Robots-Tag", value: "noindex, nofollow" }];

const config: NextConfig = {
  // design tokens live in ../design so replica-brand can edit them in one place
  turbopack: { root: path.join(__dirname, "..") },
  poweredByHeader: false,
  async headers() {
    return [
      { source: "/:path*", headers: base },
      ...["/m/:path*", "/booked/:path*", "/reschedule/:path*"].map((source) => ({ source, headers: privateLinks })),
      ...["/login", "/left", "/event-types/:path*", "/meetings/:path*", "/availability/:path*", "/integrations/:path*", "/settings/:path*", "/workflows/:path*", "/single-use-links/:path*"].map((source) => ({ source, headers: notForSearch })),
    ];
  },
};

export default config;
