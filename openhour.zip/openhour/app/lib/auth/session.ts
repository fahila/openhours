import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { newToken, sha256 } from "../crypto";
import { one, query } from "../db";
import { env } from "../env";
import type { User } from "../types";
import { mapUser, type UserRow } from "../data/rows";
import { isAllowedEmail } from "./allow";

const DAYS = 30;

/**
 * Session cookie settings. In production the name carries the __Host- prefix, which browsers only accept when the
 * cookie is Secure, has Path=/ and no Domain, so it cannot be set from a sibling subdomain.
 */
export function sessionCookie(isProd: boolean, maxAgeSec: number) {
  return {
    name: isProd ? "__Host-session" : "session",
    options: { httpOnly: true, secure: isProd, sameSite: "lax" as const, path: "/", maxAge: maxAgeSec },
  };
}
const name = () => sessionCookie(env().isProd, 0).name;
const cookieOptions = (maxAgeSec: number) => sessionCookie(env().isProd, maxAgeSec).options;

/** Create a session row and set the cookie. Only the token's hash is stored. */
export async function startSession(userId: string): Promise<void> {
  const token = newToken(32);
  const ua = (await headers()).get("user-agent")?.slice(0, 300) ?? null;
  await query("insert into sessions (user_id, token_hash, user_agent, expires_at) values ($1, $2, $3, now() + ($4 || ' days')::interval)", [userId, sha256(token), ua, String(DAYS)]);
  (await cookies()).set(name(), token, cookieOptions(DAYS * 86400));
}

/** The signed-in user, or null. Cached for the length of one request. */
export const getCurrentUser = cache(async (): Promise<User | null> => {
  const token = (await cookies()).get(name())?.value;
  if (!token) return null;
  const row = await one<UserRow & { session_id: string; seen: Date }>(
    `select u.id, u.email, u.name, u.slug, u.time_zone, u.welcome_message, s.id as session_id, s.last_seen_at as seen
       from sessions s join users u on u.id = s.user_id where s.token_hash = $1 and s.expires_at > now()`,
    [sha256(token)],
  );
  if (!row || !isAllowedEmail(row.email)) return null;
  // keep the "last used" time fresh without writing on every request
  if (Date.now() - row.seen.getTime() > 5 * 60_000) await query("update sessions set last_seen_at = now() where id = $1", [row.session_id]);
  return mapUser(row);
});

export async function requireUser(): Promise<User> {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  return u;
}

export async function endSession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(name())?.value;
  if (token) await query("delete from sessions where token_hash = $1", [sha256(token)]);
  jar.set(name(), "", { ...cookieOptions(0), maxAge: 0 });
}

export async function endAllSessions(userId: string): Promise<void> {
  await query("delete from sessions where user_id = $1", [userId]);
  (await cookies()).set(name(), "", { ...cookieOptions(0), maxAge: 0 });
}

export async function purgeExpiredSessions(): Promise<number> {
  return (await query("delete from sessions where expires_at < now() returning id")).length;
}
