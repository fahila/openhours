import { env, type Env } from "../env";

/** Signing in needs an address on the allow list; that is also checked on every request, so removing someone locks them out at once. */
export function isAllowedEmail(email: string, e: Pick<Env, "allowedEmails" | "devLoginEnabled"> = env()): boolean {
  return e.devLoginEnabled || e.allowedEmails.includes(email.trim().toLowerCase());
}
