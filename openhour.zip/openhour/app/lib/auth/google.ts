import { createHash, randomBytes } from "node:crypto";
import { decrypt, encrypt, safeEqual } from "../crypto";
import { env } from "../env";

/** Google OAuth, written against Google's public endpoints with the user's own client id and secret. */

const base = () => {
  const o = env().GOOGLE_OAUTH_BASE;
  return o
    ? { auth: `${o}/auth`, token: `${o}/token`, userinfo: `${o}/userinfo`, revoke: `${o}/revoke` }
    : {
        auth: "https://accounts.google.com/o/oauth2/v2/auth",
        token: "https://oauth2.googleapis.com/token",
        userinfo: "https://openidconnect.googleapis.com/v1/userinfo",
        revoke: "https://oauth2.googleapis.com/revoke",
      };
};

/** Sign in asks for as little as possible. */
export const LOGIN_SCOPES = ["openid", "email", "profile"];
/** Calendar: list calendars, read busy times, create and delete events. Nothing more. */
export const CALENDAR_SCOPES = [
  "https://www.googleapis.com/auth/calendar.calendarlist.readonly",
  "https://www.googleapis.com/auth/calendar.freebusy",
  "https://www.googleapis.com/auth/calendar.events",
];

export const redirectUri = (path: string) => `${env().APP_URL.replace(/\/$/, "")}${path}`;

export interface PendingOAuth {
  state: string;
  verifier: string;
  purpose: "login" | "calendar";
  userId?: string;
  exp: number;
}

/** The pending state lives in a short cookie, encrypted so it cannot be forged or read. */
export function newPending(purpose: PendingOAuth["purpose"], userId?: string): { pending: PendingOAuth; cookie: string; challenge: string } {
  const verifier = randomBytes(32).toString("base64url");
  const pending: PendingOAuth = { state: randomBytes(24).toString("base64url"), verifier, purpose, userId, exp: Date.now() + 10 * 60_000 };
  return {
    pending,
    cookie: encrypt(JSON.stringify(pending)).toString("base64url"),
    challenge: createHash("sha256").update(verifier).digest("base64url"),
  };
}

export function readPending(cookie: string | undefined, state: string | null, purpose: PendingOAuth["purpose"]): PendingOAuth | null {
  if (!cookie || !state) return null;
  try {
    const p = JSON.parse(decrypt(Buffer.from(cookie, "base64url"))) as PendingOAuth;
    if (p.exp < Date.now() || p.purpose !== purpose || !safeEqual(p.state, state)) return null;
    return p;
  } catch {
    return null;
  }
}

export function authUrl(opts: { scopes: string[]; redirect: string; state: string; challenge: string; offline?: boolean; loginHint?: string }): string {
  const e = env();
  const u = new URL(base().auth);
  u.searchParams.set("client_id", e.GOOGLE_CLIENT_ID!);
  u.searchParams.set("redirect_uri", opts.redirect);
  u.searchParams.set("response_type", "code");
  u.searchParams.set("scope", opts.scopes.join(" "));
  u.searchParams.set("state", opts.state);
  u.searchParams.set("code_challenge", opts.challenge);
  u.searchParams.set("code_challenge_method", "S256");
  if (opts.offline) {
    u.searchParams.set("access_type", "offline");
    u.searchParams.set("prompt", "consent");
  }
  if (opts.loginHint) u.searchParams.set("login_hint", opts.loginHint);
  return u.toString();
}

export interface TokenResponse {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
  scope?: string;
}

async function tokenCall(body: Record<string, string>): Promise<TokenResponse> {
  const e = env();
  const res = await fetch(base().token, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: e.GOOGLE_CLIENT_ID!, client_secret: e.GOOGLE_CLIENT_SECRET!, ...body }),
    signal: AbortSignal.timeout(10_000),
  });
  const json = (await res.json().catch(() => ({}))) as TokenResponse & { error?: string };
  if (!res.ok) {
    const err = new Error(`Google token endpoint: ${json.error ?? res.status}`) as Error & { code?: string };
    err.code = json.error;
    throw err;
  }
  return json;
}

export const exchangeCode = (code: string, verifier: string, redirect: string) =>
  tokenCall({ grant_type: "authorization_code", code, code_verifier: verifier, redirect_uri: redirect });

export const refreshAccessToken = (refreshToken: string) => tokenCall({ grant_type: "refresh_token", refresh_token: refreshToken });

export interface GoogleProfile {
  sub: string;
  email: string;
  email_verified: boolean;
  name?: string;
}

export async function fetchProfile(accessToken: string): Promise<GoogleProfile> {
  const res = await fetch(base().userinfo, { headers: { Authorization: `Bearer ${accessToken}` }, signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error(`Google userinfo: ${res.status}`);
  return (await res.json()) as GoogleProfile;
}

export async function revokeToken(token: string): Promise<void> {
  await fetch(base().revoke, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ token }), signal: AbortSignal.timeout(10_000) }).catch(() => {});
}
