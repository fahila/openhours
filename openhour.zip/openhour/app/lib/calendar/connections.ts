import { encrypt } from "../crypto";
import { isUuid, one, query, tx } from "../db";
import { NotFoundError } from "../data/errors";
import { revokeToken } from "../auth/google";
import { decrypt } from "../crypto";
import { forgetToken, listCalendars, withToken } from "./google";

export interface CalendarRow { id: string; name: string; checkConflicts: boolean; isBookingTarget: boolean; providerCalendarId: string }
export interface ConnectionView { id: string; provider: "google"; email: string; status: "active" | "needs_reauth" | "revoked"; calendars: CalendarRow[] }

export const REQUIRED_SCOPES = ["https://www.googleapis.com/auth/calendar.freebusy", "https://www.googleapis.com/auth/calendar.events", "https://www.googleapis.com/auth/calendar.calendarlist.readonly"];

/** Store (or refresh) a connection after the OAuth callback, then import the account's calendar list. */
export async function saveGoogleConnection(userId: string, input: { sub: string; email: string; refreshToken: string; scopes: string[] }): Promise<string> {
  const id = await tx(async (c) => {
    const r = await c.query<{ id: string }>(
      `insert into calendar_connections (user_id, provider, provider_account_id, email, refresh_token_enc, scopes, status)
       values ($1, 'google', $2, $3, $4, $5, 'active')
       on conflict (user_id, provider, provider_account_id)
       do update set refresh_token_enc = excluded.refresh_token_enc, scopes = excluded.scopes, email = excluded.email, status = 'active'
       returning id`,
      [userId, input.sub, input.email, encrypt(input.refreshToken), input.scopes],
    );
    return r.rows[0].id;
  });
  forgetToken(id);
  await syncCalendarList(userId, id);
  return id;
}

async function connectionRef(userId: string, id: string) {
  if (!isUuid(id)) throw new NotFoundError();
  const r = await one<{ id: string; refresh_token_enc: Buffer }>("select id, refresh_token_enc from calendar_connections where id = $1 and user_id = $2", [id, userId]);
  if (!r) throw new NotFoundError();
  return { id: r.id, refreshTokenEnc: r.refresh_token_enc };
}

/** Pull the calendar list from Google. New calendars start unchecked, except the primary one on a first connection. */
export async function syncCalendarList(userId: string, connectionId: string): Promise<void> {
  const ref = await connectionRef(userId, connectionId);
  const items = await withToken(ref, (token) => listCalendars(token));
  await tx(async (c) => {
    const hasTarget = (await c.query("select 1 from calendars cal join calendar_connections cc on cc.id = cal.connection_id where cc.user_id = $1 and cal.is_booking_target", [userId])).rowCount! > 0;
    let targetSet = hasTarget;
    for (const it of items) {
      const primary = Boolean(it.primary);
      const writable = it.accessRole === "owner" || it.accessRole === "writer";
      const isTarget = primary && writable && !targetSet;
      if (isTarget) targetSet = true;
      await c.query(
        `insert into calendars (connection_id, provider_calendar_id, name, check_conflicts, is_booking_target) values ($1, $2, $3, $4, $5)
         on conflict (connection_id, provider_calendar_id) do update set name = excluded.name`,
        [connectionId, it.id, it.summary, primary, isTarget],
      );
    }
    // calendars the account no longer lists
    await c.query("delete from calendars where connection_id = $1 and not (provider_calendar_id = any($2))", [connectionId, items.map((i) => i.id)]);
  });
}

export async function listConnections(userId: string): Promise<ConnectionView[]> {
  const conns = await query<{ id: string; email: string; status: ConnectionView["status"] }>("select id, email, status from calendar_connections where user_id = $1 order by created_at", [userId]);
  if (conns.length === 0) return [];
  const cals = await query<{ id: string; connection_id: string; name: string; check_conflicts: boolean; is_booking_target: boolean; provider_calendar_id: string }>(
    "select id, connection_id, name, check_conflicts, is_booking_target, provider_calendar_id from calendars where connection_id = any($1) order by name", [conns.map((c) => c.id)],
  );
  return conns.map((c) => ({
    id: c.id, provider: "google", email: c.email, status: c.status,
    calendars: cals.filter((x) => x.connection_id === c.id).map((x) => ({ id: x.id, name: x.name, checkConflicts: x.check_conflicts, isBookingTarget: x.is_booking_target, providerCalendarId: x.provider_calendar_id })),
  }));
}

/** At most one calendar per person receives new bookings. */
export async function setCalendarFlags(userId: string, calendarId: string, flags: { checkConflicts?: boolean; isBookingTarget?: boolean }): Promise<void> {
  if (!isUuid(calendarId)) throw new NotFoundError();
  await tx(async (c) => {
    const own = await c.query("select cal.id from calendars cal join calendar_connections cc on cc.id = cal.connection_id where cal.id = $1 and cc.user_id = $2 for update of cal", [calendarId, userId]);
    if (own.rowCount === 0) throw new NotFoundError();
    if (flags.checkConflicts !== undefined) await c.query("update calendars set check_conflicts = $2 where id = $1", [calendarId, flags.checkConflicts]);
    if (flags.isBookingTarget === true) {
      await c.query("update calendars set is_booking_target = false where connection_id in (select id from calendar_connections where user_id = $1)", [userId]);
      await c.query("update calendars set is_booking_target = true where id = $1", [calendarId]);
    } else if (flags.isBookingTarget === false) {
      await c.query("update calendars set is_booking_target = false where id = $1", [calendarId]);
    }
  });
}

export async function disconnect(userId: string, connectionId: string): Promise<void> {
  if (!isUuid(connectionId)) throw new NotFoundError();
  const r = await one<{ refresh_token_enc: Buffer }>("select refresh_token_enc from calendar_connections where id = $1 and user_id = $2", [connectionId, userId]);
  if (!r) throw new NotFoundError();
  try { await revokeToken(decrypt(r.refresh_token_enc)); } catch { /* the row goes either way */ }
  await query("delete from calendar_connections where id = $1 and user_id = $2", [connectionId, userId]);
  forgetToken(connectionId);
}

/** Account deletion: hand the tokens back to Google before the rows disappear. */
export async function revokeAllConnections(userId: string): Promise<void> {
  const rows = await query<{ id: string }>("select id from calendar_connections where user_id = $1", [userId]);
  for (const r of rows) await disconnect(userId, r.id);
}
