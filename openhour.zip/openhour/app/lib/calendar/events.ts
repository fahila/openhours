import { DateTime } from "luxon";
import { one } from "../db";
import { LOCATION_LABELS, type EventType, type User } from "../types";
import type { StoredBooking } from "../data/bookings";
import { CalendarAuthError, deleteEvent, getEvent, insertEvent, withToken } from "./google";
import { query } from "../db";

interface Target { calendar_id: string; connection_id: string; refresh_token_enc: Buffer; status: string }

async function bookingTarget(userId: string): Promise<Target | null> {
  return one<Target>(
    `select cal.provider_calendar_id as calendar_id, cc.id as connection_id, cc.refresh_token_enc, cc.status
       from calendars cal join calendar_connections cc on cc.id = cal.connection_id
      where cc.user_id = $1 and cal.is_booking_target limit 1`,
    [userId],
  );
}

/** Google event ids use [a-v0-9]. A uuid without dashes is 32 hex characters, which fits. */
export const eventIdFor = (bookingId: string) => bookingId.replace(/-/g, "");

/**
 * Put the meeting on the host's calendar. Returns null when no calendar is set up (nothing to do) or access was
 * revoked (nothing a retry can fix). Throws on a temporary failure so the job tries again.
 */
export async function ensureCalendarEvent(c: { booking: StoredBooking; eventType: EventType; host: User }): Promise<{ providerEventId: string; meetingUrl: string | null; calendarId: string } | null> {
  const target = await bookingTarget(c.host.id);
  if (!target) return null;
  try {
    if (target.status !== "active") throw new CalendarAuthError();
    const ref = { id: target.connection_id, refreshTokenEnc: target.refresh_token_enc };
    const meet = c.eventType.locationType === "google_meet";
    const guests = c.booking.invitees.map((i) => `${i.name} <${i.email}>`).join(", ");
    const notes = c.booking.invitees.map((i) => i.answers.notes).filter(Boolean).join("\n");
    const where = meet ? undefined : (c.eventType.locationValue ?? LOCATION_LABELS[c.eventType.locationType]);
    let ev = await withToken(ref, (token) => insertEvent(token, target.calendar_id, {
      id: eventIdFor(c.booking.id),
      summary: `${c.eventType.name}: ${c.booking.invitees.map((i) => i.name).join(", ")}`,
      description: [`Booked through your scheduling page.`, `Guest: ${guests}`, notes ? `Note: ${notes}` : ""].filter(Boolean).join("\n"),
      location: where,
      startIso: c.booking.startAt,
      endIso: c.booking.endAt,
      timeZone: DateTime.fromISO(c.booking.startAt, { zone: c.host.timeZone }).zoneName ?? c.host.timeZone,
      meet,
    }));
    // Google creates Meet links in the background. Give it a moment before giving up on the link.
    for (let i = 0; meet && !ev.hangoutLink && i < 3; i++) {
      await new Promise((r) => setTimeout(r, 700 * (i + 1)));
      ev = (await withToken(ref, (token) => getEvent(token, target.calendar_id, ev.id))) ?? ev;
    }
    await query("update bookings set provider_calendar_id = $2 where id = $1", [c.booking.id, target.calendar_id]);
    return { providerEventId: ev.id, meetingUrl: ev.hangoutLink ?? null, calendarId: target.calendar_id };
  } catch (e) {
    if (e instanceof CalendarAuthError) return null;
    throw e;
  }
}

/** Remove the event from the calendar it was written to. A missing event or revoked access is not an error. */
export async function deleteCalendarEvent(c: { booking: StoredBooking; host: User }): Promise<void> {
  if (!c.booking.providerEventId) return;
  const row = await one<{ provider_calendar_id: string | null }>("select provider_calendar_id from bookings where id = $1", [c.booking.id]);
  if (!row?.provider_calendar_id) return;
  const conn = await one<{ connection_id: string; refresh_token_enc: Buffer; status: string }>(
    `select cc.id as connection_id, cc.refresh_token_enc, cc.status from calendars cal join calendar_connections cc on cc.id = cal.connection_id
      where cc.user_id = $1 and cal.provider_calendar_id = $2 limit 1`,
    [c.host.id, row.provider_calendar_id],
  );
  if (!conn || conn.status !== "active") return;
  try {
    const eventId = c.booking.providerEventId;
    await withToken({ id: conn.connection_id, refreshTokenEnc: conn.refresh_token_enc }, (token) => deleteEvent(token, row.provider_calendar_id!, eventId));
  } catch (e) {
    if (e instanceof CalendarAuthError) return;
    throw e;
  }
}
