import { query } from "../db";
import { CalendarAuthError, freeBusy, withToken } from "./google";

interface Row { connection_id: string; refresh_token_enc: Buffer; status: string; provider_calendar_id: string }
export interface Busy { start: string; end: string }

// Short cache so one busy booking page does not hammer Google. A stale entry is allowed only as a fallback.
const cache = new Map<string, { at: number; busy: Busy[] }>();
const FRESH_MS = 60_000;
const STALE_OK_MS = 10 * 60_000;

/**
 * Busy intervals across every calendar the host checks for conflicts.
 *  fresh=true  (booking time): always asks Google, and any failure throws so the booking is refused rather than guessed.
 *  fresh=false (listing times): may use a recent cached answer, and falls back to one up to ten minutes old if Google fails.
 * With no calendar connected there is nothing to check and the answer is empty.
 */
export async function busyFor(userId: string, fromIso: string, toIso: string, opts: { fresh: boolean }): Promise<Busy[]> {
  const rows = await query<Row>(
    `select cc.id as connection_id, cc.refresh_token_enc, cc.status, cal.provider_calendar_id
       from calendars cal join calendar_connections cc on cc.id = cal.connection_id
      where cc.user_id = $1 and cal.check_conflicts`,
    [userId],
  );
  if (rows.length === 0) return [];

  const key = `${userId}|${fromIso.slice(0, 10)}|${toIso.slice(0, 10)}`;
  const hit = cache.get(key);
  if (!opts.fresh && hit && Date.now() - hit.at < FRESH_MS) return hit.busy;

  try {
    // a connection that needs re-authorising cannot be checked, so we must not pretend its calendars are free
    if (rows.some((r) => r.status !== "active")) throw new CalendarAuthError("A connected calendar needs to be reconnected");
    const byConn = new Map<string, Row[]>();
    for (const r of rows) byConn.set(r.connection_id, [...(byConn.get(r.connection_id) ?? []), r]);
    const parts = await Promise.all([...byConn.values()].map(async (group) => {
      const ids = group.map((g) => g.provider_calendar_id);
      return withToken({ id: group[0].connection_id, refreshTokenEnc: group[0].refresh_token_enc }, (token) => freeBusy(token, ids, fromIso, toIso));
    }));
    const busy = parts.flat();
    cache.set(key, { at: Date.now(), busy });
    if (cache.size > 500) for (const [k, v] of cache) if (Date.now() - v.at > STALE_OK_MS) cache.delete(k);
    return busy;
  } catch (e) {
    if (!opts.fresh && hit && Date.now() - hit.at < STALE_OK_MS) return hit.busy;
    throw e;
  }
}

export function clearBusyCache() {
  cache.clear();
}
