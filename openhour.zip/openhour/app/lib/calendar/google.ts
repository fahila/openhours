import { env } from "../env";
import { refreshAccessToken } from "../auth/google";
import { decrypt } from "../crypto";
import { query } from "../db";

/**
 * Google Calendar v3 over plain fetch, using the host's own OAuth client and their refresh token.
 * Only these calls are made: calendarList.list, freeBusy.query, events.insert, events.get, events.delete.
 */

export class CalendarAuthError extends Error {
  constructor(message = "Google calendar access was revoked or expired") { super(message); }
}
export class CalendarApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

const api = () => env().GOOGLE_API_BASE ?? "https://www.googleapis.com";
const TIMEOUT = 10_000;

// access tokens live about an hour; keep them in memory, never in the database
const tokenCache = new Map<string, { token: string; exp: number }>();

export interface ConnectionRef { id: string; refreshTokenEnc: Buffer }

export async function accessToken(conn: ConnectionRef): Promise<string> {
  const hit = tokenCache.get(conn.id);
  if (hit && hit.exp > Date.now() + 60_000) return hit.token;
  try {
    const t = await refreshAccessToken(decrypt(conn.refreshTokenEnc));
    tokenCache.set(conn.id, { token: t.access_token, exp: Date.now() + t.expires_in * 1000 });
    return t.access_token;
  } catch (e) {
    // invalid_grant means the person revoked access or the token expired: stop trying and say so
    if ((e as { code?: string }).code === "invalid_grant") {
      await query("update calendar_connections set status = 'needs_reauth' where id = $1", [conn.id]);
      tokenCache.delete(conn.id);
      throw new CalendarAuthError();
    }
    throw e;
  }
}

/**
 * Run a Google call with a token for this connection. If Google answers 401 the cached access token is no longer
 * good (revoked, or expired early), so drop it and try once more with a fresh one. If the refresh token has been
 * revoked too, that second step raises invalid_grant, which marks the connection "needs reconnecting" at once
 * instead of leaving guests failing until the cached token would have expired.
 */
export async function withToken<T>(conn: ConnectionRef, fn: (token: string) => Promise<T>): Promise<T> {
  try {
    return await fn(await accessToken(conn));
  } catch (e) {
    if (!(e instanceof CalendarAuthError)) throw e;
    tokenCache.delete(conn.id);
    try {
      return await fn(await accessToken(conn));
    } catch (e2) {
      if (e2 instanceof CalendarAuthError) await query("update calendar_connections set status = 'needs_reauth' where id = $1", [conn.id]);
      throw e2;
    }
  }
}

export function forgetToken(connectionId: string) {
  tokenCache.delete(connectionId);
}

async function call<T>(token: string, method: string, path: string, body?: unknown, okStatuses: number[] = []): Promise<{ status: number; json: T }> {
  const res = await fetch(`${api()}${path}`, {
    method,
    headers: { Authorization: `Bearer ${token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(TIMEOUT),
  });
  const text = await res.text();
  const json = (text ? JSON.parse(text) : {}) as T & { error?: { message?: string } };
  if (res.status === 401) throw new CalendarAuthError("Google rejected the access token");
  if (!res.ok && !okStatuses.includes(res.status)) throw new CalendarApiError(res.status, `Google Calendar ${method} ${path.split("?")[0]}: ${res.status} ${json.error?.message ?? ""}`.trim());
  return { status: res.status, json };
}

export interface GoogleCalendar { id: string; summary: string; primary?: boolean; accessRole: string }

export async function listCalendars(token: string): Promise<GoogleCalendar[]> {
  const { json } = await call<{ items?: GoogleCalendar[] }>(token, "GET", "/calendar/v3/users/me/calendarList?minAccessRole=reader&maxResults=250");
  return json.items ?? [];
}

export async function freeBusy(token: string, calendarIds: string[], timeMin: string, timeMax: string): Promise<{ start: string; end: string }[]> {
  const { json } = await call<{ calendars?: Record<string, { busy?: { start: string; end: string }[]; errors?: { reason: string }[] }> }>(
    token, "POST", "/calendar/v3/freeBusy", { timeMin, timeMax, items: calendarIds.map((id) => ({ id })) },
  );
  const out: { start: string; end: string }[] = [];
  for (const id of calendarIds) {
    const c = json.calendars?.[id];
    // a calendar we cannot read must not be treated as empty
    if (!c || c.errors?.length) throw new CalendarApiError(502, `Google could not read calendar ${id}: ${c?.errors?.map((e) => e.reason).join(",") ?? "missing"}`);
    out.push(...(c.busy ?? []));
  }
  return out;
}

export interface NewEvent {
  id: string;
  summary: string;
  description: string;
  location?: string;
  startIso: string;
  endIso: string;
  timeZone: string;
  meet: boolean;
}
export interface CreatedEvent { id: string; hangoutLink?: string }

/** The event id is chosen by us (derived from the booking), so a retry cannot create a second event. */
export async function insertEvent(token: string, calendarId: string, e: NewEvent): Promise<CreatedEvent> {
  const path = `/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events?conferenceDataVersion=${e.meet ? 1 : 0}&sendUpdates=none`;
  const body = {
    id: e.id,
    summary: e.summary,
    description: e.description,
    location: e.location,
    start: { dateTime: e.startIso, timeZone: e.timeZone },
    end: { dateTime: e.endIso, timeZone: e.timeZone },
    reminders: { useDefault: true },
    ...(e.meet ? { conferenceData: { createRequest: { requestId: e.id, conferenceSolutionKey: { type: "hangoutsMeet" } } } } : {}),
  };
  const r = await call<CreatedEvent>(token, "POST", path, body, [409]);
  if (r.status === 409) return (await call<CreatedEvent>(token, "GET", `/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events/${e.id}`)).json;
  return r.json;
}

export async function getEvent(token: string, calendarId: string, eventId: string): Promise<CreatedEvent | null> {
  const r = await call<CreatedEvent>(token, "GET", `/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events/${eventId}`, undefined, [404, 410]);
  return r.status === 404 || r.status === 410 ? null : r.json;
}

/** Gone already counts as deleted. */
export async function deleteEvent(token: string, calendarId: string, eventId: string): Promise<void> {
  await call(token, "DELETE", `/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events/${eventId}?sendUpdates=none`, undefined, [404, 410]);
}
