import { query } from "./db";

/**
 * Sliding window counter kept in Postgres. Returns true when `key` has already been used `limit` times in the last
 * `windowMs`; the attempt is recorded either way, so hammering the endpoint keeps you blocked.
 *
 * Keys that need to be hard to dodge (per email address, per host) are used next to the per-IP key, because an IP
 * is easy to change. `clientKey` trusts the first X-Forwarded-For value, so run behind a proxy that sets it
 * (Vercel, Cloudflare, nginx with proxy_set_header) and never expose the app directly to the internet.
 */
export async function rateLimited(key: string, limit: number, windowMs: number): Promise<boolean> {
  const rows = await query<{ n: number }>(
    `with ins as (insert into rate_limit_hits (key) values ($1))
     select count(*)::int as n from rate_limit_hits where key = $1 and at > now() - ($2 || ' milliseconds')::interval`,
    [key, String(windowMs)],
  );
  return rows[0].n >= limit;
}

export const clientKey = (req: Request) => (req.headers.get("x-forwarded-for") ?? "local").split(",")[0].trim().slice(0, 64);

export async function purgeRateLimits(): Promise<void> {
  await query("delete from rate_limit_hits where at < now() - interval '2 hours'");
}
