import { one, query, type Q, pool } from "../db";

export type JobKind = "booking.confirmed" | "booking.cancelled" | "workflow.send" | "payment.expire" | "payment.refund" | "cleanup";

export interface Job {
  id: string;
  kind: JobKind;
  payload: Record<string, unknown>;
  attempts: number;
  maxAttempts: number;
}

/**
 * Add a job. Pass the open transaction client so the job commits or rolls back with the change that needs it.
 * A dedupeKey makes enqueueing twice harmless.
 */
export async function enqueue(c: Q, kind: JobKind, payload: Record<string, unknown>, opts: { runAt?: Date; dedupeKey?: string } = {}) {
  await c.query(
    "insert into jobs (kind, payload, run_at, dedupe_key) values ($1, $2, $3, $4) on conflict (dedupe_key) do nothing",
    [kind, JSON.stringify(payload), opts.runAt ?? new Date(), opts.dedupeKey ?? null],
  );
}

/** Claim up to `limit` due jobs. SKIP LOCKED lets several workers run side by side without sharing a job. */
export async function claimDue(limit = 20): Promise<Job[]> {
  const rows = await query<{ id: string; kind: JobKind; payload: Record<string, unknown>; attempts: number; max_attempts: number }>(
    `update jobs set status = 'running', locked_at = now(), attempts = attempts + 1
       where id in (select id from jobs where status = 'queued' and run_at <= now() order by run_at limit $1 for update skip locked)
     returning id, kind, payload, attempts, max_attempts`,
    [limit],
  );
  return rows.map((r) => ({ id: r.id, kind: r.kind, payload: r.payload, attempts: r.attempts, maxAttempts: r.max_attempts }));
}

export async function complete(id: string) {
  await query("update jobs set status = 'done', finished_at = now(), locked_at = null, last_error = null where id = $1", [id]);
}

/** Retry with growing delay (1m, 5m, 25m, 2h, 10h), then move to the dead-letter state. */
export async function fail(job: Job, error: unknown) {
  const msg = (error instanceof Error ? error.message : String(error)).slice(0, 2000);
  if (job.attempts >= job.maxAttempts) {
    await query("update jobs set status = 'dead', finished_at = now(), locked_at = null, last_error = $2 where id = $1", [job.id, msg]);
    return "dead" as const;
  }
  const delayMin = 5 ** (job.attempts - 1);
  await query("update jobs set status = 'queued', locked_at = null, last_error = $2, run_at = now() + ($3 || ' minutes')::interval where id = $1", [job.id, msg, String(delayMin)]);
  return "retry" as const;
}

/** A worker that died mid job leaves it 'running'. Put those back after the timeout. */
export async function requeueStuck(olderThanMin = 10) {
  const rows = await query("update jobs set status = 'queued', locked_at = null where status = 'running' and locked_at < now() - ($1 || ' minutes')::interval returning id", [String(olderThanMin)]);
  return rows.length;
}

export async function deadJobs(limit = 50) {
  return query("select id, kind, payload, attempts, last_error, finished_at from jobs where status = 'dead' order by finished_at desc limit $1", [limit]);
}

export async function queueDepth() {
  return one<{ queued: string; dead: string }>("select count(*) filter (where status = 'queued') as queued, count(*) filter (where status = 'dead') as dead from jobs");
}

export { pool };
