import { claimDue, complete, enqueue, fail, requeueStuck } from "./queue";
import { handlers } from "./handlers";
import { pool } from "../db";

export interface RunStats { ran: number; failed: number; dead: number; stuck: number }

/**
 * Run due jobs until none are left or the time budget is spent. Safe to call from anywhere, any number of times:
 * rows are claimed with SKIP LOCKED, so two callers never run the same job.
 */
export async function runDueJobs(budgetMs = 25_000): Promise<RunStats> {
  const stats: RunStats = { ran: 0, failed: 0, dead: 0, stuck: await requeueStuck() };
  const deadline = Date.now() + budgetMs;
  // one cleanup per day, enqueued by whoever runs first
  await enqueue(pool(), "cleanup", {}, { dedupeKey: `cleanup:${new Date().toISOString().slice(0, 10)}` });
  while (Date.now() < deadline) {
    const batch = await claimDue(20);
    if (batch.length === 0) break;
    for (const job of batch) {
      const h = handlers[job.kind];
      try {
        if (!h) throw new Error(`No handler for job kind "${job.kind}"`);
        await h(job);
        await complete(job.id);
        stats.ran++;
      } catch (e) {
        stats.failed++;
        const outcome = await fail(job, e);
        if (outcome === "dead") {
          stats.dead++;
          // one structured line per dead job, so a log search finds them
          console.error(JSON.stringify({ level: "error", msg: "job dead", id: job.id, kind: job.kind, attempts: job.attempts, error: e instanceof Error ? e.message : String(e) }));
        }
      }
    }
  }
  return stats;
}
