import { ensureCalendarEvent, deleteCalendarEvent } from "../calendar/events";
import { calendarIdentity, getBookingContext, getInviteeToken, setBookingMeeting } from "../data/bookings";
import { one, pool, query } from "../db";
import { env } from "../env";
import { sendOnce } from "../email/send";
import { cancellationToGuest, cancellationToHost, confirmationToGuest, confirmationToHost, workflowEmail, type Ctx } from "../email/templates";
import { purgeExpiredSessions } from "../auth/session";
import { purgeRateLimits } from "../rate-limit";
import { enqueue, type Job } from "./queue";
import { expireUnpaidBooking, refundPayment } from "../payments/stripe";

type Handler = (job: Job) => Promise<void>;

interface WorkflowRow { id: string; trigger: "on_booked" | "on_cancelled" | "before_event" | "after_event"; offset_min: number; channel: string; subject: string | null; body: string; include_manage_links: boolean }

/** Workflows with no event types listed apply to every event type; otherwise only to the listed ones. */
async function workflowsFor(hostId: string, eventTypeId: string): Promise<WorkflowRow[]> {
  return query<WorkflowRow>(
    `select w.id, w.trigger, w.offset_min, w.channel, w.subject, w.body, w.include_manage_links from workflows w
      where w.user_id = $1 and w.active
        and (not exists (select 1 from workflow_event_types x where x.workflow_id = w.id)
             or exists (select 1 from workflow_event_types x where x.workflow_id = w.id and x.event_type_id = $2))`,
    [hostId, eventTypeId],
  );
}

const ctxFrom = async (c: { booking: Ctx["booking"]; eventType: Ctx["eventType"]; host: Ctx["host"] }): Promise<Ctx> => ({ ...c, cal: await calendarIdentity(c.booking.id), appUrl: env().APP_URL.replace(/\/$/, "") });

const bookingConfirmed: Handler = async (job) => {
  const { bookingId, inviteeEmail, rescheduledFrom } = job.payload as { bookingId: string; inviteeEmail: string; rescheduledFrom?: string };
  let base = await getBookingContext(bookingId);
  if (!base || base.booking.status === "cancelled") return;

  // Put the meeting on the host's calendar once per booking. Retrying is safe: the event id is derived from the booking.
  if (!base.booking.providerEventId) {
    try {
      const ev = await ensureCalendarEvent(base);
      if (ev) {
        await setBookingMeeting(bookingId, ev.providerEventId, ev.meetingUrl);
        base = (await getBookingContext(bookingId))!;
      }
    } catch (e) {
      // A Google hiccup should delay the email (the Meet link is in it), not lose it. On the last attempt send anyway.
      if (job.attempts < job.maxAttempts) throw e;
      console.error(JSON.stringify({ level: "error", msg: "calendar event not created; sending confirmation without it", bookingId, error: e instanceof Error ? e.message : String(e) }));
    }
  }
  const ctx = await ctxFrom(base);
  const invitee = ctx.booking.invitees.find((i) => i.email === inviteeEmail);
  if (!invitee) return;

  const token = await getInviteeToken(invitee.id);
  await sendOnce({ bookingId, inviteeId: invitee.id, workflowId: null, kind: `confirmation:guest:${invitee.email}` }, invitee.email, confirmationToGuest(ctx, invitee, token, Boolean(rescheduledFrom)), ctx.host.email);
  await sendOnce({ bookingId, inviteeId: invitee.id, workflowId: null, kind: `confirmation:host:${invitee.email}` }, ctx.host.email, confirmationToHost(ctx, invitee, Boolean(rescheduledFrom)));

  const start = Date.parse(ctx.booking.startAt);
  const end = Date.parse(ctx.booking.endAt);
  for (const wf of await workflowsFor(ctx.host.id, ctx.eventType.id)) {
    if (wf.channel !== "email") continue; // SMS needs a provider and consent handling; not built
    if (wf.trigger === "on_booked") {
      await sendOnce({ bookingId, inviteeId: invitee.id, workflowId: wf.id, kind: "workflow" }, invitee.email, workflowEmail(ctx, invitee, token, { subject: wf.subject, body: wf.body, includeManageLinks: wf.include_manage_links }), ctx.host.email);
    } else if (wf.trigger === "before_event" || wf.trigger === "after_event") {
      const at = wf.trigger === "before_event" ? start - wf.offset_min * 60_000 : end + wf.offset_min * 60_000;
      if (at <= Date.now()) continue;
      await enqueue(pool(), "workflow.send", { bookingId, inviteeId: invitee.id, workflowId: wf.id }, { runAt: new Date(at), dedupeKey: `workflow.send:${wf.id}:${invitee.id}` });
    }
  }
};

const bookingCancelled: Handler = async (job) => {
  const p = job.payload as { bookingId: string; by: "guest" | "host"; reason: string | null; invitees: { name: string; email: string; timeZone: string }[]; rescheduled?: boolean; partial?: boolean };
  const base = await getBookingContext(p.bookingId);
  if (!base) return;
  const ctx = await ctxFrom(base);
  // The meeting leaves the host's calendar only when the whole booking is gone, not when one guest leaves a group.
  if (!p.partial) {
    await deleteCalendarEvent(base);
    // reminders for a meeting that no longer exists would only be skipped later; clear them out now
    await query("update jobs set status = 'done', finished_at = now() where kind = 'workflow.send' and status = 'queued' and payload->>'bookingId' = $1", [p.bookingId]);
  }
  if (p.rescheduled) return; // the new booking's confirmation covers this; no cancellation notice
  for (const who of p.invitees) {
    await sendOnce({ bookingId: p.bookingId, inviteeId: null, workflowId: null, kind: `cancellation:guest:${who.email}` }, who.email, cancellationToGuest(ctx, who, p.by, p.reason), ctx.host.email);
    await sendOnce({ bookingId: p.bookingId, inviteeId: null, workflowId: null, kind: `cancellation:host:${who.email}` }, ctx.host.email, cancellationToHost(ctx, who, p.reason));
  }
  for (const wf of await workflowsFor(ctx.host.id, ctx.eventType.id)) {
    if (wf.trigger !== "on_cancelled" || wf.channel !== "email") continue;
    for (const who of p.invitees) {
      const invitee = { id: "gone", name: who.name, email: who.email, timeZone: who.timeZone, answers: {}, manageTokenHash: "", noShow: false };
      await sendOnce({ bookingId: p.bookingId, inviteeId: null, workflowId: wf.id, kind: `workflow:${who.email}` }, who.email, workflowEmail(ctx, invitee, null, { subject: wf.subject, body: wf.body, includeManageLinks: false }), ctx.host.email);
    }
  }
};

const workflowSend: Handler = async (job) => {
  const { bookingId, inviteeId, workflowId } = job.payload as { bookingId: string; inviteeId: string; workflowId: string };
  const base = await getBookingContext(bookingId);
  if (!base || base.booking.status !== "confirmed") return; // cancelled or still unpaid: do not remind
  const ctx = await ctxFrom(base);
  const invitee = ctx.booking.invitees.find((i) => i.id === inviteeId);
  if (!invitee) return; // the guest left a group booking
  const wf = await one<WorkflowRow & { active: boolean }>("select id, trigger, offset_min, channel, subject, body, include_manage_links, active from workflows where id = $1", [workflowId]);
  if (!wf || !wf.active) return;
  const token = await getInviteeToken(invitee.id);
  await sendOnce({ bookingId, inviteeId, workflowId, kind: "workflow" }, invitee.email, workflowEmail(ctx, invitee, token, { subject: wf.subject, body: wf.body, includeManageLinks: wf.include_manage_links }), ctx.host.email);
};

const paymentExpire: Handler = async (job) => {
  await expireUnpaidBooking((job.payload as { bookingId: string }).bookingId);
};

const paymentRefund: Handler = async (job) => {
  await refundPayment((job.payload as { paymentId: string }).paymentId);
};

const cleanup: Handler = async () => {
  await purgeExpiredSessions();
  await purgeRateLimits();
  await query("delete from jobs where status = 'done' and finished_at < now() - interval '30 days'");
  await query("delete from inbound_events where received_at < now() - interval '60 days'");
};

export const handlers: Record<string, Handler> = {
  "booking.confirmed": bookingConfirmed,
  "booking.cancelled": bookingCancelled,
  "workflow.send": workflowSend,
  "payment.expire": paymentExpire,
  "payment.refund": paymentRefund,
  cleanup,
};
