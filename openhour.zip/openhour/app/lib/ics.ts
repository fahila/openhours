import { BRAND } from "./brand";
import type { EventType, Invitee, User } from "./types";
import { LOCATION_LABELS } from "./types";

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const stamp = (iso: string) => new Date(iso).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
/** Lines over 75 octets are folded onto continuation lines, as RFC 5545 requires. */
const fold = (line: string) => {
  const out: string[] = [];
  let rest = line;
  while (Buffer.byteLength(rest) > 75) {
    let cut = 75;
    while (Buffer.byteLength(rest.slice(0, cut)) > 75) cut--;
    out.push(rest.slice(0, cut));
    rest = " " + rest.slice(cut);
  }
  out.push(rest);
  return out.join("\r\n");
};

export interface IcsInput {
  /** the calendar event's identity: the first booking in a chain of moves */
  uid: string;
  startAt: string;
  endAt: string;
  createdAt: string;
  eventType: Pick<EventType, "name" | "locationType" | "locationValue">;
  host: Pick<User, "name" | "email">;
  invitee?: Pick<Invitee, "name" | "email">;
  meetingUrl?: string | null;
  method?: "REQUEST" | "CANCEL" | "PUBLISH";
  /** raise it every time the meeting changes so calendar apps replace the old copy */
  sequence?: number;
}

export function buildIcs(i: IcsInput): string {
  const where = i.eventType.locationValue || LOCATION_LABELS[i.eventType.locationType];
  const method = i.method ?? "PUBLISH";
  const lines = [
    "BEGIN:VCALENDAR", "VERSION:2.0", `PRODID:-//${BRAND.name}//EN`, "CALSCALE:GREGORIAN", `METHOD:${method}`,
    "BEGIN:VEVENT",
    `UID:${i.uid}@${BRAND.icsDomain}`,
    `DTSTAMP:${stamp(i.createdAt)}`,
    `SEQUENCE:${i.sequence ?? 0}`,
    `DTSTART:${stamp(i.startAt)}`,
    `DTEND:${stamp(i.endAt)}`,
    `SUMMARY:${esc(`${i.eventType.name} with ${i.host.name}`)}`,
    `LOCATION:${esc(i.meetingUrl || where)}`,
    `ORGANIZER;CN=${esc(i.host.name)}:mailto:${i.host.email}`,
  ];
  if (i.invitee) lines.push(`ATTENDEE;CN=${esc(i.invitee.name)};RSVP=FALSE:mailto:${i.invitee.email}`);
  if (i.meetingUrl) lines.push(`DESCRIPTION:${esc(`Join: ${i.meetingUrl}`)}`);
  lines.push(`STATUS:${method === "CANCEL" ? "CANCELLED" : "CONFIRMED"}`, "END:VEVENT", "END:VCALENDAR");
  return lines.map(fold).join("\r\n") + "\r\n";
}
