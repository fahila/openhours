import { DateTime } from "luxon";

export const fmtDay = (iso: string, zone: string) => DateTime.fromISO(iso, { zone }).toFormat("cccc, LLLL d, yyyy");
export const fmtTime = (iso: string, zone: string) => DateTime.fromISO(iso, { zone }).toFormat("h:mm a");
export const fmtRange = (startIso: string, endIso: string, zone: string) => `${fmtTime(startIso, zone)} to ${fmtTime(endIso, zone)}`;
export const money = (cents: number, currency: string) => new Intl.NumberFormat("en", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100);
export const zoneLabel = (zone: string) => zone.replaceAll("_", " ");
