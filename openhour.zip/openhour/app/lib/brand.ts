/**
 * The one place the product's name lives. It is a working name: the trademark, domain and handle checks in
 * replica/brand.md have not been run yet, so changing it later means editing this file and nothing else.
 */
export const BRAND = {
  name: "Openhour",
  /** used in calendar invite identifiers and the package name */
  slug: "openhour",
  icsDomain: "openhour.local",
} as const;
