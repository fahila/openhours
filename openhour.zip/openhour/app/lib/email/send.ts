import { one, query } from "../db";
import { transport, type Email } from "./transport";
import type { Built } from "./templates";

export interface MessageKey {
  bookingId: string;
  /** null for messages to the host or to a guest who is no longer on the booking */
  inviteeId: string | null;
  workflowId: string | null;
  /** names the message and its recipient, e.g. "confirmation:guest:ann@example.com" */
  kind: string;
}

/**
 * Send at most once per key. The row in message_log is the lock: a retried job finds it already 'sent' and does
 * nothing, and the row id doubles as the provider's idempotency key if a retry fires after a timeout.
 */
export async function sendOnce(key: MessageKey, to: string, built: Built, replyTo?: string): Promise<"sent" | "skipped"> {
  const row = await one<{ id: string; status: string }>(
    `insert into message_log (booking_id, invitee_id, workflow_id, kind, channel) values ($1, $2, $3, $4, 'email')
       on conflict (booking_id, invitee_id, workflow_id, kind) do update set kind = message_log.kind
     returning id, status`,
    [key.bookingId, key.inviteeId, key.workflowId, key.kind],
  );
  if (row!.status === "sent") return "skipped";
  const email: Email = { to, subject: built.subject, html: built.html, text: built.text, attachments: built.attachments, replyTo, idempotencyKey: row!.id };
  try {
    const r = await transport().send(email);
    await query("update message_log set status = 'sent', provider_message_id = $2, sent_at = now(), error = null where id = $1", [row!.id, r.id]);
    return "sent";
  } catch (e) {
    await query("update message_log set status = 'failed', error = $2 where id = $1", [row!.id, (e instanceof Error ? e.message : String(e)).slice(0, 1000)]);
    throw e;
  }
}
