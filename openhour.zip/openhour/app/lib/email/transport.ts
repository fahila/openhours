import { env } from "../env";

export interface Email {
  to: string;
  subject: string;
  html: string;
  text: string;
  replyTo?: string;
  attachments?: { filename: string; content: string; contentType: string }[];
  /** the same key twice sends once, even if our retry fires after a timeout */
  idempotencyKey?: string;
}

export interface Transport {
  send(e: Email): Promise<{ id: string }>;
}

class ResendTransport implements Transport {
  async send(e: Email) {
    const cfg = env();
    const res = await fetch(`${cfg.RESEND_API_BASE ?? "https://api.resend.com"}/emails`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${cfg.RESEND_API_KEY}`,
        "Content-Type": "application/json",
        ...(e.idempotencyKey ? { "Idempotency-Key": e.idempotencyKey } : {}),
      },
      body: JSON.stringify({
        from: cfg.EMAIL_FROM,
        to: [e.to],
        subject: e.subject,
        html: e.html,
        text: e.text,
        reply_to: e.replyTo,
        attachments: e.attachments?.map((a) => ({ filename: a.filename, content: a.content, content_type: a.contentType })),
      }),
      signal: AbortSignal.timeout(15_000),
    });
    const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!res.ok || !body.id) throw new Error(`Resend ${res.status}: ${body.message ?? "no id returned"}`);
    return { id: body.id };
  }
}

/** Development without a Resend key: prints the email subject and recipient, never the body (it holds private links). */
class LogTransport implements Transport {
  async send(e: Email) {
    console.log(`[email:dev] to=${e.to} subject="${e.subject}"`);
    return { id: "dev-" + Date.now() };
  }
}

let override: Transport | null = null;
/** Tests install their own transport. */
export function setTransport(t: Transport | null) {
  override = t;
}

export function transport(): Transport {
  if (override) return override;
  const cfg = env();
  if (cfg.RESEND_API_KEY && cfg.EMAIL_FROM) return new ResendTransport();
  if (cfg.isProd) throw new Error("RESEND_API_KEY and EMAIL_FROM are required in production");
  return new LogTransport();
}
