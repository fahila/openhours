import { DateTime } from "luxon";
import { buildIcs } from "../ics";
import { LOCATION_LABELS, type EventType, type Invitee, type User } from "../types";
import type { StoredBooking } from "../data/bookings";

/** Every string below is written for this app. Nothing is copied from another product's emails. */

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export interface Ctx {
  /** calendar identity of this meeting across moves (see calendarIdentity) */
  cal: { uid: string; sequence: number };
  booking: StoredBooking;
  eventType: EventType;
  host: User;
  appUrl: string;
}

const when = (iso: string, zone: string) => DateTime.fromISO(iso, { zone }).toFormat("cccc, LLLL d, yyyy 'at' h:mm a ZZZZ");
const whereText = (c: Ctx) => c.booking.meetingUrl ?? (c.eventType.locationValue || LOCATION_LABELS[c.eventType.locationType]);

function layout(title: string, lines: string[], button?: { label: string; url: string }, footer?: string): { html: string; text: string } {
  const body = lines.map((l) => `<p style="margin:0 0 12px;font-size:15px;line-height:22px;color:#14171c">${l}</p>`).join("");
  const btn = button
    ? `<p style="margin:20px 0"><a href="${esc(button.url)}" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:600;padding:10px 18px;border-radius:8px">${esc(button.label)}</a></p>`
    : "";
  const html = `<!doctype html><html><body style="margin:0;background:#f6f7f9;padding:24px;font-family:Inter,Segoe UI,Arial,sans-serif"><div style="max-width:520px;margin:0 auto;background:#ffffff;border-radius:12px;padding:28px"><h1 style="margin:0 0 16px;font-size:20px;color:#14171c">${esc(title)}</h1>${body}${btn}${footer ? `<p style="margin:20px 0 0;font-size:12px;color:#5b6470">${footer}</p>` : ""}</div></body></html>`;
  const strip = (s: string) => s.replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"');
  const text = [title, "", ...lines.map(strip), ...(button ? ["", `${button.label}: ${button.url}`] : []), ...(footer ? ["", strip(footer)] : [])].join("\n");
  return { html, text };
}

export interface Built {
  subject: string;
  html: string;
  text: string;
  attachments?: { filename: string; content: string; contentType: string }[];
}

const ics = (c: Ctx, invitee: Invitee, method: "REQUEST" | "CANCEL") => [{
  filename: "meeting.ics",
  contentType: `text/calendar; method=${method}`,
  content: Buffer.from(buildIcs({
    uid: c.cal.uid, startAt: c.booking.startAt, endAt: c.booking.endAt, createdAt: c.booking.createdAt, eventType: c.eventType,
    host: c.host, invitee, meetingUrl: c.booking.meetingUrl, method, sequence: method === "CANCEL" ? c.cal.sequence + 1 : c.cal.sequence,
  })).toString("base64"),
}];

export function confirmationToGuest(c: Ctx, invitee: Invitee, token: string | null, moved: boolean): Built {
  const manage = token ? `${c.appUrl}/m/${token}` : null;
  const subject = moved ? `Moved: ${c.eventType.name} with ${c.host.name}` : `Confirmed: ${c.eventType.name} with ${c.host.name}`;
  const { html, text } = layout(
    moved ? "Your meeting has moved" : "You're booked",
    [
      `Hi ${esc(invitee.name)}, ${moved ? "your meeting with" : "you have a meeting with"} ${esc(c.host.name)} ${moved ? "is now" : "is"} set.`,
      `<strong>${esc(c.eventType.name)}</strong><br>${esc(when(c.booking.startAt, invitee.timeZone))}<br>${esc(whereText(c))}`,
      ...(c.eventType.confirmationMessage ? [esc(c.eventType.confirmationMessage).replace(/\n/g, "<br>")] : []),
      "The calendar invite is attached.",
    ],
    manage ? { label: "Change or cancel", url: manage } : undefined,
    manage ? "Anyone with this link can change or cancel the meeting, so keep it private." : undefined,
  );
  return { subject, html, text, attachments: ics(c, invitee, "REQUEST") };
}

export function confirmationToHost(c: Ctx, invitee: Invitee, moved: boolean): Built {
  const zone = c.host.timeZone;
  const { html, text } = layout(
    moved ? "A meeting was moved" : "New booking",
    [
      `${esc(invitee.name)} (${esc(invitee.email)}) ${moved ? "moved their meeting" : "booked a time"}.`,
      `<strong>${esc(c.eventType.name)}</strong><br>${esc(when(c.booking.startAt, zone))}`,
      ...(invitee.answers.notes ? [`Note from the guest: ${esc(invitee.answers.notes)}`] : []),
    ],
    { label: "Open your meetings", url: `${c.appUrl}/meetings` },
  );
  return { subject: `${moved ? "Moved" : "New booking"}: ${invitee.name}, ${c.eventType.name}`, html, text };
}

export function cancellationToGuest(c: Ctx, who: { name: string; email: string; timeZone: string }, by: "guest" | "host", reason: string | null): Built {
  const { html, text } = layout(
    "Meeting cancelled",
    [
      `Hi ${esc(who.name)}, the meeting below ${by === "host" ? `was cancelled by ${esc(c.host.name)}` : "was cancelled as you asked"}.`,
      `<strong>${esc(c.eventType.name)}</strong><br>${esc(when(c.booking.startAt, who.timeZone))}`,
      ...(reason ? [`Reason: ${esc(reason)}`] : []),
    ],
    { label: "Book a new time", url: `${c.appUrl}/${c.host.slug}/${c.eventType.slug}` },
  );
  const invitee = { id: "x", name: who.name, email: who.email, timeZone: who.timeZone, answers: {}, manageTokenHash: "", noShow: false };
  return { subject: `Cancelled: ${c.eventType.name} with ${c.host.name}`, html, text, attachments: ics(c, invitee, "CANCEL") };
}

export function cancellationToHost(c: Ctx, who: { name: string; email: string }, reason: string | null): Built {
  const { html, text } = layout(
    "Meeting cancelled",
    [
      `${esc(who.name)} (${esc(who.email)}) cancelled.`,
      `<strong>${esc(c.eventType.name)}</strong><br>${esc(when(c.booking.startAt, c.host.timeZone))}`,
      ...(reason ? [`Reason: ${esc(reason)}`] : []),
      "The time is open for booking again.",
    ],
  );
  return { subject: `Cancelled: ${who.name}, ${c.eventType.name}`, html, text };
}

export interface WorkflowLike { subject: string | null; body: string; includeManageLinks: boolean }

/** Workflow messages: the host's own wording, with {{event}}, {{host}}, {{guest}} and {{time}} filled in. */
export function workflowEmail(c: Ctx, invitee: Invitee, token: string | null, wf: WorkflowLike): Built {
  const fill = (s: string, safe: boolean) => s
    .replace(/\{\{event\}\}/g, safe ? esc(c.eventType.name) : c.eventType.name)
    .replace(/\{\{host\}\}/g, safe ? esc(c.host.name) : c.host.name)
    .replace(/\{\{guest\}\}/g, safe ? esc(invitee.name) : invitee.name)
    .replace(/\{\{time\}\}/g, safe ? esc(when(c.booking.startAt, invitee.timeZone)) : when(c.booking.startAt, invitee.timeZone));
  const subject = fill(wf.subject ?? "A note about your meeting", false).slice(0, 200);
  const manage = wf.includeManageLinks && token ? `${c.appUrl}/m/${token}` : null;
  const { html, text } = layout(
    c.eventType.name,
    [...fill(wf.body, true).split(/\n{2,}/).map((p) => p.replace(/\n/g, "<br>")), `${esc(when(c.booking.startAt, invitee.timeZone))}<br>${esc(whereText(c))}`],
    manage ? { label: "Change or cancel", url: manage } : undefined,
  );
  return { subject, html, text };
}
