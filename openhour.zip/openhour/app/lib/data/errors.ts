export class SlotUnavailableError extends Error {
  constructor() { super("That time was just taken."); }
}
export class NotFoundError extends Error {}
export class ValidationError extends Error {
  constructor(public errors: Record<string, string>) { super("Invalid input"); }
}
/** The host's calendar could not be checked, so a booking cannot be confirmed safely. */
export class CalendarUnavailableError extends Error {
  constructor() { super("We couldn't check the host's calendar. Please try again in a moment."); }
}
