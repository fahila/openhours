import { isUuid, one, query, tx } from "../db";
import type { Schedule } from "../types";
import { validateSchedule } from "../validate";
import { NotFoundError, ValidationError } from "./errors";
import { mapSchedule, type ScheduleRow } from "./rows";

type RuleRow = { schedule_id: string; day_of_week: number; start_time: string; end_time: string };
type OverrideRow = { schedule_id: string; on_date: string; start_time: string | null; end_time: string | null };

async function load(rows: ScheduleRow[]): Promise<Schedule[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const rules = await query<RuleRow>("select schedule_id, day_of_week, start_time::text, end_time::text from availability_rules where schedule_id = any($1) order by day_of_week, start_time", [ids]);
  const overrides = await query<OverrideRow>("select schedule_id, on_date::text, start_time::text, end_time::text from date_overrides where schedule_id = any($1) order by on_date, start_time", [ids]);
  return rows.map((r) => mapSchedule(r, rules.filter((x) => x.schedule_id === r.id), overrides.filter((x) => x.schedule_id === r.id)));
}

export async function listSchedules(userId: string): Promise<Schedule[]> {
  return load(await query<ScheduleRow>("select id, user_id, name, time_zone, is_default from availability_schedules where user_id = $1 order by created_at", [userId]));
}
export async function getSchedule(userId: string, id: string): Promise<Schedule | null> {
  if (!isUuid(id)) return null;
  return (await load(await query<ScheduleRow>("select id, user_id, name, time_zone, is_default from availability_schedules where id = $1 and user_id = $2", [id, userId])))[0] ?? null;
}
/** Public booking path: the event type already proved it belongs to the host. */
export async function getScheduleById(id: string): Promise<Schedule | null> {
  return (await load(await query<ScheduleRow>("select id, user_id, name, time_zone, is_default from availability_schedules where id = $1", [id])))[0] ?? null;
}

export async function saveSchedule(userId: string, id: string, input: Pick<Schedule, "name" | "timeZone" | "rules" | "overrides">): Promise<Schedule> {
  if (!isUuid(id)) throw new NotFoundError();
  const errors = validateSchedule(input);
  if (Object.keys(errors).length) throw new ValidationError(errors as Record<string, string>);
  await tx(async (c) => {
    const own = await one("select 1 from availability_schedules where id = $1 and user_id = $2 for update", [id, userId], c);
    if (!own) throw new NotFoundError();
    await c.query("update availability_schedules set name = $2, time_zone = $3 where id = $1", [id, input.name.trim(), input.timeZone]);
    await c.query("delete from availability_rules where schedule_id = $1", [id]);
    await c.query("delete from date_overrides where schedule_id = $1", [id]);
    for (const r of input.rules) await c.query("insert into availability_rules (schedule_id, day_of_week, start_time, end_time) values ($1, $2, $3, $4)", [id, r.dayOfWeek, r.start, r.end]);
    for (const o of input.overrides) await c.query("insert into date_overrides (schedule_id, on_date, start_time, end_time) values ($1, $2, $3, $4)", [id, o.date, o.start, o.end]);
  });
  return (await getSchedule(userId, id))!;
}
