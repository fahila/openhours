import type { Booking, EventType, Invitee, Schedule, User } from "../types";

export interface UserRow { id: string; email: string; name: string; slug: string; time_zone: string; welcome_message: string | null }
export const mapUser = (r: UserRow): User => ({
  id: r.id, email: r.email, name: r.name, slug: r.slug, timeZone: r.time_zone, welcomeMessage: r.welcome_message,
});

export interface EventTypeRow {
  id: string; user_id: string; schedule_id: string; kind: "one_on_one" | "group"; name: string; slug: string; description: string | null;
  color_index: number; duration_min: number; max_invitees: number; location_type: EventType["locationType"]; location_value: string | null;
  buffer_before_min: number; buffer_after_min: number; min_notice_min: number; rolling_days: number | null; start_increment_min: number;
  limit_per_day: number | null; limit_per_week: number | null; limit_per_month: number | null; confirmation_message: string | null;
  require_payment: boolean; price_cents: number | null; currency: string | null; active: boolean; hidden: boolean;
}
export const EVENT_TYPE_COLS = `id, user_id, schedule_id, kind, name, slug, description, color_index, duration_min, max_invitees, location_type,
  location_value, buffer_before_min, buffer_after_min, min_notice_min, rolling_days, start_increment_min, limit_per_day, limit_per_week,
  limit_per_month, confirmation_message, require_payment, price_cents, currency, active, hidden`;
export const mapEventType = (r: EventTypeRow): EventType => ({
  id: r.id, userId: r.user_id, scheduleId: r.schedule_id, kind: r.kind, name: r.name, slug: r.slug, description: r.description,
  colorIndex: r.color_index, durationMin: r.duration_min, maxInvitees: r.max_invitees, locationType: r.location_type,
  locationValue: r.location_value, bufferBeforeMin: r.buffer_before_min, bufferAfterMin: r.buffer_after_min, minNoticeMin: r.min_notice_min,
  rollingDays: r.rolling_days, startIncrementMin: r.start_increment_min, limitPerDay: r.limit_per_day, limitPerWeek: r.limit_per_week,
  limitPerMonth: r.limit_per_month, confirmationMessage: r.confirmation_message, requirePayment: r.require_payment, priceCents: r.price_cents,
  currency: r.currency, active: r.active, hidden: r.hidden,
});

export interface ScheduleRow { id: string; user_id: string; name: string; time_zone: string; is_default: boolean }
export const mapSchedule = (r: ScheduleRow, rules: { day_of_week: number; start_time: string; end_time: string }[], overrides: { on_date: string; start_time: string | null; end_time: string | null }[]): Schedule => ({
  id: r.id, userId: r.user_id, name: r.name, timeZone: r.time_zone, isDefault: r.is_default,
  rules: rules.map((x) => ({ dayOfWeek: x.day_of_week, start: x.start_time.slice(0, 5), end: x.end_time.slice(0, 5) })),
  overrides: overrides.map((x) => ({ date: x.on_date, start: x.start_time?.slice(0, 5) ?? null, end: x.end_time?.slice(0, 5) ?? null })),
});

/** A booking with its invitees folded into one JSON column. */
export const BOOKING_SELECT = `
  select b.id, b.event_type_id, b.host_id, b.start_at, b.end_at, b.status, b.meeting_url, b.provider_event_id, b.cancel_reason, b.rescheduled_from, b.created_at,
    coalesce(json_agg(json_build_object(
      'id', i.id, 'name', i.name, 'email', i.email, 'timeZone', i.time_zone, 'answers', i.answers,
      'manageTokenHash', encode(i.manage_token_hash, 'hex'), 'noShow', i.no_show) order by i.created_at) filter (where i.id is not null), '[]') as invitees
  from bookings b left join booking_invitees i on i.booking_id = b.id`;

export interface BookingRow {
  id: string; event_type_id: string; host_id: string; start_at: Date; end_at: Date; status: Booking["status"]; meeting_url: string | null;
  provider_event_id: string | null; cancel_reason: string | null; rescheduled_from: string | null; created_at: Date; invitees: Invitee[];
}
export const mapBooking = (r: BookingRow): Booking & { providerEventId: string | null } => ({
  id: r.id, eventTypeId: r.event_type_id, hostId: r.host_id, startAt: r.start_at.toISOString(), endAt: r.end_at.toISOString(), status: r.status,
  meetingUrl: r.meeting_url, providerEventId: r.provider_event_id, cancelReason: r.cancel_reason, rescheduledFrom: r.rescheduled_from,
  createdAt: r.created_at.toISOString(), invitees: r.invitees,
});
