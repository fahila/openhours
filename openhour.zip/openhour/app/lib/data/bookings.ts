import { DateTime } from "luxon";
import type { PoolClient } from "pg";
import { busyFor } from "../calendar/busy";
import { decrypt, encrypt, newToken, sha256 } from "../crypto";
import { isUuid, one, pgCode, pool, query, tx, type Q } from "../db";
import { enqueue } from "../jobs/queue";
import { generateSlots } from "../slots";
import type { Booking, EventType, Invitee, Slot, User } from "../types";
import { cleanLine, cleanText, EMAIL_RE } from "../validate";
import { CalendarUnavailableError, NotFoundError, SlotUnavailableError, ValidationError } from "./errors";
import { BOOKING_SELECT, EVENT_TYPE_COLS, mapBooking, mapEventType, mapUser, type BookingRow, type EventTypeRow, type UserRow } from "./rows";
import { getScheduleById } from "./schedules";

export type StoredBooking = Booking & { providerEventId: string | null };

const DAY = 86_400_000;
/** Limits count bookings per day, week and month, so the transaction reads this far either side of a slot. */
const WINDOW_DAYS = 35;
const PAYMENT_HOLD_MIN = 35;

const hashHex = (token: string) => sha256(token).toString("hex");

export async function lockHost(c: PoolClient, hostId: string) {
  await c.query("select pg_advisory_xact_lock(hashtextextended($1, 0))", [hostId]);
}

async function liveBookings(c: Q, hostId: string, fromMs: number, toMs: number): Promise<StoredBooking[]> {
  const rows = await query<BookingRow>(
    `${BOOKING_SELECT} where b.host_id = $1 and b.status in ('confirmed', 'pending_payment') and b.start_at < $3 and b.end_at > $2 group by b.id`,
    [hostId, new Date(fromMs), new Date(toMs)],
    c,
  );
  return rows.map(mapBooking);
}

/**
 * Calendar apps match updates to events by UID. A moved meeting is a new booking row here, so its UID must stay that
 * of the first booking in the chain, and SEQUENCE must rise with every move, or the guest's calendar keeps the old
 * event and shows a second one.
 */
export async function calendarIdentity(bookingId: string): Promise<{ uid: string; sequence: number }> {
  const r = await one<{ root: string; depth: number }>(
    `with recursive chain as (
       select id, rescheduled_from, 0 as depth from bookings where id = $1
       union all
       select b.id, b.rescheduled_from, c.depth + 1 from bookings b join chain c on b.id = c.rescheduled_from
     ) select id as root, depth from chain order by depth desc limit 1`,
    [bookingId],
  );
  return { uid: r?.root ?? bookingId, sequence: r?.depth ?? 0 };
}

export async function getBookingById(id: string, c?: Q): Promise<StoredBooking | null> {
  const r = await one<BookingRow>(`${BOOKING_SELECT} where b.id = $1 group by b.id`, [id], c ?? undefined);
  return r ? mapBooking(r) : null;
}

// ---- slots ------------------------------------------------------------------

export async function getSlots(et: EventType, fromDate: string, toDate: string, ignoreBookingId?: string): Promise<Slot[]> {
  const schedule = await getScheduleById(et.scheduleId);
  if (!schedule) return [];
  const from = Date.parse(fromDate + "T00:00:00Z");
  const to = Date.parse(toDate + "T00:00:00Z") + DAY;
  const [bookings, busy] = await Promise.all([
    liveBookings(pool(), et.userId, from - WINDOW_DAYS * DAY, to + WINDOW_DAYS * DAY),
    // if the host's calendar cannot be checked we offer no times rather than times that might clash
    busyFor(et.userId, new Date(from - DAY).toISOString(), new Date(to + DAY).toISOString(), { fresh: false }).catch(() => { throw new CalendarUnavailableError(); }),
  ]);
  return generateSlots({ eventType: et, schedule, bookings, busy, now: new Date(), fromDate, toDate, ignoreBookingId });
}

/** Re-runs slot generation around one instant, inside a transaction that already holds the host lock. */
async function findSlot(c: PoolClient, et: EventType, startAt: string, busy: { start: string; end: string }[], ignoreBookingId?: string): Promise<Slot | null> {
  const t = DateTime.fromISO(startAt, { zone: "UTC" });
  if (!t.isValid) return null;
  const schedule = await getScheduleById(et.scheduleId);
  if (!schedule) return null;
  const local = t.setZone(schedule.timeZone);
  const bookings = await liveBookings(c, et.userId, t.toMillis() - WINDOW_DAYS * DAY, t.toMillis() + WINDOW_DAYS * DAY);
  const slots = generateSlots({
    eventType: et, schedule, bookings, busy, now: new Date(), ignoreBookingId,
    fromDate: local.minus({ days: 1 }).toISODate()!, toDate: local.plus({ days: 1 }).toISODate()!,
  });
  return slots.find((s) => s.start === t.toUTC().toISO()) ?? null;
}

async function busyAround(hostId: string, startAt: string): Promise<{ start: string; end: string }[]> {
  const t = Date.parse(startAt);
  if (Number.isNaN(t)) return [];
  try {
    return await busyFor(hostId, new Date(t - DAY).toISOString(), new Date(t + DAY).toISOString(), { fresh: true });
  } catch {
    throw new CalendarUnavailableError();
  }
}

// ---- create -----------------------------------------------------------------

export interface NewBooking {
  eventTypeId: string;
  startAt: string;
  name: string;
  email: string;
  timeZone: string;
  answers?: Record<string, string>;
}

export async function createBooking(input: NewBooking): Promise<{ booking: StoredBooking; manageToken: string }> {
  const errors: Record<string, string> = {};
  const name = cleanLine(input.name);
  if (!name) errors.name = "Tell us your name.";
  if (name.length > 120) errors.name = "That name is too long.";
  if (!EMAIL_RE.test(input.email.trim())) errors.email = "Enter a valid email address.";
  try { new Intl.DateTimeFormat("en", { timeZone: input.timeZone }); } catch { errors.timeZone = "Unknown time zone."; }
  if (Object.keys(errors).length) throw new ValidationError(errors);

  const etRow = await one<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where id = $1 and active`, [input.eventTypeId]);
  if (!etRow) throw new NotFoundError();
  const et = mapEventType(etRow);
  const busy = await busyAround(et.userId, input.startAt);

  const email = input.email.trim().toLowerCase();
  const token = newToken(24);
  try {
    const booking = await tx(async (c) => {
      await lockHost(c, et.userId);
      const slot = await findSlot(c, et, input.startAt, busy);
      if (!slot) throw new SlotUnavailableError();

      const existing = (await liveBookings(c, et.userId, Date.parse(slot.start), Date.parse(slot.end))).find((b) => b.eventTypeId === et.id && b.startAt === slot.start);
      let bookingId: string;
      if (existing) {
        bookingId = existing.id;
      } else {
        const status = et.requirePayment ? "pending_payment" : "confirmed";
        bookingId = (await c.query<{ id: string }>("insert into bookings (event_type_id, host_id, start_at, end_at, status) values ($1, $2, $3, $4, $5) returning id", [et.id, et.userId, slot.start, slot.end, status])).rows[0].id;
      }
      await c.query(
        "insert into booking_invitees (booking_id, name, email, time_zone, is_primary, answers, manage_token_hash, manage_token_enc) values ($1, $2, $3, $4, $5, $6, $7, $8)",
        [bookingId, name, email, input.timeZone, !existing, JSON.stringify(Object.fromEntries(Object.entries(input.answers ?? {}).map(([k, v]) => [cleanLine(k), cleanText(v)]))), sha256(token), encrypt(token)],
      );
      if (et.requirePayment) {
        if (!existing) await enqueue(c, "payment.expire", { bookingId }, { runAt: new Date(Date.now() + PAYMENT_HOLD_MIN * 60_000), dedupeKey: `payment.expire:${bookingId}` });
      } else {
        await enqueue(c, "booking.confirmed", { bookingId, inviteeEmail: email }, { dedupeKey: `booking.confirmed:${bookingId}:${email}` });
      }
      return (await getBookingById(bookingId, c))!;
    });
    return { booking, manageToken: token };
  } catch (e) {
    if (pgCode(e) === "23P01") throw new SlotUnavailableError();
    if (pgCode(e) === "23505") throw new ValidationError({ email: "This email is already booked for that time." });
    throw e;
  }
}

// ---- reading ------------------------------------------------------------------

export interface PaymentSummary { status: "pending" | "paid" | "refunded" | "failed"; amountCents: number; currency: string }

export async function listBookings(userId: string, when: "upcoming" | "past"): Promise<(StoredBooking & { eventType: EventType | null; payment: PaymentSummary | null })[]> {
  const cond = when === "upcoming" ? "b.status <> 'cancelled' and b.end_at >= now()" : "(b.status = 'cancelled' or b.end_at < now())";
  const order = when === "upcoming" ? "b.start_at asc" : "b.start_at desc";
  const rows = await query<BookingRow>(`${BOOKING_SELECT} where b.host_id = $1 and ${cond} group by b.id order by ${order} limit 200`, [userId]);
  const bookings = rows.map(mapBooking);
  const types = bookings.length
    ? (await query<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where id = any($1)`, [[...new Set(bookings.map((b) => b.eventTypeId))]])).map(mapEventType)
    : [];
  const pays = bookings.length
    ? await query<{ booking_id: string; status: PaymentSummary["status"]; amount_cents: number; currency: string }>(
        "select distinct on (booking_id) booking_id, status, amount_cents, currency from payments where booking_id = any($1) order by booking_id, created_at desc",
        [bookings.map((b) => b.id)],
      )
    : [];
  return bookings.map((b) => {
    const p = pays.find((x) => x.booking_id === b.id);
    return { ...b, eventType: types.find((t) => t.id === b.eventTypeId) ?? null, payment: p ? { status: p.status, amountCents: p.amount_cents, currency: p.currency } : null };
  });
}

export interface ManagedBooking {
  booking: StoredBooking;
  invitee: Invitee;
  eventType: EventType;
  host: User;
}

export async function findByManageToken(token: string, c?: Q): Promise<ManagedBooking | null> {
  const hit = await one<{ booking_id: string; invitee_id: string }>("select booking_id, id as invitee_id from booking_invitees where manage_token_hash = $1", [sha256(token)], c);
  if (!hit) return null;
  const booking = await getBookingById(hit.booking_id, c);
  const invitee = booking?.invitees.find((i) => i.id === hit.invitee_id);
  if (!booking || !invitee) return null;
  const et = await one<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where id = $1`, [booking.eventTypeId], c);
  const host = await one<UserRow>("select id, email, name, slug, time_zone, welcome_message from users where id = $1", [booking.hostId], c);
  return et && host ? { booking, invitee, eventType: mapEventType(et), host: mapUser(host) } : null;
}

/** Everything the background jobs need to know about a booking. */
export async function getBookingContext(bookingId: string): Promise<{ booking: StoredBooking; eventType: EventType; host: User } | null> {
  const booking = await getBookingById(bookingId);
  if (!booking) return null;
  const et = await one<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where id = $1`, [booking.eventTypeId]);
  const host = await one<UserRow>("select id, email, name, slug, time_zone, welcome_message from users where id = $1", [booking.hostId]);
  return et && host ? { booking, eventType: mapEventType(et), host: mapUser(host) } : null;
}

export async function setBookingMeeting(bookingId: string, providerEventId: string | null, meetingUrl: string | null) {
  await query("update bookings set provider_event_id = coalesce($2, provider_event_id), meeting_url = coalesce($3, meeting_url) where id = $1", [bookingId, providerEventId, meetingUrl]);
}

// ---- cancelling and moving ------------------------------------------------------

const snapshot = (i: Invitee) => ({ name: i.name, email: i.email, timeZone: i.timeZone });

async function cancelInside(c: PoolClient, b: StoredBooking, reason: string | null, by: "guest" | "host", extra: Record<string, unknown> = {}) {
  const cleanReason = reason ? cleanText(reason).trim().slice(0, 500) || null : null;
  await c.query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = $2 where id = $1", [b.id, cleanReason]);
  await enqueue(c, "booking.cancelled", { bookingId: b.id, by, reason: cleanReason, invitees: b.invitees.map(snapshot), ...extra }, { dedupeKey: `booking.cancelled:${b.id}` });
}

export async function cancelBookingAsHost(userId: string, bookingId: string, reason: string | null) {
  if (!isUuid(bookingId)) throw new NotFoundError();
  await tx(async (c) => {
    await lockHost(c, userId);
    const b = await getBookingById(bookingId, c);
    if (!b || b.hostId !== userId) throw new NotFoundError();
    if (b.status === "cancelled") return;
    await cancelInside(c, b, reason, "host");
  });
}

export async function cancelByToken(token: string, reason: string | null): Promise<"cancelled" | "left"> {
  const first = await findByManageToken(token);
  if (!first) throw new NotFoundError();
  return tx(async (c): Promise<"cancelled" | "left"> => {
    await lockHost(c, first.booking.hostId);
    const m = await findByManageToken(token, c);
    if (!m) throw new NotFoundError();
    if (m.booking.status === "cancelled") return "cancelled";
    if (Date.parse(m.booking.startAt) < Date.now()) throw new ValidationError({ _: "This meeting has already started." });
    if (m.booking.invitees.length > 1) {
      await c.query("delete from booking_invitees where id = $1", [m.invitee.id]);
      await enqueue(c, "booking.cancelled", { bookingId: m.booking.id, by: "guest", reason: reason ? cleanText(reason).trim().slice(0, 500) || null : null, invitees: [snapshot(m.invitee)], partial: true }, { dedupeKey: `booking.cancelled:${m.booking.id}:${m.invitee.id}` });
      return "left";
    }
    await cancelInside(c, m.booking, reason, "guest");
    if (m.booking.status === "pending_payment") await enqueue(c, "payment.expire", { bookingId: m.booking.id }, { dedupeKey: `payment.expire:cancel:${m.booking.id}` });
    return "cancelled";
  });
}

/** Move a guest to a new slot. The old booking is cancelled and the new one linked back to it, in one transaction. */
export async function rescheduleByToken(token: string, newStartAt: string): Promise<{ booking: StoredBooking; manageToken: string }> {
  const first = await findByManageToken(token);
  if (!first) throw new NotFoundError();
  const busy = await busyAround(first.booking.hostId, newStartAt);
  const newToken_ = newToken(24);
  try {
    const booking = await tx(async (c) => {
      await lockHost(c, first.booking.hostId);
      const m = await findByManageToken(token, c);
      if (!m) throw new NotFoundError();
      if (m.booking.status !== "confirmed") throw new ValidationError({ _: "This meeting was cancelled." });
      if (Date.parse(m.booking.startAt) < Date.now()) throw new ValidationError({ _: "This meeting has already started." });
      const slot = await findSlot(c, m.eventType, newStartAt, busy, m.booking.id);
      if (!slot) throw new SlotUnavailableError();

      const alone = m.booking.invitees.length === 1;
      if (alone) {
        await c.query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = 'Rescheduled' where id = $1", [m.booking.id]);
        await enqueue(c, "booking.cancelled", { bookingId: m.booking.id, by: "guest", reason: "Rescheduled", invitees: [snapshot(m.invitee)], rescheduled: true }, { dedupeKey: `booking.cancelled:${m.booking.id}` });
      } else {
        await c.query("delete from booking_invitees where id = $1", [m.invitee.id]);
      }

      const target = (await liveBookings(c, m.eventType.userId, Date.parse(slot.start), Date.parse(slot.end))).find((b) => b.eventTypeId === m.eventType.id && b.startAt === slot.start);
      let bookingId = target?.id;
      if (!bookingId) {
        bookingId = (await c.query<{ id: string }>(
          "insert into bookings (event_type_id, host_id, start_at, end_at, status, rescheduled_from) values ($1, $2, $3, $4, 'confirmed', $5) returning id",
          [m.eventType.id, m.eventType.userId, slot.start, slot.end, m.booking.id],
        )).rows[0].id;
      }
      await c.query(
        "insert into booking_invitees (booking_id, name, email, time_zone, is_primary, answers, manage_token_hash, manage_token_enc) values ($1, $2, $3, $4, $5, $6, $7, $8)",
        [bookingId, m.invitee.name, m.invitee.email, m.invitee.timeZone, !target, JSON.stringify(m.invitee.answers), sha256(newToken_), encrypt(newToken_)],
      );
      await enqueue(c, "booking.confirmed", { bookingId, inviteeEmail: m.invitee.email, rescheduledFrom: m.booking.startAt }, { dedupeKey: `booking.confirmed:${bookingId}:${m.invitee.email}` });
      return (await getBookingById(bookingId, c))!;
    });
    return { booking, manageToken: newToken_ };
  } catch (e) {
    if (pgCode(e) === "23P01") throw new SlotUnavailableError();
    throw e;
  }
}

/** The guest's cancel and reschedule token, for building links in emails. Null for rows created before tokens were kept. */
export async function getInviteeToken(inviteeId: string): Promise<string | null> {
  const r = await one<{ manage_token_enc: Buffer | null }>("select manage_token_enc from booking_invitees where id = $1", [inviteeId]);
  if (!r?.manage_token_enc) return null;
  try { return decrypt(r.manage_token_enc); } catch { return null; }
}

/** The guest came back from Stripe without paying. Free their unpaid hold at once. True if there was a hold to release. */
export async function releaseUnpaidByToken(token: string): Promise<boolean> {
  const m = await findByManageToken(token);
  if (!m || m.booking.status !== "pending_payment") return false;
  return tx(async (c) => {
    await lockHost(c, m.booking.hostId);
    const r = await c.query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = 'Payment cancelled' where id = $1 and status = 'pending_payment' returning id", [m.booking.id]);
    if (r.rowCount === 0) return false;
    await enqueue(c, "payment.expire", { bookingId: m.booking.id }, { dedupeKey: `payment.expire:back:${m.booking.id}` }); // also closes the Stripe session
    return true;
  });
}

/** Payment could not be started: free the slot straight away. */
export async function abandonPendingBooking(bookingId: string, reason: string) {
  await query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = $2 where id = $1 and status = 'pending_payment'", [bookingId, reason]);
}
