import { isUuid, one, query } from "../db";
import type { EventType } from "../types";
import type { EventTypeInput } from "../validate";
import { NotFoundError, ValidationError } from "./errors";
import { EVENT_TYPE_COLS, mapEventType, type EventTypeRow } from "./rows";

export async function listEventTypes(userId: string): Promise<EventType[]> {
  return (await query<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where user_id = $1 order by created_at`, [userId])).map(mapEventType);
}
export async function getEventType(userId: string, id: string): Promise<EventType | null> {
  if (!isUuid(id)) return null;
  const r = await one<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where id = $1 and user_id = $2`, [id, userId]);
  return r ? mapEventType(r) : null;
}
export async function getEventTypeBySlug(userId: string, slug: string): Promise<EventType | null> {
  if (!/^[a-z0-9][a-z0-9-]{0,58}$/.test(slug)) return null; // see getUserBySlug
  const r = await one<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where user_id = $1 and slug = $2 and active`, [userId, slug]);
  return r ? mapEventType(r) : null;
}
export async function listPublicEventTypes(userId: string): Promise<EventType[]> {
  return (await query<EventTypeRow>(`select ${EVENT_TYPE_COLS} from event_types where user_id = $1 and active and not hidden order by created_at`, [userId])).map(mapEventType);
}

const FIELDS = [
  "schedule_id", "kind", "name", "slug", "description", "color_index", "duration_min", "max_invitees", "location_type", "location_value",
  "buffer_before_min", "buffer_after_min", "min_notice_min", "rolling_days", "start_increment_min", "limit_per_day", "limit_per_week",
  "limit_per_month", "confirmation_message", "require_payment", "price_cents", "currency",
] as const;

const values = (i: EventTypeInput) => [
  i.scheduleId, i.kind, i.name, i.slug, i.description, i.colorIndex, i.durationMin, i.maxInvitees, i.locationType, i.locationValue,
  i.bufferBeforeMin, i.bufferAfterMin, i.minNoticeMin, i.rollingDays, i.startIncrementMin, i.limitPerDay, i.limitPerWeek,
  i.limitPerMonth, i.confirmationMessage, i.requirePayment, i.priceCents, i.currency,
];

export async function saveEventType(userId: string, id: string | null, input: EventTypeInput): Promise<EventType> {
  if (id !== null && !isUuid(id)) throw new NotFoundError();
  if (!isUuid(input.scheduleId) || !(await one("select 1 from availability_schedules where id = $1 and user_id = $2", [input.scheduleId, userId]))) {
    throw new ValidationError({ scheduleId: "Choose one of your hours." });
  }
  try {
    const v = values(input);
    if (id) {
      const set = FIELDS.map((f, n) => `${f} = $${n + 3}`).join(", ");
      const r = await one<EventTypeRow>(`update event_types set ${set} where id = $1 and user_id = $2 returning ${EVENT_TYPE_COLS}`, [id, userId, ...v]);
      if (!r) throw new NotFoundError();
      return mapEventType(r);
    }
    const cols = FIELDS.join(", ");
    const ph = FIELDS.map((_, n) => `$${n + 2}`).join(", ");
    const r = await one<EventTypeRow>(`insert into event_types (user_id, ${cols}) values ($1, ${ph}) returning ${EVENT_TYPE_COLS}`, [userId, ...v]);
    return mapEventType(r!);
  } catch (e) {
    if ((e as { code?: string }).code === "23505") throw new ValidationError({ slug: "You already use that link name." });
    throw e;
  }
}

export async function setEventTypeActive(userId: string, id: string, active: boolean) {
  if (!isUuid(id)) throw new NotFoundError();
  const r = await query("update event_types set active = $3 where id = $1 and user_id = $2 returning id", [id, userId, active]);
  if (r.length === 0) throw new NotFoundError();
}

export async function deleteEventType(userId: string, id: string) {
  if (!isUuid(id)) throw new NotFoundError();
  if (await one("select 1 from bookings b join event_types e on e.id = b.event_type_id where e.id = $1 and e.user_id = $2 limit 1", [id, userId])) {
    throw new ValidationError({ _: "This event has bookings. Turn it off instead." });
  }
  const r = await query("delete from event_types where id = $1 and user_id = $2 returning id", [id, userId]);
  if (r.length === 0) throw new NotFoundError();
}
