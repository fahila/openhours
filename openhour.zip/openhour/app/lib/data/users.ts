import { one, query, tx, type Q } from "../db";
import { RESERVED_SLUGS, slugify } from "../validate";
import type { User } from "../types";
import { NotFoundError, ValidationError } from "./errors";
import { mapUser, type UserRow } from "./rows";

const COLS = "id, email, name, slug, time_zone, welcome_message";

export async function getUserById(id: string): Promise<User | null> {
  const r = await one<UserRow>(`select ${COLS} from users where id = $1`, [id]);
  return r ? mapUser(r) : null;
}
/** Link names come straight from the address bar. Anything that could not be a link name is "no such person", and never reaches the database (a NUL byte makes Postgres throw). */
const SLUG_SHAPE = /^[a-z0-9][a-z0-9-]{0,58}$/;

export async function getUserBySlug(slug: string): Promise<User | null> {
  if (!SLUG_SHAPE.test(slug)) return null;
  const r = await one<UserRow>(`select ${COLS} from users where slug = $1`, [slug]);
  return r ? mapUser(r) : null;
}
export async function getUserByEmail(email: string): Promise<User | null> {
  const r = await one<UserRow>(`select ${COLS} from users where email = $1`, [email.toLowerCase()]);
  return r ? mapUser(r) : null;
}

export async function updateUser(userId: string, patch: Partial<Pick<User, "name" | "slug" | "timeZone" | "welcomeMessage">>): Promise<User> {
  if (patch.slug !== undefined && (RESERVED_SLUGS.has(patch.slug) || !/^[a-z0-9][a-z0-9-]{1,38}$/.test(patch.slug))) {
    throw new ValidationError({ slug: "Use 2 to 39 lowercase letters, numbers or dashes, and not a reserved word." });
  }
  try {
    const r = await one<UserRow>(
      `update users set name = coalesce($2, name), slug = coalesce($3, slug), time_zone = coalesce($4, time_zone),
         welcome_message = case when $5::boolean then $6 else welcome_message end
       where id = $1 returning ${COLS}`,
      [userId, patch.name ?? null, patch.slug ?? null, patch.timeZone ?? null, patch.welcomeMessage !== undefined, patch.welcomeMessage ?? null],
    );
    if (!r) throw new NotFoundError();
    return mapUser(r);
  } catch (e) {
    if ((e as { code?: string }).code === "23505") throw new ValidationError({ slug: "That link name is taken." });
    throw e;
  }
}

async function uniqueSlug(base: string, c: Q): Promise<string> {
  let root = slugify(base).replace(/^-+/, "").slice(0, 30) || "host";
  if (root.length < 2) root += "-1";
  for (let n = 0; n < 50; n++) {
    const candidate = n === 0 ? root : `${root}-${n + 1}`;
    if (RESERVED_SLUGS.has(candidate)) continue;
    if (!(await one("select 1 from users where slug = $1", [candidate], c))) return candidate;
  }
  throw new Error("Could not find a free link name");
}

/**
 * First sign-in: a user, their default hours, a starter event type and a default reminder workflow.
 * Time zone starts as UTC. They change it in Settings or Availability.
 */
export async function createUserWithDefaults(input: { email: string; name: string; googleSub?: string }): Promise<User> {
  return tx(async (c) => {
    const email = input.email.toLowerCase();
    const name = input.name.trim().slice(0, 120) || email.split("@")[0];
    const slug = await uniqueSlug(name === email.split("@")[0] ? name : name, c);
    const u = (await c.query<UserRow>(`insert into users (email, name, slug, time_zone) values ($1, $2, $3, 'UTC') returning ${COLS}`, [email, name, slug])).rows[0];
    if (input.googleSub) await c.query("insert into login_identities (user_id, provider, provider_user_id) values ($1, 'google', $2)", [u.id, input.googleSub]);
    const sch = (await c.query<{ id: string }>("insert into availability_schedules (user_id, name, time_zone, is_default) values ($1, 'Working hours', 'UTC', true) returning id", [u.id])).rows[0];
    for (const d of [1, 2, 3, 4, 5]) await c.query("insert into availability_rules (schedule_id, day_of_week, start_time, end_time) values ($1, $2, '09:00', '17:00')", [sch.id, d]);
    await c.query(
      `insert into event_types (user_id, schedule_id, kind, name, slug, color_index, duration_min, location_type) values ($1, $2, 'one_on_one', '30 minute meeting', '30-minute-meeting', 1, 30, 'google_meet')`,
      [u.id, sch.id],
    );
    await c.query(`insert into workflows (user_id, name, trigger, offset_min, channel, subject, body) values ($1, 'Reminder 24 hours before', 'before_event', 1440, 'email', 'Reminder: {{event}} tomorrow', 'This is a reminder about your meeting.')`, [u.id]);
    return mapUser(u);
  });
}

export async function findUserByGoogleSub(sub: string): Promise<User | null> {
  const r = await one<UserRow>(`select ${COLS.split(", ").map((c) => "u." + c).join(", ")} from users u join login_identities l on l.user_id = u.id where l.provider = 'google' and l.provider_user_id = $1`, [sub]);
  return r ? mapUser(r) : null;
}
export async function linkGoogleIdentity(userId: string, sub: string) {
  await query("insert into login_identities (user_id, provider, provider_user_id) values ($1, 'google', $2) on conflict do nothing", [userId, sub]);
}

/** Removes the person and everything of theirs. Bookings go first because event types are protected while bookings exist. */
export async function deleteUser(userId: string): Promise<void> {
  await tx(async (c) => {
    // payments are local copies of what Stripe holds; they block deleting a booking until removed first
    await c.query("delete from payments where booking_id in (select id from bookings where host_id = $1)", [userId]);
    await c.query("delete from bookings where host_id = $1", [userId]);
    await c.query("delete from users where id = $1", [userId]);
  });
}
