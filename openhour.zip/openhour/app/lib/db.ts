import { Pool, types, type PoolClient, type QueryResultRow } from "pg";
import { env } from "./env";

// dates stay "YYYY-MM-DD" strings instead of becoming local-midnight Date objects
types.setTypeParser(1082, (v) => v);

const g = globalThis as unknown as { __pool?: Pool };

export function pool(): Pool {
  return (g.__pool ??= new Pool({ connectionString: env().DATABASE_URL, max: 10, idleTimeoutMillis: 30_000 }));
}

export async function closePool() {
  await g.__pool?.end();
  g.__pool = undefined;
}

export type Q = Pick<PoolClient, "query">;

export async function query<T extends QueryResultRow = QueryResultRow>(text: string, params: unknown[] = [], c: Q = pool()): Promise<T[]> {
  return (await c.query<T>(text, params)).rows;
}

export async function one<T extends QueryResultRow = QueryResultRow>(text: string, params: unknown[] = [], c: Q = pool()): Promise<T | null> {
  return (await query<T>(text, params, c))[0] ?? null;
}

export async function tx<T>(fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await pool().connect();
  try {
    await c.query("begin");
    const r = await fn(c);
    await c.query("commit");
    return r;
  } catch (e) {
    await c.query("rollback").catch(() => {});
    throw e;
  } finally {
    c.release();
  }
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
/** Ids come from URLs and forms. Postgres raises a 500-level error on a malformed uuid, so check first and treat it as "not found". */
export const isUuid = (v: unknown): v is string => typeof v === "string" && UUID.test(v);

/** Postgres error code helper: 23P01 exclusion violation, 23505 unique violation. */
export const pgCode = (e: unknown): string | undefined => (e as { code?: string })?.code;
