import { z } from "zod";

const bool = z.enum(["1", "true", "0", "false", ""]).optional().transform((v) => v === "1" || v === "true");

const schema = z.object({
  NODE_ENV: z.string().default("development"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  APP_URL: z.string().url().default("http://localhost:3000"),
  /** 32 random bytes, base64. Encrypts calendar refresh tokens and webhook secrets at rest. */
  APP_ENCRYPTION_KEY: z.string().optional(),
  /** Comma separated emails allowed to sign in. Empty means nobody can. */
  ALLOWED_EMAILS: z.string().default(""),
  CRON_SECRET: z.string().optional(),
  DEV_LOGIN: bool,

  GOOGLE_CLIENT_ID: z.string().optional(),
  GOOGLE_CLIENT_SECRET: z.string().optional(),

  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().optional(),

  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),

  // Test and local overrides for talking to mock servers. Never set in production.
  GOOGLE_OAUTH_BASE: z.string().url().optional(),
  GOOGLE_API_BASE: z.string().url().optional(),
  RESEND_API_BASE: z.string().url().optional(),
  STRIPE_API_HOST: z.string().optional(),
  STRIPE_API_PORT: z.string().optional(),
  STRIPE_API_PROTOCOL: z.enum(["http", "https"]).optional(),
});

export type Env = z.infer<typeof schema> & {
  isProd: boolean;
  allowedEmails: string[];
  googleEnabled: boolean;
  stripeEnabled: boolean;
  devLoginEnabled: boolean;
};

const PROD_REQUIRED = ["DATABASE_URL", "APP_URL", "APP_ENCRYPTION_KEY", "CRON_SECRET", "RESEND_API_KEY", "EMAIL_FROM", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET"] as const;

let cached: Env | null = null;

export function parseEnv(source: Record<string, string | undefined>): Env {
  const r = schema.safeParse(source);
  if (!r.success) throw new Error("Bad environment:\n" + r.error.issues.map((i) => `  ${i.path.join(".")}: ${i.message}`).join("\n"));
  const e = r.data;
  const isProd = e.NODE_ENV === "production";
  if (isProd) {
    const missing = PROD_REQUIRED.filter((k) => !e[k]);
    if (!e.ALLOWED_EMAILS.trim()) missing.push("ALLOWED_EMAILS" as never);
    if (missing.length) throw new Error("Missing production environment variables: " + missing.join(", "));
    if (e.DEV_LOGIN) throw new Error("DEV_LOGIN must not be set in production");
    if (e.GOOGLE_OAUTH_BASE || e.GOOGLE_API_BASE || e.RESEND_API_BASE || e.STRIPE_API_HOST) throw new Error("Mock server overrides must not be set in production");
    if (!e.APP_URL.startsWith("https://")) throw new Error("APP_URL must be https in production");
  }
  if (e.APP_ENCRYPTION_KEY && Buffer.from(e.APP_ENCRYPTION_KEY, "base64").length !== 32) throw new Error("APP_ENCRYPTION_KEY must be 32 bytes, base64 encoded");
  return {
    ...e,
    isProd,
    allowedEmails: e.ALLOWED_EMAILS.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean),
    googleEnabled: Boolean(e.GOOGLE_CLIENT_ID && e.GOOGLE_CLIENT_SECRET),
    stripeEnabled: Boolean(e.STRIPE_SECRET_KEY),
    devLoginEnabled: !isProd && e.DEV_LOGIN,
  };
}

export function env(): Env {
  return (cached ??= parseEnv(process.env));
}

/** For tests that change process.env between cases. */
export function resetEnvCache() {
  cached = null;
}
