import Stripe from "stripe";
import { one, query } from "../db";
import { env } from "../env";
import type { EventType, User } from "../types";
import type { StoredBooking } from "../data/bookings";

/** Stripe Checkout in test mode until replica-deploy. We never touch card numbers: Stripe hosts the payment page. */

let client: Stripe | null = null;
let clientKey = "";

export function stripe(): Stripe {
  const e = env();
  if (!e.STRIPE_SECRET_KEY) throw new Error("STRIPE_SECRET_KEY is not set");
  const sig = [e.STRIPE_SECRET_KEY, e.STRIPE_API_HOST, e.STRIPE_API_PORT].join("|");
  if (!client || sig !== clientKey) {
    client = new Stripe(e.STRIPE_SECRET_KEY, {
      maxNetworkRetries: 2,
      timeout: 15_000,
      ...(e.STRIPE_API_HOST ? { host: e.STRIPE_API_HOST, port: e.STRIPE_API_PORT, protocol: e.STRIPE_API_PROTOCOL ?? "http" } : {}),
    });
    clientKey = sig;
  }
  return client;
}

/** Stripe refuses to start a Checkout Session that expires in under 30 minutes. Our own hold on the slot is 35. */
const SESSION_MINUTES = 31;

export async function startCheckout(input: { booking: StoredBooking; eventType: EventType; host: User; manageToken: string }): Promise<string> {
  const { booking, eventType, host, manageToken } = input;
  if (!eventType.requirePayment || !eventType.priceCents || !eventType.currency) throw new Error("This event type does not take payment");
  const app = env().APP_URL.replace(/\/$/, "");
  const guest = booking.invitees[0];
  const session = await stripe().checkout.sessions.create(
    {
      mode: "payment",
      line_items: [{ quantity: 1, price_data: { currency: eventType.currency, unit_amount: eventType.priceCents, product_data: { name: `${eventType.name} with ${host.name}` } } }],
      customer_email: guest.email,
      client_reference_id: booking.id,
      metadata: { booking_id: booking.id },
      payment_intent_data: { metadata: { booking_id: booking.id } },
      success_url: `${app}/booked/${manageToken}?paid=1`,
      // the token lets the booking page release this guest's hold the moment they come back, instead of 35 minutes later
      cancel_url: `${app}/${host.slug}/${eventType.slug}?payment=cancelled&m=${manageToken}`,
      expires_at: Math.floor(Date.now() / 1000) + SESSION_MINUTES * 60,
    },
    { idempotencyKey: `checkout:${booking.id}` },
  );
  if (!session.url) throw new Error("Stripe returned no checkout URL");
  await query(
    "insert into payments (booking_id, provider, provider_session_id, amount_cents, currency, status) values ($1, 'stripe', $2, $3, $4, 'pending')",
    [booking.id, session.id, eventType.priceCents, eventType.currency],
  );
  return session.url;
}

/**
 * Job: the guest never paid. Free the slot and close the Stripe session so it cannot be paid afterwards.
 * Leaves a booking alone if money has already arrived.
 */
export async function expireUnpaidBooking(bookingId: string): Promise<void> {
  const p = await one<{ id: string; provider_session_id: string; status: string }>("select id, provider_session_id, status from payments where booking_id = $1 order by created_at desc limit 1", [bookingId]);
  if (p && p.status === "paid") return;
  await query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = coalesce(cancel_reason, 'Payment not completed') where id = $1 and status = 'pending_payment'", [bookingId]);
  if (p && p.status === "pending") {
    await query("update payments set status = 'failed' where id = $1 and status = 'pending'", [p.id]);
    try {
      await stripe().checkout.sessions.expire(p.provider_session_id);
    } catch (e) {
      // already completed or expired on Stripe's side; the webhook reconciles the rest
      if (!(e instanceof Stripe.errors.StripeInvalidRequestError)) throw e;
    }
  }
}

/** Job: money arrived for a booking that no longer exists (it expired first). Give it back. */
export async function refundPayment(paymentId: string): Promise<void> {
  const p = await one<{ id: string; provider_payment_id: string | null; status: string }>("select id, provider_payment_id, status from payments where id = $1", [paymentId]);
  if (!p || p.status === "refunded" || !p.provider_payment_id) return;
  await stripe().refunds.create({ payment_intent: p.provider_payment_id, reason: "requested_by_customer" }, { idempotencyKey: `refund:${p.id}` });
  await query("update payments set status = 'refunded' where id = $1", [p.id]);
}
