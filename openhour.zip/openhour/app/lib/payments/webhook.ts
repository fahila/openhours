import Stripe from "stripe";
import { lockHost } from "../data/bookings";
import { tx } from "../db";
import { env } from "../env";
import { enqueue } from "../jobs/queue";
import { stripe } from "./stripe";

export interface WebhookResult { status: number; body: string }

/**
 * Stripe webhook. The signature is checked against the raw body, the event id is recorded in the same transaction
 * as its effects (so a failure rolls both back and Stripe's retry works), and every effect is safe to repeat.
 */
export async function handleStripeWebhook(rawBody: string, signature: string | null): Promise<WebhookResult> {
  const secret = env().STRIPE_WEBHOOK_SECRET;
  if (!secret) return { status: 503, body: "Stripe webhooks are not configured" };
  if (!signature) return { status: 400, body: "Missing signature" };
  let event: Stripe.Event;
  try {
    event = stripe().webhooks.constructEvent(rawBody, signature, secret); // also rejects timestamps older than 5 minutes
  } catch {
    return { status: 400, body: "Bad signature" };
  }
  const outcome = await tx(async (c) => {
    const first = await c.query("insert into inbound_events (provider, event_id) values ('stripe', $1) on conflict do nothing returning event_id", [event.id]);
    if (first.rowCount === 0) return "duplicate";

    switch (event.type) {
      case "checkout.session.completed": {
        const s = event.data.object as Stripe.Checkout.Session;
        if (s.payment_status !== "paid") return "ignored";
        const peek = await c.query<{ host_id: string }>("select b.host_id from payments p join bookings b on b.id = p.booking_id where p.provider_session_id = $1", [s.id]);
        if (peek.rowCount === 0) return "unknown session";
        await lockHost(c, peek.rows[0].host_id);
        const row = (await c.query<{ pid: string; bid: string; bstatus: string }>(
          "select p.id as pid, b.id as bid, b.status as bstatus from payments p join bookings b on b.id = p.booking_id where p.provider_session_id = $1 for update of p, b", [s.id],
        )).rows[0];
        const intent = typeof s.payment_intent === "string" ? s.payment_intent : s.payment_intent?.id ?? null;
        await c.query("update payments set status = 'paid', provider_payment_id = coalesce($2, provider_payment_id) where id = $1 and status <> 'refunded'", [row.pid, intent]);
        if (row.bstatus === "pending_payment") {
          await c.query("update bookings set status = 'confirmed' where id = $1", [row.bid]);
          const inv = (await c.query<{ email: string }>("select email from booking_invitees where booking_id = $1 order by created_at limit 1", [row.bid])).rows[0];
          await enqueue(c, "booking.confirmed", { bookingId: row.bid, inviteeEmail: inv.email }, { dedupeKey: `booking.confirmed:${row.bid}:${inv.email}` });
          return "confirmed";
        }
        if (row.bstatus === "cancelled") {
          // paid after the hold ran out and the slot was released: refund rather than keep money for nothing
          await enqueue(c, "payment.refund", { paymentId: row.pid }, { dedupeKey: `payment.refund:${row.pid}` });
          return "late payment, refund queued";
        }
        return "already confirmed";
      }
      case "checkout.session.expired": {
        const s = event.data.object as Stripe.Checkout.Session;
        const peek = await c.query<{ host_id: string; bid: string }>("select b.host_id, b.id as bid from payments p join bookings b on b.id = p.booking_id where p.provider_session_id = $1", [s.id]);
        if (peek.rowCount === 0) return "unknown session";
        await lockHost(c, peek.rows[0].host_id);
        await c.query("update payments set status = 'failed' where provider_session_id = $1 and status = 'pending'", [s.id]);
        await c.query("update bookings set status = 'cancelled', cancelled_at = now(), cancel_reason = 'Payment not completed' where id = $1 and status = 'pending_payment'", [peek.rows[0].bid]);
        return "expired";
      }
      case "charge.refunded": {
        const ch = event.data.object as Stripe.Charge;
        const intent = typeof ch.payment_intent === "string" ? ch.payment_intent : ch.payment_intent?.id;
        if (intent && ch.refunded) await c.query("update payments set status = 'refunded' where provider_payment_id = $1", [intent]);
        return "refund recorded";
      }
      default:
        return "ignored";
    }
  });
  return { status: 200, body: outcome };
}
