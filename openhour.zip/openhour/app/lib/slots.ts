import { DateTime } from "luxon";
import type { Booking, EventType, Schedule, Slot } from "./types";

export interface SlotInput {
  eventType: EventType;
  schedule: Schedule;
  /** every live booking for this host, all event types */
  bookings: Booking[];
  now: Date;
  /** inclusive range of host-zone dates, "YYYY-MM-DD" */
  fromDate: string;
  toDate: string;
  /** a booking being moved: its own time must not block the new time */
  ignoreBookingId?: string;
  /** busy intervals read from the host's connected calendars (UTC instants) */
  busy?: { start: string; end: string }[];
}

const hm = (s: string) => {
  const [h, m] = s.split(":").map(Number);
  return { h, m };
};

/** A local wall-clock time in a zone as an instant, or null when that time does not exist (DST gap). */
function localToInstant(date: string, time: string, zone: string): DateTime | null {
  const [year, month, day] = date.split("-").map(Number);
  const { h, m } = hm(time);
  const dt = DateTime.fromObject({ year, month, day, hour: h, minute: m }, { zone });
  if (!dt.isValid || dt.hour !== h || dt.minute !== m) return null;
  return dt;
}

function windowsFor(schedule: Schedule, date: string): { start: string; end: string }[] {
  const overrides = schedule.overrides.filter((o) => o.date === date);
  if (overrides.length > 0) {
    return overrides.filter((o) => o.start && o.end).map((o) => ({ start: o.start!, end: o.end! }));
  }
  const dow = DateTime.fromISO(date, { zone: "UTC" }).weekday % 7; // luxon: Monday 1 .. Sunday 7
  return schedule.rules.filter((r) => r.dayOfWeek === dow).map((r) => ({ start: r.start, end: r.end }));
}

const overlaps = (aStart: number, aEnd: number, bStart: number, bEnd: number) => aStart < bEnd && bStart < aEnd;

/**
 * Open slots for an event type. Pure: no clock, no storage. The booking transaction runs this again and
 * only accepts a slot this function still returns, so the list is advice and this is the rule.
 */
export function generateSlots(input: SlotInput): Slot[] {
  const { eventType: et, schedule, now, fromDate, toDate, ignoreBookingId } = input;
  const zone = schedule.timeZone;
  const busy = (input.busy ?? []).map((b) => [Date.parse(b.start), Date.parse(b.end)] as const);
  const bookings = input.bookings.filter((b) => b.status !== "cancelled" && b.id !== ignoreBookingId);
  const dur = et.durationMin * 60_000;
  const earliest = now.getTime() + et.minNoticeMin * 60_000;
  const latest =
    et.rollingDays != null
      ? DateTime.fromJSDate(now, { zone }).startOf("day").plus({ days: et.rollingDays }).toMillis()
      : Infinity;

  const mine = bookings.filter((b) => b.eventTypeId === et.id);
  const countIn = (unit: "day" | "week" | "month", at: DateTime) => {
    const s = at.startOf(unit === "week" ? "week" : unit);
    const e = s.plus({ [unit === "week" ? "weeks" : unit === "day" ? "days" : "months"]: 1 });
    return mine.filter((b) => {
      const t = Date.parse(b.startAt);
      return t >= s.toMillis() && t < e.toMillis();
    }).length;
  };

  const out: Slot[] = [];
  let day = DateTime.fromISO(fromDate, { zone: "UTC" });
  const last = DateTime.fromISO(toDate, { zone: "UTC" });
  for (; day <= last; day = day.plus({ days: 1 })) {
    const date = day.toISODate()!;
    for (const w of windowsFor(schedule, date)) {
      const ws = localToInstant(date, w.start, zone);
      let we = localToInstant(date, w.end, zone);
      if (!ws) continue;
      if (!we) we = DateTime.fromObject({ ...day.toObject(), hour: hm(w.end).h, minute: hm(w.end).m }, { zone });
      const step = et.startIncrementMin * 60_000;
      for (let t = ws.toMillis(); t + dur <= we.toMillis(); t += step) {
        const end = t + dur;
        if (t < earliest || t >= latest) continue;

        const sameStart = mine.filter((b) => Date.parse(b.startAt) === t);
        const taken = sameStart.reduce((n, b) => n + b.invitees.length, 0);
        const isGroupJoin = et.kind === "group" && sameStart.length > 0;
        if (taken >= et.maxInvitees) continue;

        const bs = t - et.bufferBeforeMin * 60_000;
        const be = end + et.bufferAfterMin * 60_000;
        const blocked = bookings.some((b) => {
          if (isGroupJoin && b.eventTypeId === et.id && Date.parse(b.startAt) === t) return false;
          return overlaps(bs, be, Date.parse(b.startAt), Date.parse(b.endAt));
        });
        if (blocked) continue;
        if (busy.some(([bStart, bEnd]) => overlaps(bs, be, bStart, bEnd))) continue;

        if (!isGroupJoin) {
          const at = DateTime.fromMillis(t, { zone });
          if (et.limitPerDay != null && countIn("day", at) >= et.limitPerDay) continue;
          if (et.limitPerWeek != null && countIn("week", at) >= et.limitPerWeek) continue;
          if (et.limitPerMonth != null && countIn("month", at) >= et.limitPerMonth) continue;
        }

        out.push({ start: new Date(t).toISOString(), end: new Date(end).toISOString(), remaining: et.maxInvitees - taken });
      }
    }
  }
  return out.sort((a, b) => a.start.localeCompare(b.start));
}
