/** Mirrors replica/schema.sql, camelCased. Times are UTC ISO strings, dates are "YYYY-MM-DD", clock times "HH:mm". */

export type LocationType = "google_meet" | "zoom" | "phone_host" | "phone_invitee" | "in_person" | "custom";

export interface User {
  id: string;
  email: string;
  name: string;
  slug: string;
  timeZone: string;
  welcomeMessage: string | null;
}

export interface WeeklyRule {
  /** 0 = Sunday */
  dayOfWeek: number;
  start: string;
  end: string;
}

export interface DateOverride {
  date: string;
  /** both null = unavailable all day */
  start: string | null;
  end: string | null;
}

export interface Schedule {
  id: string;
  userId: string;
  name: string;
  timeZone: string;
  isDefault: boolean;
  rules: WeeklyRule[];
  overrides: DateOverride[];
}

export interface EventType {
  id: string;
  userId: string;
  scheduleId: string;
  kind: "one_on_one" | "group";
  name: string;
  slug: string;
  description: string | null;
  /** 1..8, an index into the event-N colour tokens */
  colorIndex: number;
  durationMin: number;
  maxInvitees: number;
  locationType: LocationType;
  locationValue: string | null;
  bufferBeforeMin: number;
  bufferAfterMin: number;
  minNoticeMin: number;
  rollingDays: number | null;
  startIncrementMin: number;
  limitPerDay: number | null;
  limitPerWeek: number | null;
  limitPerMonth: number | null;
  confirmationMessage: string | null;
  requirePayment: boolean;
  priceCents: number | null;
  currency: string | null;
  active: boolean;
  hidden: boolean;
}

export interface Invitee {
  id: string;
  name: string;
  email: string;
  timeZone: string;
  answers: Record<string, string>;
  /** sha256 hex of the token in the email link; the token itself is never stored */
  manageTokenHash: string;
  noShow: boolean;
}

export interface Booking {
  id: string;
  eventTypeId: string;
  hostId: string;
  startAt: string;
  endAt: string;
  status: "pending_payment" | "confirmed" | "cancelled";
  meetingUrl: string | null;
  cancelReason: string | null;
  rescheduledFrom: string | null;
  createdAt: string;
  invitees: Invitee[];
}

export interface Slot {
  /** UTC instant */
  start: string;
  end: string;
  /** open places left (always 1 for one-on-one) */
  remaining: number;
}

export const LOCATION_LABELS: Record<LocationType, string> = {
  google_meet: "Google Meet",
  zoom: "Zoom",
  phone_host: "Host calls the guest",
  phone_invitee: "Guest calls the host",
  in_person: "In person",
  custom: "Custom",
};
