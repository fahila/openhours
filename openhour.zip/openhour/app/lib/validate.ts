import type { EventType, LocationType, Schedule } from "./types";

export type Errors<T extends string = string> = Partial<Record<T, string>>;

export const RESERVED_SLUGS = new Set([
  "api", "login", "signup", "onboarding", "event-types", "meetings", "availability", "integrations", "workflows",
  "routing", "contacts", "settings", "admin", "single-use-links", "polls", "m", "s", "p", "booked", "reschedule", "privacy", "left", "design", "dev", "_next",
]);

const LOCATIONS: LocationType[] = ["google_meet", "zoom", "phone_host", "phone_invitee", "in_person", "custom"];
export const SLUG_RE = /^[a-z0-9][a-z0-9-]{0,58}$/;
export const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
/** "2026-13-45" looks like a date and is not one. Checked against the real calendar, so it never reaches the database. */
export const isRealDate = (s: string) => {
  if (!DATE_RE.test(s)) return false;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
};
export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const CURRENCIES = ["usd", "eur", "gbp", "cad", "aud", "inr", "sgd"];

/** A single line of text: control characters (including NUL, which Postgres rejects) and line breaks become spaces. */
export const cleanLine = (s: string) => s.replace(/[\u0000-\u001f\u007f\u2028\u2029]+/g, " ").replace(/\s{2,}/g, " ").trim();
/** Free text may keep its line breaks and tabs, but not NUL or other control characters. */
export const cleanText = (s: string) => s.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "");

/** First of `base`, `base-2`, `base-3`... that is not in `taken`, kept inside the 59 character limit. */
export function pickFreeSlug(base: string, taken: ReadonlySet<string>): string {
  const root = base || "event";
  if (!taken.has(root)) return root;
  for (let n = 2; n < 1000; n++) {
    const suffix = `-${n}`;
    const candidate = root.slice(0, 59 - suffix.length).replace(/-+$/, "") + suffix;
    if (!taken.has(candidate)) return candidate;
  }
  throw new Error("no free link name");
}

export const slugify = (s: string) =>
  s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 59);

const intOrNull = (v: FormDataEntryValue | null): number | null => {
  const s = String(v ?? "").trim();
  if (s === "") return null;
  const n = Number(s);
  return Number.isInteger(n) ? n : NaN;
};

export type EventTypeInput = Omit<EventType, "id" | "userId" | "active" | "hidden">;

export function parseEventType(fd: FormData): { value?: EventTypeInput; errors: Errors } {
  const errors: Errors = {};
  const name = cleanLine(String(fd.get("name") ?? ""));
  if (!name) errors.name = "Give this event a name.";
  else if (name.length > 120) errors.name = "Keep the name under 120 characters.";

  const typedSlug = String(fd.get("slug") ?? "").trim().toLowerCase();
  const slug = typedSlug || slugify(name) || "event"; // emoji-only names have nothing to build a link from
  if (!SLUG_RE.test(slug)) errors.slug = "Use lowercase letters, numbers and dashes.";

  const durationMin = intOrNull(fd.get("durationMin"));
  if (durationMin == null || Number.isNaN(durationMin) || durationMin < 5 || durationMin > 720) errors.durationMin = "Choose between 5 and 720 minutes.";

  const kind = fd.get("kind") === "group" ? "group" : "one_on_one";
  let maxInvitees = intOrNull(fd.get("maxInvitees")) ?? 1;
  if (kind === "one_on_one") maxInvitees = 1;
  else if (Number.isNaN(maxInvitees) || maxInvitees < 2 || maxInvitees > 500) errors.maxInvitees = "A group needs between 2 and 500 places.";

  const locationType = String(fd.get("locationType")) as LocationType;
  if (!LOCATIONS.includes(locationType)) errors.locationType = "Pick where the meeting happens.";
  const locationValue = cleanLine(String(fd.get("locationValue") ?? "")) || null;
  if ((locationType === "in_person" || locationType === "custom") && !locationValue) errors.locationValue = "Add the address or details guests need.";

  const num = (key: string, min: number, max: number, label: string, orNull = false) => {
    const v = intOrNull(fd.get(key));
    if (v == null) {
      if (orNull) return null;
      errors[key] = `Enter ${label}.`;
      return 0;
    }
    if (Number.isNaN(v) || v < min || v > max) { errors[key] = `Use a whole number from ${min} to ${max}.`; return 0; }
    return v;
  };
  const bufferBeforeMin = num("bufferBeforeMin", 0, 240, "a buffer, 0 for none") ?? 0;
  const bufferAfterMin = num("bufferAfterMin", 0, 240, "a buffer, 0 for none") ?? 0;
  const minNoticeMin = num("minNoticeMin", 0, 60 * 24 * 90, "a notice period, 0 for none") ?? 0;
  const rollingDays = num("rollingDays", 1, 365, "days", true);
  const limitPerDay = num("limitPerDay", 1, 100, "a limit", true);
  const limitPerWeek = num("limitPerWeek", 1, 500, "a limit", true);
  const limitPerMonth = num("limitPerMonth", 1, 1000, "a limit", true);
  const startIncrementMin = Number(fd.get("startIncrementMin"));
  if (![5, 10, 15, 20, 30, 60].includes(startIncrementMin)) errors.startIncrementMin = "Choose a start interval from the list.";

  const colorIndex = Number(fd.get("colorIndex"));
  if (!Number.isInteger(colorIndex) || colorIndex < 1 || colorIndex > 8) errors.colorIndex = "Pick a colour.";

  const requirePayment = fd.get("requirePayment") === "on";
  const currency = String(fd.get("currency") ?? "usd").toLowerCase();
  let priceCents: number | null = null;
  if (requirePayment) {
    if (kind !== "one_on_one") errors.requirePayment = "Payment works for one guest at a time, not group events.";
    if (!CURRENCIES.includes(currency)) errors.currency = "Pick a currency from the list.";
    const price = Number(String(fd.get("price") ?? "").replace(",", "."));
    if (!Number.isFinite(price) || price < 0.5 || price > 10000) errors.price = "Enter a price between 0.50 and 10,000.";
    else priceCents = Math.round(price * 100);
  }

  const scheduleId = String(fd.get("scheduleId") ?? "");
  if (!scheduleId) errors.scheduleId = "Choose the hours this event uses.";

  if (Object.keys(errors).length) return { errors };
  return {
    errors,
    value: {
      scheduleId, kind, name, slug, description: cleanText(String(fd.get("description") ?? "")).trim() || null, colorIndex,
      durationMin: durationMin!, maxInvitees, locationType, locationValue, bufferBeforeMin, bufferAfterMin, minNoticeMin,
      rollingDays, startIncrementMin, limitPerDay, limitPerWeek, limitPerMonth,
      confirmationMessage: cleanText(String(fd.get("confirmationMessage") ?? "")).trim() || null,
      requirePayment, priceCents, currency: requirePayment ? currency : null,
    },
  };
}

export function validateSchedule(s: Pick<Schedule, "name" | "timeZone" | "rules" | "overrides">): Errors {
  const errors: Errors = {};
  if (!s.name.trim()) errors.name = "Name these hours.";
  try { new Intl.DateTimeFormat("en", { timeZone: s.timeZone }); } catch { errors.timeZone = "That time zone is not recognised."; }
  const byDay = new Map<number, [string, string][]>();
  for (const r of s.rules) {
    if (!TIME_RE.test(r.start) || !TIME_RE.test(r.end) || r.end <= r.start) { errors.rules = "Each range must end after it starts."; continue; }
    byDay.set(r.dayOfWeek, [...(byDay.get(r.dayOfWeek) ?? []), [r.start, r.end]]);
  }
  for (const ranges of byDay.values()) {
    const sorted = [...ranges].sort();
    for (let i = 1; i < sorted.length; i++) if (sorted[i][0] < sorted[i - 1][1]) errors.rules = "Ranges on the same day can't overlap.";
  }
  for (const o of s.overrides) {
    if (!isRealDate(o.date)) errors.overrides = "Use a valid date.";
    if ((o.start == null) !== (o.end == null) || (o.start && o.end && (!TIME_RE.test(o.start) || !TIME_RE.test(o.end) || o.end <= o.start))) {
      errors.overrides = "Each override needs a start before its end, or none for a day off.";
    }
  }
  return errors;
}
