import { z } from "zod";
import { isRealDate, TIME_RE } from "./validate";

/** Shapes accepted from the outside world. Everything is bounded, so a hostile client cannot send megabytes. */

const instant = z.string().min(10).max(40);

export const bookBody = z.object({
  startAt: instant,
  name: z.string().max(200),
  email: z.string().max(320),
  timeZone: z.string().max(64),
  answers: z.record(z.string().max(60), z.string().max(2000)).refine((o) => Object.keys(o).length <= 20, "Too many answers").optional(),
});

export const cancelBody = z.object({ reason: z.string().max(500).nullish() });
export const rescheduleBody = z.object({ startAt: instant });

export const slotsQuery = z.object({
  from: z.string().refine(isRealDate, "Not a real date"),
  to: z.string().refine(isRealDate, "Not a real date"),
  reschedule: z.string().max(100).nullish(),
});

const time = z.string().regex(TIME_RE);
export const schedulePayload = z.object({
  name: z.string().max(120),
  timeZone: z.string().max(64),
  rules: z.array(z.object({ dayOfWeek: z.number().int().min(0).max(6), start: time, end: time })).max(100),
  overrides: z.array(z.object({ date: z.string().refine(isRealDate, "Not a real date"), start: time.nullable(), end: time.nullable() })).max(400),
});

export const uuid = z.string().uuid();
export const hostCancel = z.object({ bookingId: uuid, reason: z.string().max(500) });
export const calendarFlags = z.object({ id: uuid, checkConflicts: z.boolean().optional(), isBookingTarget: z.boolean().optional() });

/** First message per field, in the same shape the forms use. */
export function fieldErrors(e: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const i of e.issues) out[i.path.join(".") || "_"] ??= i.message;
  return out;
}
