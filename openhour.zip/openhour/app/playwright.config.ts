import { defineConfig } from "@playwright/test";
import { BASE } from "./e2e/env.mjs";

export default defineConfig({
  testDir: "e2e/specs",
  // One database and one mock server are shared, so tests run one at a time and each starts from a clean slate.
  workers: 1,
  fullyParallel: false,
  retries: 0,
  timeout: 90_000,
  expect: { timeout: 15_000 },
  reporter: [["list"], ["html", { open: "never", outputFolder: "e2e/report" }]],
  outputDir: "e2e/results",
  use: {
    baseURL: BASE,
    locale: "en-US",
    timezoneId: "America/New_York",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    launchOptions: { executablePath: process.env.PLAYWRIGHT_CHROMIUM ?? "/opt/pw-browsers/chromium" },
  },
  webServer: {
    command: "node e2e/stack.mjs",
    url: `${BASE}/login`,
    reuseExistingServer: !process.env.CI,
    timeout: 240_000,
    stdout: "ignore",
    stderr: "pipe",
  },
});
