/**
 * Runs once when the server starts. Validating the environment here means a deploy with a missing or malformed
 * variable crashes immediately and loudly, instead of starting "healthy" and failing on the first request.
 * Skipped during `next build`, which has no runtime secrets.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs" || process.env.NEXT_PHASE === "phase-production-build") return;
  const { env } = await import("./lib/env");
  env();
}
