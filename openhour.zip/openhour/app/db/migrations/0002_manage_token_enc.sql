-- Emails (confirmations, reminders) must contain the guest's cancel and reschedule link, but only a hash of the
-- token was stored. Keep the token encrypted (AES-256-GCM, key in APP_ENCRYPTION_KEY) so the background job can
-- rebuild the link. The hash stays as the lookup key. Older rows without it simply get emails without the link.
alter table booking_invitees add column manage_token_enc bytea;
