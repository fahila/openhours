-- Schema for a self-hosted scheduling app (own use). Postgres 15+ (needs UNIQUE NULLS NOT DISTINCT).
-- Source of truth: this file replaces replica/schema.sql. Run with `npm run db:migrate`.
-- Access rules: data-layer checks. Every owner-scoped query takes the signed-in
-- user_id. Public guest routes use hashed random tokens and only reach the one
-- row the token names. No RLS (guests are anonymous).
-- All times are timestamptz stored in UTC. Weekly rules are local wall-clock
-- times in the schedule's IANA time zone, expanded at slot-generation time so
-- DST is handled there.

create extension if not exists btree_gist;
create extension if not exists pgcrypto;

create function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- users (owner of everything). A team/org layer can be added later by adding
-- organizations + memberships and an org_id column; nothing here blocks it.
create table users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  name text not null,
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,38}$'),
  time_zone text not null default 'UTC',
  welcome_message text,
  brand_logo_url text,
  brand_color text check (brand_color is null or brand_color ~ '^#[0-9a-fA-F]{6}$'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Auth.js adapter tables (accounts for Google sign-in, sessions) live in the
-- auth library's own migration. Keep them out of this file.

create table calendar_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  provider text not null check (provider in ('google','outlook')),
  provider_account_id text not null,
  email text not null,
  refresh_token_enc bytea not null,          -- encrypted with app key, never plaintext
  scopes text[] not null default '{}',
  status text not null default 'active' check (status in ('active','needs_reauth','revoked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, provider, provider_account_id)
);
create index on calendar_connections (user_id);

create table calendars (
  id uuid primary key default gen_random_uuid(),
  connection_id uuid not null references calendar_connections(id) on delete cascade,
  provider_calendar_id text not null,
  name text not null,
  check_conflicts boolean not null default false,   -- read busy times
  is_booking_target boolean not null default false, -- write new bookings here
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (connection_id, provider_calendar_id)
);
create index on calendars (connection_id);
-- at most one booking target per user is enforced in the data layer (it spans a join)

create table availability_schedules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  time_zone text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on availability_schedules (user_id);
create unique index one_default_schedule on availability_schedules (user_id) where is_default;

create table availability_rules (
  id uuid primary key default gen_random_uuid(),
  schedule_id uuid not null references availability_schedules(id) on delete cascade,
  day_of_week smallint not null check (day_of_week between 0 and 6),  -- 0 = Sunday
  start_time time not null,
  end_time time not null,
  check (end_time > start_time)
);
create index on availability_rules (schedule_id, day_of_week);

create table date_overrides (
  id uuid primary key default gen_random_uuid(),
  schedule_id uuid not null references availability_schedules(id) on delete cascade,
  on_date date not null,
  start_time time,            -- both null = unavailable all day
  end_time time,
  check ((start_time is null and end_time is null) or (start_time is not null and end_time > start_time))
);
create index on date_overrides (schedule_id, on_date);

create table event_types (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  schedule_id uuid not null references availability_schedules(id) on delete restrict,
  kind text not null default 'one_on_one' check (kind in ('one_on_one','group')),
  name text not null,
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,58}$'),
  description text,
  color_index smallint not null default 1 check (color_index between 1 and 8),
  duration_min integer not null check (duration_min between 5 and 720),
  max_invitees integer not null default 1 check (max_invitees >= 1),
  location_type text not null check (location_type in ('google_meet','zoom','phone_host','phone_invitee','in_person','custom')),
  location_value text,
  buffer_before_min integer not null default 0 check (buffer_before_min >= 0),
  buffer_after_min integer not null default 0 check (buffer_after_min >= 0),
  min_notice_min integer not null default 240 check (min_notice_min >= 0),
  rolling_days integer check (rolling_days is null or rolling_days > 0),   -- null = use fixed range
  range_start date,
  range_end date,
  start_increment_min integer not null default 30 check (start_increment_min in (5,10,15,20,30,60)),
  limit_per_day integer check (limit_per_day is null or limit_per_day > 0),
  limit_per_week integer check (limit_per_week is null or limit_per_week > 0),
  limit_per_month integer check (limit_per_month is null or limit_per_month > 0),
  confirmation_message text,
  redirect_url text,
  require_payment boolean not null default false,
  price_cents integer check (price_cents is null or price_cents >= 0),
  currency char(3),
  active boolean not null default true,
  hidden boolean not null default false,      -- reachable by link, not listed on profile
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, slug),
  check (kind = 'group' or max_invitees = 1),
  check (range_end is null or range_start is null or range_end >= range_start),
  check (not require_payment or (price_cents is not null and currency is not null))
);
create index on event_types (user_id);
create index on event_types (schedule_id);

create table invitee_questions (
  id uuid primary key default gen_random_uuid(),
  event_type_id uuid not null references event_types(id) on delete cascade,
  label text not null,
  type text not null check (type in ('text','textarea','select','radio','checkbox','phone')),
  options text[] not null default '{}',
  required boolean not null default false,
  position integer not null default 0
);
create index on invitee_questions (event_type_id, position);

-- free/busy exceptions: busy events whose title matches may be booked over
create table free_busy_exceptions (
  id uuid primary key default gen_random_uuid(),
  event_type_id uuid not null references event_types(id) on delete cascade,
  title_match text not null
);
create index on free_busy_exceptions (event_type_id);

-- A booking is a meeting on the host's calendar. A group event is ONE booking
-- with several booking_invitees, so the host-level exclusion constraint holds.
create table bookings (
  id uuid primary key default gen_random_uuid(),
  event_type_id uuid not null references event_types(id) on delete restrict,
  host_id uuid not null references users(id) on delete cascade,
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text not null default 'confirmed' check (status in ('pending_payment','confirmed','cancelled')),
  location_details text,
  provider_event_id text,                    -- id of the event written to the host's calendar
  meeting_url text,
  cancelled_at timestamptz,
  cancel_reason text,
  rescheduled_from uuid references bookings(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint no_zero_length check (end_at > start_at),
  -- a host cannot hold two live bookings that overlap in time
  constraint no_host_overlap exclude using gist (
    host_id with =,
    tstzrange(start_at, end_at, '[)') with &&
  ) where (status in ('pending_payment','confirmed'))
);
create index on bookings (host_id, start_at);
create index on bookings (event_type_id, start_at);
create index on bookings (rescheduled_from);

create table booking_invitees (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  name text not null,
  email text not null,
  time_zone text not null,
  is_primary boolean not null default true,
  answers jsonb not null default '{}',
  manage_token_hash bytea not null unique,   -- sha256 of the token in the email link
  no_show boolean not null default false,
  created_at timestamptz not null default now(),
  unique (booking_id, email)
);
create index on booking_invitees (booking_id);
create index on booking_invitees (lower(email));

create table single_use_links (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  event_type_id uuid not null references event_types(id) on delete cascade,
  token_hash bytea not null unique,
  status text not null default 'created' check (status in ('created','viewed','booked','expired')),
  offered_slots jsonb,                        -- null = normal availability; else [{start,end}] one-off times
  booking_id uuid references bookings(id) on delete set null,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on single_use_links (user_id);
create index on single_use_links (event_type_id);

create table workflows (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  trigger text not null check (trigger in ('on_booked','on_cancelled','before_event','after_event')),
  offset_min integer not null default 0 check (offset_min >= 0),
  channel text not null default 'email' check (channel in ('email','sms')),
  subject text,
  body text not null,
  include_manage_links boolean not null default true,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on workflows (user_id);

create table workflow_event_types (
  workflow_id uuid not null references workflows(id) on delete cascade,
  event_type_id uuid not null references event_types(id) on delete cascade,
  primary key (workflow_id, event_type_id)
);
create index on workflow_event_types (event_type_id);

-- Scheduled sends. The unique key makes reminders idempotent: retrying the job
-- cannot send the same message twice.
create table message_log (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  invitee_id uuid references booking_invitees(id) on delete cascade,
  workflow_id uuid references workflows(id) on delete set null,
  kind text not null,                         -- confirmation, cancellation, reminder, follow_up
  channel text not null check (channel in ('email','sms')),
  status text not null default 'queued' check (status in ('queued','sent','failed')),
  provider_message_id text,
  error text,
  created_at timestamptz not null default now(),
  sent_at timestamptz,
  unique nulls not distinct (booking_id, invitee_id, workflow_id, kind)
);
create index on message_log (booking_id);

create table payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete restrict,
  provider text not null default 'stripe' check (provider in ('stripe','paypal')),
  provider_session_id text not null unique,
  provider_payment_id text unique,
  amount_cents integer not null check (amount_cents >= 0),
  currency char(3) not null,
  status text not null default 'pending' check (status in ('pending','paid','refunded','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on payments (booking_id);

create table meeting_polls (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  title text not null,
  duration_min integer not null check (duration_min > 0),
  token_hash bytea not null unique,
  status text not null default 'open' check (status in ('open','closed')),
  booking_id uuid references bookings(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on meeting_polls (user_id);

create table poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references meeting_polls(id) on delete cascade,
  start_at timestamptz not null
);
create index on poll_options (poll_id, start_at);

create table poll_votes (
  option_id uuid not null references poll_options(id) on delete cascade,
  voter_email text not null,
  voter_name text not null,
  created_at timestamptz not null default now(),
  primary key (option_id, voter_email)
);

create table webhook_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  url text not null check (url ~ '^https://'),
  events text[] not null check (events <@ array['invitee.created','invitee.cancelled','invitee.rescheduled']::text[]),
  signing_secret_enc bytea not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on webhook_subscriptions (user_id);

create table webhook_deliveries (
  id uuid primary key default gen_random_uuid(),
  subscription_id uuid not null references webhook_subscriptions(id) on delete cascade,
  event text not null,
  booking_id uuid references bookings(id) on delete set null,
  payload jsonb not null,
  attempt integer not null default 0,
  status text not null default 'pending' check (status in ('pending','delivered','failed')),
  response_code integer,
  next_attempt_at timestamptz,
  created_at timestamptz not null default now(),
  unique nulls not distinct (subscription_id, event, booking_id)   -- idempotent enqueue
);
create index on webhook_deliveries (status, next_attempt_at);

create table api_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  name text not null,
  token_hash bytea not null unique,
  last_used_at timestamptz,
  created_at timestamptz not null default now()
);
create index on api_tokens (user_id);

-- Provider webhooks (Stripe, Google push) are deduplicated here
create table inbound_events (
  provider text not null,
  event_id text not null,
  received_at timestamptz not null default now(),
  primary key (provider, event_id)
);


-- ---------------------------------------------------------------------------
-- sign-in and sessions

-- One row per way a person can sign in. Today only Google.
create table login_identities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  provider text not null check (provider in ('google')),
  provider_user_id text not null,
  created_at timestamptz not null default now(),
  unique (provider, provider_user_id)
);
create index on login_identities (user_id);

-- Cookie holds a random token; only its sha256 is stored.
create table sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  token_hash bytea not null unique,
  user_agent text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index on sessions (user_id);
create index on sessions (expires_at);

-- ---------------------------------------------------------------------------
-- background jobs. Enqueued in the same transaction as the change that needs
-- them, so a booking and its confirmation email can never get out of step.

create table jobs (
  id uuid primary key default gen_random_uuid(),
  kind text not null,
  payload jsonb not null default '{}',
  run_at timestamptz not null default now(),
  status text not null default 'queued' check (status in ('queued','running','done','dead')),
  attempts integer not null default 0,
  max_attempts integer not null default 6,
  last_error text,
  dedupe_key text unique,                      -- enqueue twice, run once
  locked_at timestamptz,
  created_at timestamptz not null default now(),
  finished_at timestamptz
);
create index jobs_due on jobs (run_at) where status = 'queued';
create index on jobs (status, finished_at);

do $$
declare t text;
begin
  for t in select table_name from information_schema.columns
           where table_schema = 'public' and column_name = 'updated_at'
  loop
    execute format('create trigger set_updated_at before update on %I
                    for each row execute function set_updated_at()', t);
  end loop;
end $$;
