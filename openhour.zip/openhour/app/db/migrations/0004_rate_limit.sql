-- Rate limits live in the database so they hold across several server instances and restarts.
create table rate_limit_hits (
  key text not null,
  at timestamptz not null default now()
);
create index on rate_limit_hits (key, at);
