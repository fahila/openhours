-- Remember which calendar a booking's event was written to, so cancelling still deletes it
-- after the host changes their "write bookings to" calendar.
alter table bookings add column provider_calendar_id text;
