import { test as base, expect, type Browser, type BrowserContext, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import pg from "pg";
import { DateTime } from "luxon";
import { BASE, CRON, DATABASE_URL, MOCK } from "./env.mjs";

export { expect, BASE, MOCK, CRON };

// ---- database and mock helpers ---------------------------------------------------------------

let pool: pg.Pool | null = null;
export const db = () => (pool ??= new pg.Pool({ connectionString: DATABASE_URL, max: 4 }));
export const sql = async <T = Record<string, any>>(q: string, p: unknown[] = []): Promise<T[]> => (await db().query(q, p)).rows as T[];

export const mockState = async () => (await fetch(`${MOCK}/__state`)).json() as Promise<{
  emails: { to: string[]; subject: string; text: string; html: string; attachments?: { filename: string; content: string; content_type: string }[]; idempotencyKey?: string; from: string }[];
  stripe: { sessions: Record<string, { success_url: string; cancel_url: string; booking_id: string; amount: string; currency: string; payment_status: string }>; expired: string[]; refunds: string[] };
  google: { events: { id: string; calendarId: string; body: Record<string, any> }[]; deleted: string[]; revoked: string[] };
}>;
export const mockControl = (patch: Record<string, unknown>) => fetch(`${MOCK}/__control`, { method: "POST", body: JSON.stringify(patch) });
export const emailsTo = async (addr: string) => (await mockState()).emails.filter((e) => e.to[0] === addr);

export async function until<T>(fn: () => Promise<T | false | null | undefined>, ms = 20_000, label = "condition"): Promise<T> {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error(`timed out waiting for ${label}`);
    await new Promise((r) => setTimeout(r, 250));
  }
}

export const runJobs = (secret = CRON) => fetch(`${BASE}/api/jobs/run`, { method: "POST", headers: { Authorization: `Bearer ${secret}` } });
/**
 * Run background jobs until the queue is quiet. The app also runs jobs by itself right after a booking, so a single
 * call can find nothing to do while that run is still sending; waiting for "nothing queued, nothing running" avoids
 * reading the inbox too early. Retries are pulled forward; jobs scheduled for later (reminders, payment holds) only
 * when the test names them in `future`.
 */
export type FutureKind = "workflow.send" | "payment.expire" | "payment.refund";
export async function flushJobs(o: { future?: FutureKind[] } = {}) {
  const future = o.future ?? [];
  let last: { ran: number; failed: number; dead: number } = { ran: 0, failed: 0, dead: 0 };
  for (let i = 0; i < 40; i++) {
    await sql("update jobs set run_at = now() where status = 'queued' and (attempts > 0 or kind not in ('workflow.send', 'payment.expire') or kind = any($1))", [future]);
    const r = await runJobs();
    const stats = (await r.json()) as typeof last;
    last = { ran: last.ran + stats.ran, failed: last.failed + stats.failed, dead: last.dead + stats.dead };
    const [busy] = await sql<{ n: number }>("select count(*)::int as n from jobs where status = 'running' or (status = 'queued' and (attempts > 0 or kind not in ('workflow.send', 'payment.expire') or kind = any($1)))", [future]);
    if (busy.n === 0) break;
    await new Promise((res) => setTimeout(res, 150));
  }
  return last;
}

/** Every test starts from empty tables and a fresh mock. */
export async function resetAll() {
  await sql("truncate users, rate_limit_hits, jobs, inbound_events restart identity cascade");
  await fetch(`${MOCK}/__reset`, { method: "POST" });
}

// ---- watching for trouble ------------------------------------------------------------------------

export interface Allowed { status: number[]; console: RegExp[] }

/** Collected problems: console errors, uncaught page errors and any 5xx response. A test says what it expects by adding to `allowed`. */
function watch(page: Page, problems: string[], allowed: Allowed, label = "page") {
  // Client components attach their handlers when React hydrates. Typing into a controlled field before that loses the
  // value on the first re-render, which makes tests flaky for a reason no real visitor hits. Wait for the page to settle.
  const goto = page.goto.bind(page);
  page.goto = (async (url: string, opts?: Parameters<Page["goto"]>[1]) => {
    const r = await goto(url, opts);
    if (opts?.waitUntil === "commit") return r; // a test that wants to watch the page while it loads asks for this
    await page.waitForLoadState("networkidle").catch(() => {});
    return r;
  }) as Page["goto"];
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    const t = m.text();
    if (/Failed to load resource: the server responded with a status of 4\d\d/.test(t)) return; // expected refusals are tracked by status, not by this line
    if (allowed.console.some((re) => re.test(t))) return;
    problems.push(`[${label}] console error: ${t}`);
  });
  page.on("pageerror", (e) => problems.push(`[${label}] uncaught: ${e.message}`));
  page.on("response", (r) => {
    if (r.status() >= 500 && !allowed.status.includes(r.status()) && !r.url().includes("/_next/")) problems.push(`[${label}] ${r.status()} on ${r.request().method()} ${r.url()}`);
  });
}

// ---- guests and hosts ------------------------------------------------------------------------------

export interface Host { id: string; slug: string; email: string }

type Fixtures = {
  allowed: Allowed;
  problems: string[];
  /** A signed-in host in New York with the starter hours. */
  host: { page: Page; user: Host };
  /** Open another browser identity: a guest in the given time zone, or a second host. */
  newPage: (opts?: { tz?: string; width?: number; height?: number; offline?: boolean }) => Promise<Page>;
  login: (page: Page, opts?: { email?: string; name?: string; sub?: string }) => Promise<Host>;
  axe: (page: Page, label?: string) => Promise<void>;
};

export const test = base.extend<Fixtures>({
  allowed: async ({}, use) => { await use({ status: [], console: [] }); },
  problems: async ({}, use) => { await use([]); },

  page: async ({ page, problems, allowed }, use) => {
    await resetAll();
    watch(page, problems, allowed, "host");
    await use(page);
    expect(problems, "no console errors, uncaught errors or 5xx responses").toEqual([]);
  },

  login: async ({}, use) => {
    await use(async (page, opts = {}) => {
      const email = opts.email ?? "owner@example.com";
      await mockControl({ profile: { email, email_verified: true, sub: opts.sub ?? "g-" + email, name: opts.name ?? "Sam Rivera" } });
      await page.goto("/login");
      await page.getByRole("link", { name: "Continue with Google" }).click();
      await page.waitForURL("**/event-types", { timeout: 60_000 });
      const [u] = await sql<{ id: string; slug: string }>("select id, slug from users where email = $1", [email.toLowerCase()]);
      return { id: u.id, slug: u.slug, email: email.toLowerCase() };
    });
  },

  host: async ({ page, login }, use) => {
    const user = await login(page);
    // the account starts in UTC; the browser is in New York, so move both to New York and pick a short link name
    const slug = "sam";
    await sql("update users set time_zone = 'America/New_York', slug = $2 where id = $1", [user.id, slug]);
    await sql("update availability_schedules set time_zone = 'America/New_York' where user_id = $1", [user.id]);
    await use({ page, user: { ...user, slug } });
  },

  newPage: async ({ browser, problems, allowed }, use) => {
    const contexts: BrowserContext[] = [];
    await use(async (opts = {}) => {
      const ctx = await browser.newContext({
        timezoneId: opts.tz ?? "Asia/Kolkata", locale: "en-US", viewport: { width: opts.width ?? 1280, height: opts.height ?? 900 }, offline: opts.offline,
      });
      contexts.push(ctx);
      const p = await ctx.newPage();
      watch(p, problems, allowed, "guest");
      return p;
    });
    for (const c of contexts) await c.close();
  },

  axe: async ({}, use) => {
    await use(async (page, label = "page") => {
      const r = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa", "best-practice"]).analyze();
      expect(r.violations.map((v) => `${v.id} (${v.nodes.length}): ${v.nodes[0].html.slice(0, 110)}`), `axe violations on ${label}`).toEqual([]);
    });
  },
});

// ---- dates and API shortcuts ---------------------------------------------------------------------------

/** The next weekday that is at least `minDays` away, as a host-zone date. */
export function weekdayAhead(minDays = 9, zone = "America/New_York") {
  let d = DateTime.now().setZone(zone).plus({ days: minDays });
  while (d.weekday > 5) d = d.plus({ days: 1 });
  return d;
}

export interface Slot { start: string; remaining: number }
export async function apiSlots(hostSlug: string, event: string, from: string, to: string, headers: Record<string, string> = {}) {
  const r = await fetch(`${BASE}/api/public/${hostSlug}/${event}/slots?from=${from}&to=${to}`, { headers });
  return { status: r.status, slots: ((await r.json().catch(() => ({}))) as { slots?: Slot[] }).slots ?? [] };
}

let ipCounter = 10;
/** Book through the public API like a guest would. Each call uses its own fake client address so rate limits stay out of the way. */
export async function apiBook(hostSlug: string, event: string, o: { name?: string; email?: string; tz?: string; day?: DateTime; idx?: number; notes?: string; ip?: string } = {}) {
  const day = (o.day ?? weekdayAhead()).toISODate()!;
  const { slots } = await apiSlots(hostSlug, event, day, day);
  if (!slots.length) throw new Error(`no slots on ${day}`);
  const slot = slots[o.idx ?? 0];
  const email = o.email ?? `guest${ipCounter}@example.com`;
  const r = await fetch(`${BASE}/api/public/${hostSlug}/${event}/book`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-forwarded-for": o.ip ?? `198.51.100.${ipCounter++ % 250}` },
    body: JSON.stringify({ startAt: slot.start, name: o.name ?? "Test Guest", email, timeZone: o.tz ?? "Europe/London", answers: o.notes ? { notes: o.notes } : {} }),
  });
  const body = (await r.json().catch(() => ({}))) as { manageToken?: string; checkoutUrl?: string; error?: string; message?: string };
  return { status: r.status, token: body.manageToken, checkoutUrl: body.checkoutUrl, slot, email, body };
}

/** Click through the public booking page: pick the nth open day, the nth time, fill the form. Stops before submitting. */
export async function fillBooking(page: Page, o: { dayIndex?: number; slotIndex?: number; name?: string; email?: string; notes?: string } = {}) {
  await page.waitForSelector('button[data-day]:not([aria-disabled="true"])', { timeout: 60_000 });
  await page.locator('button[data-day]:not([aria-disabled="true"])').nth(o.dayIndex ?? 1).click();
  await page.locator('ul[aria-label="Available times"] button').nth(o.slotIndex ?? 0).click();
  await page.getByLabel(/^Name/).fill(o.name ?? "Ann Guest");
  await page.getByLabel(/^Email/).fill(o.email ?? "ann@example.com");
  if (o.notes) await page.getByLabel(/^Anything to share/).fill(o.notes);
}

export const noHorizontalScroll = (page: Page) => page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth);
export type { Browser };
