/**
 * Starts everything the browser tests need and stays running until stopped (Playwright's webServer runs this):
 * a fresh Postgres database, a local mock of Google + Resend + Stripe, and the Next dev server pointed at both.
 * Needs a reachable Postgres server: TEST_PG=postgres://user@host:port
 */
import { spawn } from "node:child_process";
import pg from "pg";
import { APP_PORT, BASE, CRON, DATABASE_URL, DB_NAME, KEY, MOCK, MOCK_PORT, PG, WEBHOOK_SECRET } from "./env.mjs";

const procs = [];
function start(cmd, args, env, tag) {
  const p = spawn(cmd, args, { env: { ...process.env, ...env }, stdio: ["ignore", "pipe", "pipe"], detached: true });
  p.stdout.on("data", (d) => process.stdout.write(`[${tag}] ${d}`));
  p.stderr.on("data", (d) => process.stderr.write(`[${tag}] ${d}`));
  procs.push(p);
  return p;
}
const stop = () => { for (const p of procs) { try { process.kill(-p.pid, "SIGTERM"); } catch { /* gone */ } } };
process.on("SIGTERM", () => { stop(); process.exit(0); });
process.on("SIGINT", () => { stop(); process.exit(0); });
process.on("exit", stop);

const admin = new pg.Client({ connectionString: `${PG}/postgres` });
await admin.connect();
await admin.query(`drop database if exists ${DB_NAME} with (force)`);
await admin.query(`create database ${DB_NAME}`);
await admin.end();

await new Promise((res, rej) => start("npx", ["tsx", "scripts/migrate.ts"], { DATABASE_URL }, "migrate").on("exit", (c) => (c === 0 ? res() : rej(new Error("migrate failed")))));

start("npx", ["tsx", "e2e/services-mock.ts", String(MOCK_PORT), BASE], { STRIPE_WEBHOOK_SECRET: WEBHOOK_SECRET }, "mock");

start("npx", ["next", "dev", "-p", String(APP_PORT)], {
  NODE_ENV: "development", DATABASE_URL, APP_URL: BASE, APP_ENCRYPTION_KEY: KEY, ALLOWED_EMAILS: "owner@example.com,second@example.com", CRON_SECRET: CRON,
  GOOGLE_CLIENT_ID: "e2e-client", GOOGLE_CLIENT_SECRET: "e2e-secret", GOOGLE_OAUTH_BASE: `${MOCK}/oauth`, GOOGLE_API_BASE: MOCK,
  RESEND_API_KEY: "re_e2e", EMAIL_FROM: "Openhour <hello@example.com>", RESEND_API_BASE: MOCK,
  STRIPE_SECRET_KEY: "sk_test_e2e", STRIPE_WEBHOOK_SECRET: WEBHOOK_SECRET, STRIPE_API_HOST: "127.0.0.1", STRIPE_API_PORT: String(MOCK_PORT), STRIPE_API_PROTOCOL: "http",
}, "app");

await new Promise(() => {}); // run until Playwright stops us
