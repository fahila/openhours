import { DateTime } from "luxon";
import { test, expect, sql, apiBook, apiSlots, weekdayAhead, fillBooking, flushJobs, emailsTo, BASE, noHorizontalScroll, mockState } from "../fixtures";

const bookingsCount = async () => Number((await sql<{ n: string }>("select count(*) as n from bookings where status <> 'cancelled'"))[0].n);
const EVENT = "30-minute-meeting";

test.describe("F03 guest books a meeting", () => {
  test("F03-H1 a guest in another zone books; the confirmation, the host's list and the emails agree", async ({ host, newPage }) => {
    const g = await newPage({ tz: "Asia/Kolkata" });
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "Asha Verma", email: "asha@example.com" });
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    await expect(g.getByRole("heading", { name: "You're booked" })).toBeVisible();
    const [b] = await sql<{ start_at: Date; end_at: Date }>("select start_at, end_at from bookings");
    const inKolkata = DateTime.fromJSDate(b.start_at, { zone: "Asia/Kolkata" });
    await expect(g.locator("dl")).toContainText(inKolkata.toFormat("cccc, LLLL d, yyyy"));
    await expect(g.locator("dl")).toContainText(inKolkata.toFormat("h:mm a"));
    expect(b.end_at.getTime() - b.start_at.getTime()).toBe(30 * 60_000);
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Asha Verma", { exact: true })).toBeVisible();
    await expect(host.page.getByText(DateTime.fromJSDate(b.start_at, { zone: "America/New_York" }).toFormat("h:mm a"), { exact: false }).first()).toBeVisible();
    await flushJobs();
    expect(await emailsTo("asha@example.com")).toHaveLength(1);
    expect((await emailsTo("owner@example.com")).some((e) => /^New booking: Asha Verma/.test(e.subject))).toBe(true);
  });

  test("F03-H2 what the guest writes in the note is visible to the host in the app", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "Noted Guest", email: "noted@example.com", notes: "Please bring the contract draft." });
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Please bring the contract draft.")).toBeVisible();
  });

  test("F03-H3 the host profile page lists active events and leads to the booking page", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto("/sam");
    await expect(g.getByRole("heading", { name: "30 minute meeting" })).toBeVisible();
    await g.getByRole("link", { name: /30 minute meeting/ }).click();
    await expect(g).toHaveURL(new RegExp(`/sam/${EVENT}$`));
    void host;
  });

  test("F03-E1 someone else takes the slot while you fill the form: clear message, pick again, one booking", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g);
    let rival = 0;
    await g.route("**/api/public/sam/**/book", async (route) => {
      const body = JSON.parse(route.request().postData()!);
      const r = await fetch(`${BASE}/api/public/sam/${EVENT}/book`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "198.51.100.77" }, body: JSON.stringify({ ...body, name: "Rival", email: "rival@example.com" }) });
      rival = r.status;
      await route.continue();
    });
    await g.getByRole("button", { name: "Book this time" }).click();
    await expect(g.locator('p[role="alert"]')).toContainText("That time was just taken. Please pick another.");
    expect(rival).toBe(201);
    await expect(g.locator('ul[aria-label="Available times"]')).toBeVisible();
    expect(await bookingsCount()).toBe(1);
    await g.unroute("**/api/public/sam/**/book");
    await g.locator('ul[aria-label="Available times"] button').first().click();
    await g.getByLabel(/^Name/).fill("Second Try");
    await g.getByLabel(/^Email/).fill("second@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    expect(await bookingsCount()).toBe(2);
    void host;
  });

  test("F03-E2 two guests press 'Book' for the same time at once: exactly one wins, the other is told", async ({ host, newPage }) => {
    const a = await newPage({ tz: "Europe/London" });
    const b = await newPage({ tz: "Europe/London" });
    for (const [p, n] of [[a, "Alpha"], [b, "Bravo"]] as const) {
      await p.goto(`/sam/${EVENT}`);
      await fillBooking(p, { dayIndex: 1, slotIndex: 0, name: n, email: `${n.toLowerCase()}@example.com` });
    }
    await Promise.all([a.getByRole("button", { name: "Book this time" }).click(), b.getByRole("button", { name: "Book this time" }).click()]);
    await expect.poll(async () => (await Promise.all([a, b].map(async (p) => /\/booked\//.test(p.url())))).filter(Boolean).length, { timeout: 20_000 }).toBe(1);
    expect(await bookingsCount()).toBe(1);
    const loser = /\/booked\//.test(a.url()) ? b : a;
    await expect(loser.locator('p[role="alert"]')).toContainText("just taken");
    void host;
  });

  test("F03-E3 double-clicking 'Book' makes one booking and no error flash", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g);
    await g.getByRole("button", { name: "Book this time" }).dblclick();
    await g.waitForURL("**/booked/**", { timeout: 20_000 });
    await expect(g.getByRole("heading", { name: "You're booked" })).toBeVisible();
    expect(await bookingsCount()).toBe(1);
    void host;
  });

  test("F03-E4 the back button after booking returns to the booking page without booking again", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g);
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    await g.goBack();
    await expect(g).toHaveURL(new RegExp(`/sam/${EVENT}$`));
    await expect(g.getByRole("heading", { name: "30 minute meeting" })).toBeVisible();
    expect(await bookingsCount()).toBe(1);
    void host;
  });

  test("F03-E5 refreshing while typing your details starts over cleanly", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g);
    await g.reload();
    await expect(g.getByLabel(/^Name/)).toHaveCount(0);
    await expect(g.getByRole("heading", { name: "30 minute meeting" })).toBeVisible();
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    expect(await bookingsCount()).toBe(0);
    void host;
  });

  test("F03-E6 on a slow connection a loading state shows, then the times", async ({ host, newPage }) => {
    const g = await newPage();
    await g.route("**/api/public/sam/**/slots*", async (r) => { await new Promise((s) => setTimeout(s, 2500)); await r.continue(); });
    await g.goto(`/sam/${EVENT}`, { waitUntil: "commit" });
    await expect(g.locator('[aria-busy="true"]')).toBeVisible();
    await expect(g.locator('button[data-day]:not([aria-disabled="true"])').first()).toBeVisible({ timeout: 20_000 });
    void host;
  });

  test("F03-E7 offline when submitting: a message, the form is kept, and retrying works once back online", async ({ host, newPage, allowed }) => {
    allowed.console.push(/net::ERR_INTERNET_DISCONNECTED|Failed to fetch/);
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "Offline Olly", email: "olly@example.com" });
    await g.context().setOffline(true);
    await g.getByRole("button", { name: "Book this time" }).click();
    await expect(g.locator('p[role="alert"]')).toContainText("We couldn't reach the server");
    await expect(g.getByLabel(/^Name/)).toHaveValue("Offline Olly");
    await g.context().setOffline(false);
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    expect(await bookingsCount()).toBe(1);
    void host;
  });

  test("F03-E8 the 24-hour switch changes how times are written", async ({ host, newPage }) => {
    const g = await newPage({ tz: "Europe/London" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    const first12 = await g.locator('ul[aria-label="Available times"] button').first().innerText();
    expect(first12).toMatch(/^\d{1,2}:\d{2}\s?(AM|PM)$/i);
    await g.getByLabel("24-hour time").check();
    const first24 = await g.locator('ul[aria-label="Available times"] button').first().innerText();
    expect(first24).toMatch(/^\d{2}:\d{2}$/);
    void host;
  });

  for (const tz of ["Pacific/Kiritimati", "Pacific/Pago_Pago", "Asia/Kathmandu", "America/St_Johns"]) {
    test(`F03-E9 guest in ${tz}: the booked time is shown the same everywhere and stored in UTC`, async ({ host, newPage }) => {
      const g = await newPage({ tz });
      await g.goto(`/sam/${EVENT}`);
      await fillBooking(g, { name: "Zone Tester", email: "zone@example.com" });
      await g.getByRole("button", { name: "Book this time" }).click();
      await g.waitForURL("**/booked/**");
      const token = g.url().split("/booked/")[1];
      const [b] = await sql<{ start_at: Date }>("select start_at from bookings");
      const local = DateTime.fromJSDate(b.start_at, { zone: tz });
      await expect(g.locator("dl")).toContainText(local.toFormat("cccc, LLLL d, yyyy"));
      await expect(g.locator("dl")).toContainText(local.toFormat("h:mm a"));
      const ics = await (await fetch(`${BASE}/m/${token}/ics`)).text();
      expect(ics).toContain("DTSTART:" + b.start_at.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, ""));
      void host;
    });
  }

  test("F03-E10 accents, emoji and a very long name are kept exactly and shown to the host", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    const weird = "Zoë Ñandú 🎉 O'Neil-Smith";
    await fillBooking(g, { name: weird, email: "zoe@example.com" });
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    const long = "N".repeat(120);
    const b2 = await apiBook("sam", EVENT, { name: long, email: "long@example.com", idx: 3 });
    expect(b2.status).toBe(201);
    const tooLong = await apiBook("sam", EVENT, { name: "N".repeat(121), email: "toolong@example.com", idx: 4 });
    expect(tooLong.status).toBe(422);
    expect(tooLong.body).toHaveProperty("errors.name");
    await host.page.goto("/meetings");
    await expect(host.page.getByText(weird, { exact: true })).toBeVisible();
    expect(await noHorizontalScroll(host.page)).toBe(true);
    await flushJobs();
    const mail = (await emailsTo("owner@example.com")).find((e) => e.subject.includes("Zoë"));
    expect(mail?.subject).toContain("🎉");
  });

  test("F03-E11 HTML in a guest's name is plain text in the app and the email", async ({ host, newPage }) => {
    let dialogs = 0;
    host.page.on("dialog", (d) => { dialogs++; d.dismiss(); });
    const evil = `<img src=x onerror=alert(1)><script>alert(2)</script>`;
    const b = await apiBook("sam", EVENT, { name: evil, email: "evil@example.com" });
    expect(b.status).toBe(201);
    await host.page.goto("/meetings");
    await expect(host.page.getByText(evil).first()).toBeVisible();
    const g = await newPage();
    g.on("dialog", (d) => { dialogs++; d.dismiss(); });
    await g.goto(`/booked/${b.token}`);
    await expect(g.getByRole("heading", { name: "You're booked" })).toBeVisible();
    await flushJobs();
    const mails = await emailsTo("owner@example.com");
    for (const m of mails) { expect(m.html).not.toContain("<script>"); expect(m.html).not.toContain("<img src=x"); }
    expect(dialogs).toBe(0);
  });

  test("F03-E12 missing or invalid details are explained next to the field and nothing is lost", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "", email: "not-an-email" });
    await g.getByRole("button", { name: "Book this time" }).click();
    await expect(g.getByText("Tell us your name.")).toBeVisible();
    await expect(g.getByText("Enter a valid email address.")).toBeVisible();
    await g.getByLabel(/^Name/).fill("Fixed Name");
    await g.getByLabel(/^Email/).fill("fixed@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    expect(await bookingsCount()).toBe(1);
    void host;
  });

  test("F03-E13 month buttons work in both directions and never leave the page broken", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    const title = () => g.locator("#cal-label").innerText();
    const start = await title();
    await g.getByRole("button", { name: "Next month" }).click();
    await expect(g.locator("#cal-label")).not.toHaveText(start);
    await g.getByRole("button", { name: "Previous month" }).click();
    await expect(g.locator("#cal-label")).toHaveText(start);
    for (let i = 0; i < 4; i++) { await g.getByRole("button", { name: "Previous month" }).click(); await g.waitForTimeout(150); }
    await expect(g.getByText("No times this month. Try the next month.")).toBeVisible();
    expect(await title()).not.toBe(start);
    void host;
  });

  test("F03-E14 the minimum notice hides times that are too soon", async ({ host, newPage }) => {
    await sql("update event_types set min_notice_min = 2880");
    const tomorrow = DateTime.now().setZone("America/New_York").plus({ days: 1 }).toISODate()!;
    const r = await apiSlots("sam", EVENT, tomorrow, tomorrow);
    expect(r.slots).toHaveLength(0);
    const ok = weekdayAhead(4);
    expect((await apiSlots("sam", EVENT, ok.toISODate()!, ok.toISODate()!)).slots.length).toBeGreaterThan(0);
    void host; void newPage;
  });

  test("F03-E15 pages that should not exist return 404: turned-off event, unknown event, unknown host", async ({ host }) => {
    await sql("update event_types set active = false");
    for (const path of [`/sam/${EVENT}`, "/sam/does-not-exist", "/nobody", "/nobody/anything", "/sam/a/b"]) {
      expect((await fetch(`${BASE}${path}`)).status, path).toBe(404);
    }
    void host;
  });

  test("F03-E16 a rate-limit answer is explained to the guest", async ({ host, newPage }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g);
    await g.route("**/api/public/sam/**/book", (r) => r.fulfill({ status: 429, contentType: "application/json", body: JSON.stringify({ error: "rate_limited", message: "Too many attempts. Wait a minute and try again." }) }));
    await g.getByRole("button", { name: "Book this time" }).click();
    await expect(g.locator('p[role="alert"]')).toContainText("Too many attempts");
    await expect(g.getByLabel(/^Name/)).toHaveValue("Ann Guest");
    void host;
  });

  test("F03-E17 a group event shows places left and closes when full", async ({ host, newPage }) => {
    await sql("update event_types set kind = 'group', max_invitees = 2, slug = 'group'");
    const day = weekdayAhead(9);
    await apiBook("sam", "group", { day, name: "One", email: "one@example.com" });
    const g = await newPage();
    await g.goto("/sam/group");
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    const taken = DateTime.fromJSDate((await sql<{ s: Date }>("select start_at as s from bookings"))[0].s, { zone: "Asia/Kolkata" });
    await g.locator(`button[data-day="${taken.toISODate()}"]`).click();
    await g.locator('ul[aria-label="Available times"] button', { hasText: taken.toFormat("h:mm a") }).click();
    await expect(g.getByText("1 place left at this time.")).toBeVisible();
    await g.getByLabel(/^Name/).fill("Two");
    await g.getByLabel(/^Email/).fill("two@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    const fullAt = (await sql<{ s: Date }>("select start_at as s from bookings"))[0].s.toISOString();
    const [people] = await sql<{ n: string }>("select count(*) as n from booking_invitees");
    expect(people.n).toBe("2"); // two guests share one meeting
    const next = await apiBook("sam", "group", { day, name: "Three", email: "three@example.com" });
    expect(next.slot.start).not.toBe(fullAt); // the full time is no longer offered, the next one is
    const [meetings] = await sql<{ n: string }>("select count(*) as n from bookings");
    expect(meetings.n).toBe("2");
    void host;
  });

  test("F03-E18 a hidden event is not listed but its link works", async ({ host, newPage }) => {
    await sql("update event_types set hidden = true");
    const g = await newPage();
    await g.goto("/sam");
    await expect(g.getByText("Nothing to book right now")).toBeVisible();
    expect((await fetch(`${BASE}/sam/${EVENT}`)).status).toBe(200);
    void host;
  });

  test("F03-E19 changing the guest's time zone regroups the days without errors", async ({ host, newPage }) => {
    const g = await newPage({ tz: "Asia/Kolkata" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    const before = await g.locator('button[data-day]:not([aria-disabled="true"])').count();
    await g.locator("#guest-tz").selectOption("Pacific/Kiritimati");
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    const after = await g.locator('button[data-day]:not([aria-disabled="true"])').count();
    expect(before).toBeGreaterThan(0);
    expect(after).toBeGreaterThan(0);
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    await expect(g.locator('ul[aria-label="Available times"] button').first()).toBeVisible();
    void host;
  });

  test("F03-E20 a long description with line breaks wraps and keeps its breaks", async ({ host, newPage }) => {
    await sql("update event_types set description = $1", ["First line\nSecond line\n" + "x".repeat(300)]);
    const g = await newPage({ width: 390, height: 800 });
    await g.goto(`/sam/${EVENT}`);
    await expect(g.getByText("Second line")).toBeVisible();
    expect(await noHorizontalScroll(g)).toBe(true);
    void host;
  });

  test("F03-N1 the booking API refuses times outside the hours, in the past, malformed times, bad zones and wrong methods", async ({ host }) => {
    const url = `${BASE}/api/public/sam/${EVENT}/book`;
    const post = (body: unknown, ip: string) => fetch(url, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": ip }, body: JSON.stringify(body) });
    const ok = { name: "N", email: "n@example.com", timeZone: "UTC" };
    const sunday = DateTime.now().setZone("America/New_York").plus({ days: 10 }).startOf("week").plus({ days: 6, hours: 10 }); // a Sunday 10:00, outside Monday-Friday hours
    expect((await post({ ...ok, startAt: sunday.toUTC().toISO() }, "203.0.113.11")).status).toBe(409);
    expect((await post({ ...ok, startAt: "2020-01-06T14:00:00.000Z" }, "203.0.113.12")).status).toBe(409);
    expect((await post({ ...ok, startAt: "not a time" }, "203.0.113.13")).status).toBe(409);
    const day = weekdayAhead().toISODate()!;
    const { slots } = await apiSlots("sam", EVENT, day, day);
    expect((await post({ ...ok, startAt: slots[0].start, timeZone: "Mars/Olympus" }, "203.0.113.14")).status).toBe(422);
    expect((await post({ ...ok, startAt: DateTime.fromISO(slots[0].start).plus({ minutes: 7 }).toUTC().toISO() }, "203.0.113.15")).status).toBe(409);
    expect((await fetch(url, { headers: { "x-forwarded-for": "203.0.113.16" } })).status).toBe(405);
    expect((await fetch(`${BASE}/api/public/sam/nope/book`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "203.0.113.17" }, body: "{}" })).status).toBe(404);
    expect(await bookingsCount()).toBe(0);
    void host;
  });

  test("F03-N2 the slots API refuses nonsense ranges", async ({ host }) => {
    const get = (q: string) => fetch(`${BASE}/api/public/sam/${EVENT}/slots?${q}`).then((r) => r.status);
    expect(await get("from=2026-13-45&to=2026-13-46")).toBe(400);
    expect(await get("from=2026-11-10&to=2026-11-01")).toBe(400);
    expect(await get("from=2026-01-01&to=2027-12-31")).toBe(400);
    expect(await get("")).toBe(400);
    expect(await get("from=2026-11-01&to=2026-11-02")).toBe(200);
    void host;
  });

  test("F03-M1 the whole flow works at phone width with no sideways scrolling at any step", async ({ host, newPage }) => {
    const g = await newPage({ tz: "Europe/Berlin", width: 390, height: 844 });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    expect(await noHorizontalScroll(g)).toBe(true);
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    expect(await noHorizontalScroll(g)).toBe(true);
    await g.locator('ul[aria-label="Available times"] button').first().click();
    expect(await noHorizontalScroll(g)).toBe(true);
    await g.getByLabel(/^Name/).fill("Phone User");
    await g.getByLabel(/^Email/).fill("phone@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    expect(await noHorizontalScroll(g)).toBe(true);
    void host;
  });

  test("F03-K1 a whole booking can be made with the keyboard alone", async ({ host, newPage }) => {
    const g = await newPage({ tz: "America/Chicago" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.locator('button[data-day][tabindex="0"]').focus();
    for (let i = 0; i < 40; i++) {
      if (await g.evaluate(() => document.activeElement?.getAttribute("aria-disabled") !== "true")) break;
      await g.keyboard.press("ArrowRight");
    }
    await g.keyboard.press("Enter");
    await g.locator('ul[aria-label="Available times"] button').first().focus();
    await g.keyboard.press("Enter");
    await expect(g.getByLabel(/^Name/)).toBeFocused();
    await g.keyboard.type("Kay Lee");
    await g.keyboard.press("Tab");
    await g.keyboard.type("kay@example.com");
    await g.keyboard.press("Enter");
    await g.waitForURL("**/booked/**");
    void host;
  });

  test("F03-A1 no accessibility violations on the pick, details, error and confirmation steps", async ({ host, newPage, axe }) => {
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await axe(g, "pick day");
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    await axe(g, "pick time");
    await g.locator('ul[aria-label="Available times"] button').first().click();
    await axe(g, "details form");
    await g.getByRole("button", { name: "Book this time" }).click();
    await expect(g.getByText("Tell us your name.")).toBeVisible();
    await axe(g, "details with errors");
    await g.getByLabel(/^Name/).fill("A11y Tester");
    await g.getByLabel(/^Email/).fill("a11y@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    await axe(g, "confirmation");
    void host;
  });
});
