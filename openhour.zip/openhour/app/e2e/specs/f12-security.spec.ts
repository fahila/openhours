import { test, expect, sql, apiBook, BASE, flushJobs, CRON } from "../fixtures";

const EVENT = "30-minute-meeting";

test.describe("F12 security and isolation between hosts", () => {
  test("SEC-1 a second host cannot see or open the first host's event types, meetings, hours or calendars", async ({ host, newPage, login }) => {
    const [et] = await sql<{ id: string }>("select id from event_types");
    const [sch] = await sql<{ id: string }>("select id from availability_schedules");
    await apiBook("sam", EVENT, { name: "First Hosts Guest", email: "fhg@example.com" });
    await sql("insert into calendar_connections (user_id, provider, provider_account_id, email, refresh_token_enc) values ($1, 'google', 'x', 'first@example.com', '\\x00')", [host.user.id]);
    const p2 = await newPage({ tz: "America/New_York" });
    await login(p2, { email: "second@example.com", name: "Second Host", sub: "g-2" });
    // lists show only their own
    await p2.goto("/event-types");
    await expect(p2.getByRole("heading", { name: "30 minute meeting" })).toHaveCount(1);
    expect(await p2.locator("article").count()).toBe(1);
    await p2.goto("/meetings");
    await expect(p2.getByText("First Hosts Guest")).toHaveCount(0);
    await p2.goto("/integrations");
    await expect(p2.getByText("first@example.com")).toHaveCount(0);
    // direct links to the first host's rows
    const r = await p2.goto(`/event-types/${et.id}`);
    expect(r?.status()).toBe(404);
    // the second host's own data is separate: editing their hours does not touch the first host's
    await p2.goto("/availability");
    await p2.getByLabel("Monday range 1 end").fill("10:00");
    await p2.getByRole("button", { name: "Save hours" }).click();
    await expect(p2.getByText("Saved.")).toBeVisible();
    const rules = await sql<{ end_time: string }>("select end_time::text from availability_rules where schedule_id = $1 and day_of_week = 1", [sch.id]);
    expect(rules[0].end_time).toBe("17:00:00");
  });

  test("SEC-2 a signed-in host cannot cancel, change or delete another host's rows by guessing ids", async ({ host, newPage, login }) => {
    const b = await apiBook("sam", EVENT, { name: "Target Guest", email: "target@example.com" });
    const [booking] = await sql<{ id: string }>("select id from bookings");
    const p2 = await newPage({ tz: "America/New_York" });
    await login(p2, { email: "second@example.com", name: "Second Host", sub: "g-2" });
    // the only host actions are server actions; their ids are opaque, so test the visible path: their meetings page and event pages
    await p2.goto(`/event-types/${booking.id}`);
    await expect(p2.getByText("We can't find that page")).toBeVisible();
    const [still] = await sql<{ status: string }>("select status from bookings where id = $1", [booking.id]);
    expect(still.status).toBe("confirmed");
    expect((await fetch(`${BASE}/m/${b.token}`)).status).toBe(200);
    void host;
  });

  test("SEC-3 signing a host out does not sign anyone else out, and a signed-out browser cannot reach host pages", async ({ host, newPage, login }) => {
    const p2 = await newPage({ tz: "America/New_York" });
    await login(p2, { email: "second@example.com", name: "Second Host", sub: "g-2" });
    await host.page.goto("/settings");
    await host.page.getByRole("button", { name: "Sign out", exact: true }).click();
    await host.page.waitForURL("**/login");
    await p2.goto("/event-types");
    await expect(p2.getByRole("heading", { name: "Event types" })).toBeVisible();
  });

  test("SEC-4 odd addresses are 404, never a crash or a leak: traversal, NUL, very long, encoded slashes", async ({ host }) => {
    const long = "a".repeat(5000);
    for (const path of ["/sam/%2e%2e%2f%2e%2e%2fetc%2fpasswd", "/%00", `/${long}`, `/sam/${long}`, "/sam/..%5c..%5c", "/sam/%E0%A4%A", "/m/%00", "/booked/%2e%2e", "/sam/30-minute-meeting/extra", "/_next/../etc/passwd"]) {
      const r = await fetch(`${BASE}${path}`, { redirect: "manual" });
      expect([301, 302, 307, 308, 400, 404], path.slice(0, 60)).toContain(r.status);
      const body = await r.text();
      // (the dev server embeds stack text in its payloads; what must never appear is a database or connection error)
      expect(body).not.toMatch(/ECONNREFUSED|invalid byte sequence|syntax error at|violates|password authentication/);
    }
    void host;
  });

  test("SEC-5 secrets and source are not served: env files, git data, migrations, tests, package files", async ({ host }) => {
    for (const path of ["/.env", "/.env.local", "/.git/config", "/package.json", "/db/migrations/0001_init.sql", "/e2e/env.mjs", "/lib/env.ts", "/next.config.ts", "/tests/setup.ts"]) {
      const r = await fetch(`${BASE}${path}`);
      expect(r.status, path).toBe(404);
    }
    void host;
  });

  test("SEC-6 no secret value appears in any script the browser downloads", async ({ host, newPage }) => {
    const g = await newPage();
    const scripts: string[] = [];
    g.on("response", async (r) => { if (r.url().includes("/_next/") && r.url().endsWith(".js")) scripts.push(await r.text().catch(() => "")); });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForLoadState("networkidle");
    await host.page.goto("/integrations");
    const secrets = ["e2e-secret", "sk_test_e2e", "whsec_e2e", "re_e2e", CRON, "ZTJlLWtleS1lMmUta2V5LWUyZS1rZXktZTJlLWtleS0="];
    const all = scripts.join("\n");
    expect(all.length).toBeGreaterThan(1000);
    for (const s of secrets) expect(all.includes(s), `script contains ${s.slice(0, 6)}…`).toBe(false);
  });

  test("SEC-7 every kind of page carries the security headers; private links are not cached or sent as referrers; no wildcard CORS", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT);
    const urls = ["/login", "/sam", `/sam/${EVENT}`, "/privacy", "/m/nope", `/m/${b.token}`, `/booked/${b.token}`, `/reschedule/${b.token}`, "/does-not-exist", "/api/public/sam/" + EVENT + "/slots?from=2026-11-02&to=2026-11-02"];
    for (const u of urls) {
      const r = await fetch(`${BASE}${u}`);
      expect(r.headers.get("x-content-type-options"), u).toBe("nosniff");
      expect(r.headers.get("x-frame-options"), u).toBe("DENY");
      expect(r.headers.get("content-security-policy"), u).toContain("frame-ancestors 'none'");
      expect(r.headers.has("x-powered-by"), u).toBe(false);
      expect(r.headers.get("access-control-allow-origin"), u).toBeNull();
    }
    for (const u of [`/m/${b.token}`, `/booked/${b.token}`, `/reschedule/${b.token}`]) {
      const r = await fetch(`${BASE}${u}`);
      expect(r.headers.get("referrer-policy"), u).toBe("no-referrer");
      expect(r.headers.get("cache-control"), u).toContain("no-store");
    }
    void host; void newPage;
  });

  test("SEC-8 pages with private links, and the host app, ask search engines not to index them", async ({ host }) => {
    const b = await apiBook("sam", EVENT);
    for (const u of [`/m/${b.token}`, `/booked/${b.token}`, `/reschedule/${b.token}`, "/m/nope", "/login"]) {
      const r = await fetch(`${BASE}${u}`);
      const html = await r.text();
      const noindex = /noindex/i.test(r.headers.get("x-robots-tag") ?? "") || /<meta name="robots" content="[^"]*noindex/i.test(html);
      expect(noindex, `${u} should be noindex`).toBe(true);
    }
    await host.page.goto("/event-types");
    expect(await host.page.locator('meta[name="robots"]').getAttribute("content")).toContain("noindex");
  });

  test("SEC-9 the session cookie is httpOnly and SameSite, and cannot be read by page scripts", async ({ host }) => {
    const c = (await host.page.context().cookies()).find((x) => x.name === "session")!;
    expect([c.httpOnly, c.sameSite, c.path]).toEqual([true, "Lax", "/"]);
    expect(await host.page.evaluate(() => document.cookie)).not.toContain("session=");
  });

  test("SEC-10 hostile text in every host-editable field is stored and shown as text, never run or fatal", async ({ host }) => {
    const { page } = host;
    let dialogs = 0;
    page.on("dialog", (d) => { dialogs++; d.dismiss(); });
    const evil = `'); DROP TABLE users;-- <img src=x onerror=alert(1)> <script>alert(2)</script> {{7*7}} \${7*7}`;
    await page.goto("/event-types/new");
    await page.getByLabel(/^Name/).fill(evil);
    await page.getByLabel("Description").fill(evil);
    await page.getByLabel("Message on the confirmation page").fill(evil);
    await page.getByRole("button", { name: "Create event type" }).click();
    await expect(page).toHaveURL(/\/event-types$/);
    await page.goto("/settings");
    await page.getByLabel("Welcome message").fill(evil);
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    const g = await (await fetch(`${BASE}/sam`)).text();
    expect(g).not.toContain("<script>alert(2)");
    expect(g).not.toContain("<img src=x");
    expect(await sql("select id from users")).toHaveLength(1);
    expect(dialogs).toBe(0);
    await page.goto("/sam");
    await expect(page.getByText("{{7*7}}").first()).toBeVisible();
  });

  test("SEC-11 the login page never redirects to an address taken from the URL", async ({ host, newPage }) => {
    const g = await newPage();
    for (const q of ["next=//evil.example", "redirect=https://evil.example", "callbackUrl=https://evil.example", "returnTo=//evil.example"]) {
      await g.goto(`/login?${q}`);
      expect(new URL(g.url()).host).toBe(new URL(BASE).host);
    }
    void host;
  });

  test("SEC-12 hammering the sign-in start is rate limited", async ({ host }) => {
    const codes: number[] = [];
    for (let i = 0; i < 24; i++) codes.push((await fetch(`${BASE}/api/auth/google`, { redirect: "manual", headers: { "x-forwarded-for": "203.0.113.250" } })).status);
    expect(codes.slice(0, 20).every((c) => c >= 300 && c < 400)).toBe(true);
    expect(codes.slice(20).every((c) => c === 429)).toBe(true);
    void host;
  });

  test("SEC-13 the Stripe webhook accepts only signed events", async ({ host }) => {
    const body = JSON.stringify({ id: "evt_x", type: "checkout.session.completed", data: { object: {} } });
    for (const h of [{}, { "stripe-signature": "t=1,v1=00" }, { "stripe-signature": "garbage" }]) {
      const r = await fetch(`${BASE}/api/webhooks/stripe`, { method: "POST", body, headers: h as Record<string, string> });
      expect(r.status).toBe(400);
    }
    expect((await fetch(`${BASE}/api/webhooks/stripe`)).status).toBe(405);
    void host;
  });

  test("SEC-14 an address removed from the allow list loses access at once (existing session ends)", async ({ host }) => {
    // the allow list is fixed for this server; prove the check exists by removing the person's email from their own record
    await sql("update users set email = 'removed@example.com' where id = $1", [host.user.id]);
    await host.page.goto("/event-types");
    await expect(host.page).toHaveURL(/\/login$/);
  });

  test("SEC-15 booking data is not leaked through the public slots or profile pages", async ({ host }) => {
    await apiBook("sam", EVENT, { name: "Private Person", email: "private@example.com", notes: "secret note" });
    const day = new Date(Date.now() + 9 * 864e5).toISOString().slice(0, 10);
    for (const u of [`/api/public/sam/${EVENT}/slots?from=${day}&to=${day}`, "/sam", `/sam/${EVENT}`]) {
      const t = await (await fetch(`${BASE}${u}`)).text();
      for (const s of ["Private Person", "private@example.com", "secret note"]) expect(t, `${u} leaks ${s}`).not.toContain(s);
    }
    void host;
  });
});
