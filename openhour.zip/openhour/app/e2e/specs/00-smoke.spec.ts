import { test, expect, sql } from "../fixtures";

test("SMOKE-1 the stack is up: sign in, land on event types, starter data exists", async ({ host }) => {
  await expect(host.page.getByRole("heading", { name: "Event types" })).toBeVisible();
  const [n] = await sql<{ n: string }>("select count(*) as n from event_types where user_id = $1", [host.user.id]);
  expect(n.n).toBe("1");
});
