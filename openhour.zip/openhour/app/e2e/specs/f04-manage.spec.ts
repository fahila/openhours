import { DateTime } from "luxon";
import { test, expect, sql, apiBook, apiSlots, weekdayAhead, flushJobs, emailsTo, BASE, noHorizontalScroll } from "../fixtures";

const EVENT = "30-minute-meeting";
const row = async (token?: string) => (await sql<{ id: string; status: string; start_at: Date; cancel_reason: string | null }>("select id, status, start_at, cancel_reason from bookings order by created_at desc limit 1"))[0];
const alertIn = (p: import("@playwright/test").Page) => p.locator('p[role="alert"]');

test.describe("F04 guest changes or cancels a booking", () => {
  test("F04-H1 reschedule: the guest picks a new time, the old time opens up, the host and guest are told once", async ({ host, newPage }) => {
    const day = weekdayAhead(9);
    const b = await apiBook("sam", EVENT, { day, idx: 0, name: "Ria Mover", email: "ria@example.com" });
    const g = await newPage({ tz: "Europe/London" });
    await g.goto(`/m/${b.token}`);
    await expect(g.getByText("Confirmed")).toBeVisible();
    await g.getByRole("link", { name: "Pick another time" }).click();
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await expect(g.getByText("Moving the meeting for Ria Mover")).toBeVisible();
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(2).click();
    await g.locator('ul[aria-label="Available times"] button').nth(2).click();
    await g.getByRole("button", { name: "Move my meeting" }).click();
    await g.waitForURL("**/booked/**");
    const [old] = await sql<{ status: string }>("select status from bookings where start_at = $1", [b.slot.start]);
    expect(old.status).toBe("cancelled");
    const live = await sql<{ rescheduled_from: string | null }>("select rescheduled_from from bookings where status = 'confirmed'");
    expect(live).toHaveLength(1);
    expect(live[0].rescheduled_from).not.toBeNull();
    const free = await apiSlots("sam", EVENT, day.toISODate()!, day.toISODate()!);
    expect(free.slots.map((s) => s.start)).toContain(b.slot.start);
    await flushJobs();
    expect((await emailsTo("ria@example.com")).filter((e) => /^Moved:/.test(e.subject))).toHaveLength(1);
    expect((await emailsTo("owner@example.com")).filter((e) => /^Moved:/.test(e.subject))).toHaveLength(1);
    expect((await emailsTo("ria@example.com")).filter((e) => /^Cancelled/.test(e.subject))).toHaveLength(0);
    void host;
  });

  test("F04-H2 cancel with a reason: the host sees it, the time opens up, both are emailed", async ({ host, newPage }) => {
    const day = weekdayAhead(9);
    const b = await apiBook("sam", EVENT, { day, idx: 1, name: "Cal Canceller", email: "cal@example.com" });
    const g = await newPage();
    await g.goto(`/m/${b.token}`);
    await g.getByRole("button", { name: "Cancel meeting" }).click();
    await g.getByLabel("Reason (optional)").fill("Family emergency");
    await g.getByRole("dialog").getByRole("button", { name: "Cancel meeting" }).click();
    await expect(g.getByText("Reason: Family emergency")).toBeVisible();
    await expect(g.getByText("Cancelled", { exact: true })).toBeVisible();
    await expect(g.getByRole("link", { name: "Pick another time" })).toHaveCount(0);
    await expect(g.getByRole("link", { name: "Book a new time" })).toBeVisible();
    await host.page.goto("/meetings");
    await host.page.getByRole("tab", { name: /Past and cancelled/ }).click();
    await expect(host.page.getByText("Family emergency")).toBeVisible();
    expect((await apiSlots("sam", EVENT, day.toISODate()!, day.toISODate()!)).slots.map((s) => s.start)).toContain(b.slot.start);
    await flushJobs();
    expect((await emailsTo("cal@example.com")).some((e) => /^Cancelled/.test(e.subject))).toBe(true);
    expect((await emailsTo("owner@example.com")).some((e) => /^Cancelled: Cal Canceller/.test(e.subject))).toBe(true);
  });

  test("F04-E1 moving to the very same time is allowed and changes nothing for the host's calendar slot", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Same Time", email: "same@example.com" });
    const r = await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: b.slot.start }) });
    expect(r.status).toBe(200);
    const live = await sql("select id from bookings where status = 'confirmed'");
    expect(live).toHaveLength(1);
    void host; void newPage;
  });

  test("F04-E2 a cancelled booking's links show 'cancelled', and cancelling again is harmless", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Twice Cancel", email: "twice@example.com" });
    const url = `${BASE}/m/${b.token}/cancel`;
    const post = () => fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ reason: "x" }) });
    expect((await post()).status).toBe(200);
    expect((await post()).status).toBe(200);
    const g = await newPage();
    await g.goto(`/reschedule/${b.token}`);
    await expect(g).toHaveURL(new RegExp(`/m/${b.token}$`));
    await expect(g.getByText("Cancelled", { exact: true })).toBeVisible();
    const r = await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: b.slot.start }) });
    expect(r.status).toBe(422);
    void host;
  });

  test("F04-E3 someone takes the new time while you are choosing it: message, nothing is lost", async ({ host, newPage }) => {
    const day = weekdayAhead(9);
    const b = await apiBook("sam", EVENT, { day, idx: 0, name: "Mover", email: "mover@example.com" });
    const g = await newPage();
    await g.goto(`/reschedule/${b.token}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    await g.locator('ul[aria-label="Available times"] button').first().click();
    await g.route("**/m/*/reschedule", async (route) => {
      const body = JSON.parse(route.request().postData()!);
      await fetch(`${BASE}/api/public/sam/${EVENT}/book`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "198.51.100.88" }, body: JSON.stringify({ startAt: body.startAt, name: "Rival", email: "rival@example.com", timeZone: "UTC" }) });
      await route.continue();
    });
    await g.getByRole("button", { name: "Move my meeting" }).click();
    await expect(alertIn(g)).toContainText("just taken");
    const [still] = await sql<{ status: string }>("select status from bookings where id = (select booking_id from booking_invitees where email = 'mover@example.com')");
    expect(still.status).toBe("confirmed");
    void host;
  });

  test("F04-E4 a meeting that already happened can no longer be changed", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Past Guest", email: "past@example.com" });
    await sql("update bookings set start_at = now() - interval '2 days', end_at = now() - interval '2 days' + interval '30 minutes'");
    const g = await newPage();
    await g.goto(`/m/${b.token}`);
    await expect(g.getByText("Finished")).toBeVisible();
    await expect(g.getByRole("button", { name: "Cancel meeting" })).toHaveCount(0);
    await expect(g.getByRole("link", { name: "Pick another time" })).toHaveCount(0);
    await g.goto(`/reschedule/${b.token}`);
    await expect(g).toHaveURL(new RegExp(`/m/${b.token}$`));
    const r = await fetch(`${BASE}/m/${b.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    expect(r.status).toBe(422);
    expect(await r.json()).toHaveProperty("errors._");
    void host;
  });

  test("F04-E5 cancelling from two tabs at once ends cancelled with no error", async ({ host, newPage, allowed }) => {
    const b = await apiBook("sam", EVENT, { name: "Two Tabs", email: "tabs@example.com" });
    const a = await newPage(), c = await newPage();
    await Promise.all([a.goto(`/m/${b.token}`), c.goto(`/m/${b.token}`)]);
    await Promise.all([a, c].map((p) => p.getByRole("button", { name: "Cancel meeting" }).click()));
    await Promise.all([a, c].map((p) => p.getByRole("dialog").getByRole("button", { name: "Cancel meeting" }).click()));
    await expect(a.getByText("Cancelled", { exact: true })).toBeVisible();
    await expect(c.getByText("Cancelled", { exact: true })).toBeVisible();
    expect((await row()).status).toBe("cancelled");
    void host; void allowed;
  });

  test("F04-E6 a rescheduled booking keeps the guest's name, note and zone", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Keeper Guest", email: "keeper@example.com", notes: "Remember me", tz: "Asia/Tokyo" });
    const { slots } = await apiSlots("sam", EVENT, weekdayAhead(12).toISODate()!, weekdayAhead(12).toISODate()!);
    const r = await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: slots[3].start }) });
    expect(r.status).toBe(200);
    const [inv] = await sql<{ name: string; time_zone: string; answers: { notes: string } }>("select i.name, i.time_zone, i.answers from booking_invitees i join bookings b on b.id = i.booking_id where b.status = 'confirmed'");
    expect(inv).toEqual({ name: "Keeper Guest", time_zone: "Asia/Tokyo", answers: { notes: "Remember me" } });
    void host; void newPage;
  });

  test("F04-E7 one guest leaving a group leaves the others booked, and the host sees the smaller group", async ({ host, newPage }) => {
    await sql("update event_types set kind = 'group', max_invitees = 3, slug = 'group'");
    const day = weekdayAhead(9);
    const a = await apiBook("sam", "group", { day, name: "Gina", email: "gina@example.com" });
    const b = await apiBook("sam", "group", { day, name: "Hugo", email: "hugo@example.com" });
    expect(b.slot.start).toBe(a.slot.start);
    const g = await newPage();
    await g.goto(`/m/${a.token}`);
    await g.getByRole("button", { name: "Cancel meeting" }).click();
    await g.getByRole("dialog").getByRole("button", { name: "Cancel meeting" }).click();
    await expect(g.getByRole("heading", { name: "You've left this meeting" })).toBeVisible(); // not "page not found"
    await expect.poll(async () => (await sql<{ email: string }>("select i.email from booking_invitees i join bookings b on b.id = i.booking_id where b.status = 'confirmed'")).map((l) => l.email), { timeout: 15_000 }).toEqual(["hugo@example.com"]);
    await g.goto(`/m/${a.token}`);
    await expect(g.getByText("We can't find that page")).toBeVisible(); // her link no longer opens the group's meeting
    await expect(g.getByRole("heading", { name: "Your meeting" })).toHaveCount(0);
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Hugo", { exact: true })).toBeVisible();
    await expect(host.page.getByText("Gina", { exact: true })).toHaveCount(0);
  });

  test("F04-E8 the cancel dialog closes with Escape and 'Keep it', and focus returns to its button", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Esc Guest", email: "esc@example.com" });
    const g = await newPage();
    await g.goto(`/m/${b.token}`);
    const open = g.getByRole("button", { name: "Cancel meeting" });
    await open.click();
    await expect(g.getByRole("dialog")).toBeVisible();
    await g.keyboard.press("Escape");
    await expect(g.getByRole("dialog")).toBeHidden();
    await expect(open).toBeFocused();
    await open.click();
    await g.getByRole("button", { name: "Keep it" }).click();
    await expect(g.getByRole("dialog")).toBeHidden();
    expect((await row()).status).toBe("confirmed");
    void host;
  });

  test("F04-E9 a group guest's page never shows the other guests", async ({ host, newPage }) => {
    await sql("update event_types set kind = 'group', max_invitees = 3, slug = 'group'");
    const day = weekdayAhead(9);
    const a = await apiBook("sam", "group", { day, name: "Visible Vera", email: "vera@example.com" });
    await apiBook("sam", "group", { day, name: "Secret Sid", email: "sid@example.com" });
    const html = await (await fetch(`${BASE}/m/${a.token}`)).text();
    expect(html).not.toContain("Secret Sid");
    expect(html).not.toContain("sid@example.com");
    void host; void newPage;
  });

  test("F04-E10 tampered, truncated and oversized links are 404, not errors", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Link Tester", email: "link@example.com" });
    const flip = b.token!.slice(0, -1) + (b.token!.endsWith("A") ? "B" : "A");
    for (const t of [flip, b.token!.slice(0, 10), "x".repeat(5000), "%00", "../../etc/passwd", "'; drop table bookings;--"]) {
      for (const path of ["/m/", "/booked/", "/reschedule/"]) {
        const r = await fetch(`${BASE}${path}${encodeURIComponent(t)}`);
        expect(r.status, `${path}${t.slice(0, 20)}`).toBe(404);
      }
      expect((await fetch(`${BASE}/m/${encodeURIComponent(t)}/ics`)).status).toBe(404);
    }
    expect((await sql("select id from bookings where status = 'confirmed'"))).toHaveLength(1);
    void host;
  });

  test("F04-E11 the manage link works from any device, with no sign-in", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Anywhere", email: "anywhere@example.com" });
    const g = await newPage({ tz: "America/Sao_Paulo" });
    await g.goto(`/m/${b.token}`);
    await expect(g.getByRole("heading", { name: "Your meeting" })).toBeVisible();
    void host;
  });

  test("F04-E12 rescheduling across a month boundary works", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Far Mover", email: "far@example.com" });
    const g = await newPage({ tz: "America/New_York" });
    await g.goto(`/reschedule/${b.token}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.getByRole("button", { name: "Next month" }).click();
    await g.getByRole("button", { name: "Next month" }).click();
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.locator('button[data-day]:not([aria-disabled="true"])').first().click();
    await g.locator('ul[aria-label="Available times"] button').first().click();
    await g.getByRole("button", { name: "Move my meeting" }).click();
    await g.waitForURL("**/booked/**");
    const [r] = await sql<{ start_at: Date }>("select start_at from bookings where status = 'confirmed'");
    expect(r.start_at.getTime()).toBeGreaterThan(Date.now() + 40 * 864e5);
    void host;
  });

  test("F04-N1 a cancel reason over 500 characters is refused, not truncated silently", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Wordy", email: "wordy@example.com" });
    const r = await fetch(`${BASE}/m/${b.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ reason: "r".repeat(501) }) });
    expect(r.status).toBe(422);
    expect((await row()).status).toBe("confirmed");
    void host;
  });

  test("F04-N2 guessing links is rate limited", async ({ host }) => {
    const codes: number[] = [];
    for (let i = 0; i < 24; i++) {
      const r = await fetch(`${BASE}/m/guess-${i}/cancel`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "203.0.113.200" }, body: "{}" });
      codes.push(r.status);
    }
    expect(codes.slice(0, 20).every((c) => c === 404)).toBe(true);
    expect(codes.slice(20).every((c) => c === 429)).toBe(true);
    void host;
  });

  test("F04-M1 manage and reschedule pages fit a phone", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Phone Mgr", email: "phonemgr@example.com" });
    const g = await newPage({ width: 390, height: 800 });
    for (const path of [`/m/${b.token}`, `/reschedule/${b.token}`, `/booked/${b.token}`]) {
      await g.goto(path);
      await g.waitForLoadState("networkidle");
      expect(await noHorizontalScroll(g), path).toBe(true);
    }
    void host;
  });

  test("F04-A1 manage, cancelled, finished, dialog and reschedule screens pass an accessibility scan", async ({ host, newPage, axe }) => {
    const b = await apiBook("sam", EVENT, { name: "Axe Mgr", email: "axemgr@example.com" });
    const g = await newPage();
    await g.goto(`/m/${b.token}`);
    await axe(g, "manage");
    await g.getByRole("button", { name: "Cancel meeting" }).click();
    await axe(g, "cancel dialog");
    await g.keyboard.press("Escape");
    await g.goto(`/reschedule/${b.token}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await axe(g, "reschedule");
    await fetch(`${BASE}/m/${b.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    await g.goto(`/m/${b.token}`);
    await axe(g, "cancelled");
    const p = await apiBook("sam", EVENT, { name: "Axe Past", email: "axepast@example.com", idx: 4 });
    await sql("update bookings set start_at = now() - interval '2 days', end_at = now() - interval '2 days' + interval '30 minutes' where status = 'confirmed'");
    await g.goto(`/m/${p.token}`);
    await axe(g, "finished");
    void host;
  });
});
