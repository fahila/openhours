import { test, expect, sql, apiBook, apiSlots, weekdayAhead, flushJobs, emailsTo, mockState, mockControl, BASE, MOCK, until, fillBooking } from "../fixtures";

const EVENT = "30-minute-meeting";
const makePaid = async (price = 2500, currency = "usd") => { await sql("update event_types set require_payment = true, price_cents = $1, currency = $2", [price, currency]); };
const pay = async (checkoutUrl: string) => fetch(`${checkoutUrl}/complete`, { redirect: "manual" });
const status = async (email: string) => (await sql<{ status: string }>("select b.status from bookings b join booking_invitees i on i.booking_id = b.id where i.email = $1", [email]))[0]?.status;

test.describe("F11 guest pays to book", () => {
  test("F11-H1 pay through checkout: pending while paying, confirmed after, one confirmation email, host sees it paid", async ({ host, newPage }) => {
    await makePaid();
    const g = await newPage({ tz: "Europe/London" });
    await g.goto(`/sam/${EVENT}`);
    await expect(g.getByText("$25.00 to book")).toBeVisible();
    await fillBooking(g, { name: "Pam Payer", email: "pam@example.com" });
    await g.getByRole("button", { name: "Continue to payment" }).click();
    await g.waitForURL(`${MOCK}/pay/**`);
    expect(await status("pam@example.com")).toBe("pending_payment");
    expect(await emailsTo("pam@example.com")).toHaveLength(0);
    await g.getByRole("link", { name: "Pay" }).click();
    await g.waitForURL("**/booked/**");
    await expect(g.getByRole("heading", { name: "You're booked" })).toBeVisible({ timeout: 30_000 });
    expect(await status("pam@example.com")).toBe("confirmed");
    await flushJobs();
    expect((await emailsTo("pam@example.com")).filter((e) => /^Confirmed/.test(e.subject))).toHaveLength(1);
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Paid $25.00")).toBeVisible();
  });

  test("F11-H2 prices are written in the right currency", async ({ host, newPage }) => {
    const g = await newPage();
    for (const [cents, cur, text] of [[2500, "eur", "€25.00 to book"], [1999, "gbp", "£19.99 to book"], [150000, "inr", "₹1,500.00 to book"]] as const) {
      await makePaid(cents, cur);
      await g.goto(`/sam/${EVENT}`);
      await expect(g.getByText(text)).toBeVisible();
    }
    void host;
  });

  test("F11-N1 backing out of the payment page frees the time at once and says so", async ({ host, newPage }) => {
    await makePaid();
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "Back Out", email: "backout@example.com" });
    await g.getByRole("button", { name: "Continue to payment" }).click();
    await g.waitForURL(`${MOCK}/pay/**`);
    const slot = (await sql<{ start_at: Date }>("select start_at from bookings"))[0].start_at.toISOString();
    await g.locator("#back").click();
    await expect(g).toHaveURL(new RegExp(`/sam/${EVENT}`));
    await expect(g.getByText("You haven't been charged")).toBeVisible();
    const day = slot.slice(0, 10);
    const { slots } = await apiSlots("sam", EVENT, day, day);
    expect(slots.map((s) => s.start)).toContain(slot);
    expect(await status("backout@example.com")).toBe("cancelled");
    void host;
  });

  test("F11-E1 money that arrives after the hold ran out is refunded and the booking stays cancelled", async ({ host }) => {
    await makePaid();
    const b = await apiBook("sam", EVENT, { name: "Late Payer", email: "late@example.com" });
    expect(b.checkoutUrl).toBeTruthy();
    await flushJobs({ future: ["payment.expire"] }); // runs the hold-expiry job early: the slot is released
    expect(await status("late@example.com")).toBe("cancelled");
    await pay(b.checkoutUrl!);
    await until(async () => ["paid", "refunded"].includes((await sql<{ status: string }>("select status from payments"))[0].status) || undefined, 15_000, "late payment recorded");
    await flushJobs({ future: ["payment.refund"] });
    await until(async () => (await mockState()).stripe.refunds.length === 1 || undefined, 15_000, "refund issued");
    expect(await status("late@example.com")).toBe("cancelled");
    expect((await sql<{ status: string }>("select status from payments"))[0].status).toBe("refunded");
    expect(await emailsTo("late@example.com")).toHaveLength(0);
  });

  test("F11-E2 paying twice, or the payment event arriving twice, gives one booking and one email and no refund", async ({ host }) => {
    await makePaid();
    const b = await apiBook("sam", EVENT, { name: "Twice Payer", email: "twicepay@example.com" });
    await pay(b.checkoutUrl!);
    await pay(b.checkoutUrl!);
    await until(async () => (await status("twicepay@example.com")) === "confirmed" || undefined, 15_000, "confirmed");
    await flushJobs();
    expect((await emailsTo("twicepay@example.com")).filter((e) => /^Confirmed/.test(e.subject))).toHaveLength(1);
    expect((await mockState()).stripe.refunds).toHaveLength(0);
    expect(await sql("select id from payments")).toHaveLength(1);
    void host;
  });

  test("F11-E3 Stripe being down: the guest is told nothing was charged, the time is free again, and a retry works", async ({ host, newPage, allowed }) => {
    allowed.status.push(502); // designed answer when the payment page cannot be created
    allowed.console.push(/status of 502/);
    await makePaid();
    await mockControl({ failCheckout: true });
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await fillBooking(g, { name: "Down Dee", email: "dee@example.com" });
    await g.getByRole("button", { name: "Continue to payment" }).click();
    await expect(g.locator('p[role="alert"]')).toContainText("Nothing was charged");
    expect(await status("dee@example.com")).toBe("cancelled");
    expect(await sql("select id from payments")).toHaveLength(0);
    await mockControl({ failCheckout: false });
    await g.getByRole("button", { name: "Continue to payment" }).click();
    await g.waitForURL(`${MOCK}/pay/**`, { timeout: 20_000 }).catch(async () => {
      // the form returned to the times; choose again
      await g.locator('ul[aria-label="Available times"] button').first().click();
      await g.getByLabel(/^Name/).fill("Down Dee");
      await g.getByLabel(/^Email/).fill("dee@example.com");
      await g.getByRole("button", { name: "Continue to payment" }).click();
      await g.waitForURL(`${MOCK}/pay/**`);
    });
    void host;
  });

  test("F11-E4 the waiting page confirms by itself once the payment lands", async ({ host, newPage }) => {
    await makePaid();
    const b = await apiBook("sam", EVENT, { name: "Wait Wes", email: "wes@example.com" });
    const g = await newPage();
    await g.goto(`/booked/${b.token}`);
    await expect(g.getByRole("heading", { name: "Confirming your payment" })).toBeVisible();
    await pay(b.checkoutUrl!);
    await expect(g.getByRole("heading", { name: "You're booked" })).toBeVisible({ timeout: 30_000 });
    void host;
  });

  test("F11-E5 while someone is paying, the time cannot be taken by another guest", async ({ host }) => {
    await makePaid();
    const day = weekdayAhead(9);
    const a = await apiBook("sam", EVENT, { day, idx: 0, name: "Holder", email: "holder@example.com" });
    const { slots } = await apiSlots("sam", EVENT, day.toISODate()!, day.toISODate()!);
    expect(slots.map((s) => s.start)).not.toContain(a.slot.start);
    const rival = await fetch(`${BASE}/api/public/sam/${EVENT}/book`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "198.51.100.70" }, body: JSON.stringify({ startAt: a.slot.start, name: "Rival", email: "rival@example.com", timeZone: "UTC" }) });
    expect(rival.status).toBe(409);
    void host;
  });

  test("F11-E6 cancelling before paying closes the Stripe session and frees the time", async ({ host }) => {
    await makePaid();
    const b = await apiBook("sam", EVENT, { name: "Cancel Pay", email: "cancelpay@example.com" });
    await fetch(`${BASE}/m/${b.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    await flushJobs();
    expect((await mockState()).stripe.expired.length).toBe(1);
    expect(await status("cancelpay@example.com")).toBe("cancelled");
    void host;
  });

  test("F11-E7 moving a paid booking does not charge again", async ({ host }) => {
    await makePaid();
    const b = await apiBook("sam", EVENT, { name: "Move Payer", email: "movepay@example.com" });
    await pay(b.checkoutUrl!);
    await until(async () => (await status("movepay@example.com")) === "confirmed" || undefined, 15_000, "confirmed");
    const { slots } = await apiSlots("sam", EVENT, weekdayAhead(12).toISODate()!, weekdayAhead(12).toISODate()!);
    const r = await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: slots[0].start }) });
    expect(r.status).toBe(200);
    expect(Object.keys((await mockState()).stripe.sessions)).toHaveLength(1);
    void host;
  });

  test("F11-E8 changing the price later does not change what an earlier guest paid", async ({ host }) => {
    await makePaid(2500);
    const b = await apiBook("sam", EVENT, { name: "Price Pat", email: "pricepat@example.com" });
    await pay(b.checkoutUrl!);
    await until(async () => (await status("pricepat@example.com")) === "confirmed" || undefined, 15_000, "confirmed");
    await makePaid(9900);
    expect((await sql<{ amount_cents: number }>("select amount_cents from payments"))[0].amount_cents).toBe(2500);
    void host;
  });

  test("F11-A1 the paid booking screens pass an accessibility scan", async ({ host, newPage, axe }) => {
    await makePaid();
    const g = await newPage();
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await axe(g, "paid booking page");
    const b = await apiBook("sam", EVENT, { name: "A11y Payer", email: "a11ypay@example.com" });
    await g.goto(`/booked/${b.token}`);
    await expect(g.getByRole("heading", { name: "Confirming your payment" })).toBeVisible();
    await axe(g, "waiting for payment");
    await host.page.goto("/event-types/new");
    await host.page.getByLabel("Take payment when guests book").check();
    await axe(host.page, "event type with payment");
  });
});
