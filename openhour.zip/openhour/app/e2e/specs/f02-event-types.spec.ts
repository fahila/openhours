import type { Page } from "@playwright/test";
import { test, expect, sql, apiBook, apiSlots, weekdayAhead, BASE } from "../fixtures";

const create = async (page: Page, name: string, extra: (p: Page) => Promise<void> = async () => {}) => {
  await page.goto("/event-types/new");
  await page.getByLabel(/^Name/).fill(name);
  await extra(page);
  await page.getByRole("button", { name: "Create event type" }).click();
};
const slugs = async () => (await sql<{ slug: string }>("select slug from event_types order by created_at")).map((r) => r.slug);

test.describe("F02 host creates and manages an event type", () => {
  test("F02-H1 create an event type; it is listed and its public link works", async ({ host }) => {
    await create(host.page, "Strategy call", async (p) => { await p.getByLabel("Duration in minutes").fill("45"); await p.getByLabel("Description").fill("Bring your questions."); });
    await expect(host.page).toHaveURL(/\/event-types$/);
    await expect(host.page.getByRole("heading", { name: "Strategy call" })).toBeVisible();
    const r = await apiSlots("sam", "strategy-call", weekdayAhead().toISODate()!, weekdayAhead().toISODate()!);
    expect(r.status).toBe(200);
    expect(r.slots.length).toBeGreaterThan(0);
    const res = await fetch(`${BASE}/sam/strategy-call`);
    expect(res.status).toBe(200);
    expect(await res.text()).toContain("Bring your questions.");
  });

  test("F02-H2 editing the name, duration and place shows up on the booking page", async ({ host }) => {
    await host.page.goto("/event-types");
    await host.page.getByRole("link", { name: /Edit.*30 minute meeting/ }).click();
    await host.page.getByLabel(/^Name/).fill("Renamed call");
    await host.page.getByLabel("Duration in minutes").fill("20");
    await host.page.getByLabel("Where it happens").selectOption("in_person");
    await host.page.getByLabel(/^Address/).fill("1 Main Street");
    await host.page.getByRole("button", { name: "Save changes" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    const g = await fetch(`${BASE}/sam/30-minute-meeting`);
    const html = (await g.text()).replace(/<!-- -->/g, "");
    expect(html).toContain("Renamed call");
    expect(html).toContain("20 min");
    expect(html).toContain("1 Main Street");
  });

  test("F02-H3 turning an event off hides it and its link; turning it on restores both", async ({ host }) => {
    await host.page.goto("/event-types");
    await host.page.getByRole("switch", { name: "30 minute meeting is on" }).click();
    await expect(host.page.getByRole("switch", { name: "30 minute meeting is off" })).toBeVisible();
    expect((await fetch(`${BASE}/sam/30-minute-meeting`)).status).toBe(404);
    expect(await (await fetch(`${BASE}/sam`)).text()).not.toContain("30 minute meeting");
    await host.page.getByRole("switch", { name: "30 minute meeting is off" }).click();
    await expect(host.page.getByRole("switch", { name: "30 minute meeting is on" })).toBeVisible();
    expect((await fetch(`${BASE}/sam/30-minute-meeting`)).status).toBe(200);
  });

  test("F02-H4 an event type with no bookings can be deleted", async ({ host }) => {
    await create(host.page, "Temporary");
    await host.page.getByRole("link", { name: /Edit.*Temporary/ }).click();
    await host.page.getByRole("button", { name: "Delete" }).click();
    await host.page.getByRole("dialog").getByRole("button", { name: "Delete" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    await expect(host.page.getByRole("heading", { name: "Temporary" })).toHaveCount(0);
    expect(await slugs()).toEqual(["30-minute-meeting"]);
  });

  test("F02-N1 deleting an event type that has bookings is refused with a reason", async ({ host }) => {
    await apiBook("sam", "30-minute-meeting");
    await host.page.goto("/event-types");
    await host.page.getByRole("link", { name: /Edit.*30 minute meeting/ }).click();
    await host.page.getByRole("button", { name: "Delete" }).click();
    await host.page.getByRole("dialog").getByRole("button", { name: "Delete" }).click();
    await expect(host.page.getByRole("dialog").getByRole("alert")).toContainText("This event has bookings. Turn it off instead.");
    expect(await slugs()).toEqual(["30-minute-meeting"]);
  });

  test("F02-E1 accents and emoji in the name work, and the link name is generated sensibly", async ({ host }) => {
    await create(host.page, "Café ☕ chat");
    await expect(host.page).toHaveURL(/\/event-types$/);
    await expect(host.page.getByRole("heading", { name: "Café ☕ chat" })).toBeVisible();
    expect(await slugs()).toContain("cafe-chat");
    expect(await (await fetch(`${BASE}/sam/cafe-chat`)).text()).toContain("Café ☕ chat");
  });

  test("F02-E2 a name made only of emoji or symbols still creates an event with a working link", async ({ host }) => {
    await create(host.page, "☕☕☕");
    await expect(host.page).toHaveURL(/\/event-types$/, { timeout: 10_000 });
    const all = await slugs();
    expect(all).toHaveLength(2);
    const made = all.find((s) => s !== "30-minute-meeting")!;
    expect((await fetch(`${BASE}/sam/${made}`)).status).toBe(200);
  });

  test("F02-E3 two event types with the same name get different link names without an error", async ({ host }) => {
    await create(host.page, "Intro call");
    await expect(host.page).toHaveURL(/\/event-types$/);
    await create(host.page, "Intro call");
    await expect(host.page).toHaveURL(/\/event-types$/, { timeout: 10_000 });
    const all = await slugs();
    expect(new Set(all).size).toBe(3);
    expect(all).toContain("intro-call");
  });

  test("F02-E4 typing an existing link name is refused with a clear message", async ({ host }) => {
    await create(host.page, "Another", async (p) => { await p.getByLabel(/^Link name/).fill("30-minute-meeting"); });
    await expect(host.page.getByText("You already use that link name.").first()).toBeVisible();
    expect(await slugs()).toEqual(["30-minute-meeting"]);
  });

  test("F02-E5 120 characters are accepted and wrap; 121 are refused", async ({ host }) => {
    const long = "L".repeat(120);
    await create(host.page, long);
    await expect(host.page).toHaveURL(/\/event-types$/);
    expect(await host.page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)).toBe(true);
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).evaluate((el: HTMLInputElement) => el.removeAttribute("maxlength"));
    await host.page.getByLabel(/^Name/).fill("M".repeat(121));
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page.getByText("Keep the name under 120 characters.").first()).toBeVisible();
  });

  test("F02-E6 HTML in a name is shown as text, never run", async ({ host }) => {
    let dialogs = 0;
    host.page.on("dialog", (d) => { dialogs++; d.dismiss(); });
    await create(host.page, "<img src=x onerror=alert(1)> <b>bold</b>");
    await expect(host.page.getByRole("heading", { name: "<img src=x onerror=alert(1)> <b>bold</b>" })).toBeVisible();
    expect(dialogs).toBe(0);
  });

  test("F02-E7 a group event asks for places; fewer than 2 is refused", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Workshop");
    await expect(host.page.getByLabel("Places per time")).toHaveCount(0);
    await host.page.getByLabel("Who can book a time").selectOption("group");
    await host.page.getByLabel("Places per time").fill("1");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page.getByText("A group needs between 2 and 500 places.").first()).toBeVisible();
    await host.page.getByLabel("Places per time").fill("8");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    const [row] = await sql<{ kind: string; max_invitees: number }>("select kind, max_invitees from event_types where slug = 'workshop'");
    expect(row).toEqual({ kind: "group", max_invitees: 8 });
  });

  test("F02-E8 in-person and custom places need details", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Visit");
    await host.page.getByLabel("Where it happens").selectOption("in_person");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page.getByText("Add the address or details guests need.").first()).toBeVisible();
    await host.page.getByLabel("Where it happens").selectOption("custom");
    await host.page.getByLabel(/^Details/).fill("Ask at the front desk");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
  });

  test("F02-E9 double-clicking Create makes one event type", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Once only");
    await host.page.getByRole("button", { name: "Create event type" }).dblclick();
    await expect(host.page).toHaveURL(/\/event-types$/, { timeout: 15_000 });
    const n = await sql("select id from event_types where name = 'Once only'");
    expect(n).toHaveLength(1);
  });

  test("F02-E10 numbers that make no sense are refused: negative buffers, decimals, huge limits", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Odd numbers");
    await host.page.getByLabel("Duration in minutes").evaluate((el: HTMLInputElement) => { el.type = "text"; });
    await host.page.getByLabel("Duration in minutes").fill("2.5");
    await host.page.getByLabel("Most per day").evaluate((el: HTMLInputElement) => { el.type = "text"; });
    await host.page.getByLabel("Most per day").fill("-3");
    await host.page.getByLabel("Bookable days ahead").evaluate((el: HTMLInputElement) => { el.type = "text"; });
    await host.page.getByLabel("Bookable days ahead").fill("100000");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page.getByText("Choose between 5 and 720 minutes.").first()).toBeVisible();
    await expect(host.page.getByText(/Use a whole number from 1 to 100/).first()).toBeVisible();
    await expect(host.page.getByText(/Use a whole number from 1 to 365/).first()).toBeVisible();
    expect(await slugs()).toEqual(["30-minute-meeting"]);
  });

  test("F02-E11 prices: too low, not a number and group events are refused; a valid price is stored in cents", async ({ host }) => {
    const form = async (price: string, kind = "one_on_one") => {
      await host.page.goto("/event-types/new");
      await host.page.getByLabel(/^Name/).fill("Priced");
      if (kind === "group") { await host.page.getByLabel("Who can book a time").selectOption("group"); await host.page.getByLabel("Places per time").fill("4"); }
      await host.page.getByLabel("Take payment when guests book").check();
      await host.page.getByLabel("Price").fill(price);
      await host.page.getByRole("button", { name: "Create event type" }).click();
    };
    await form("0.10");
    await expect(host.page.getByText("Enter a price between 0.50 and 10,000.").first()).toBeVisible();
    await form("abc");
    await expect(host.page.getByText("Enter a price between 0.50 and 10,000.").first()).toBeVisible();
    await form("20", "group");
    await expect(host.page.getByText("Payment works for one guest at a time, not group events.").first()).toBeVisible();
    await form("19,99");
    await expect(host.page).toHaveURL(/\/event-types$/);
    const [row] = await sql<{ price_cents: number }>("select price_cents from event_types where slug = 'priced'");
    expect(row.price_cents).toBe(1999);
  });

  test("F02-E12 changing the link name breaks the old link, the new one works, and guests' manage links keep working", async ({ host }) => {
    const b = await apiBook("sam", "30-minute-meeting");
    await host.page.goto("/event-types");
    await host.page.getByRole("link", { name: /Edit.*30 minute meeting/ }).click();
    await host.page.getByLabel(/^Link name/).fill("intro");
    await host.page.getByRole("button", { name: "Save changes" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    expect((await fetch(`${BASE}/sam/30-minute-meeting`)).status).toBe(404);
    expect((await fetch(`${BASE}/sam/intro`)).status).toBe(200);
    expect((await fetch(`${BASE}/m/${b.token}`)).status).toBe(200);
  });

  test("F02-E13 a failed save keeps what was typed", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Keep my words");
    await host.page.getByLabel("Description").fill("A long description I would hate to retype");
    await host.page.getByLabel("Duration in minutes").evaluate((el: HTMLInputElement) => { el.type = "text"; });
    await host.page.getByLabel("Duration in minutes").fill("1");
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page.getByText("Choose between 5 and 720 minutes.").first()).toBeVisible();
    await expect(host.page.getByLabel(/^Name/)).toHaveValue("Keep my words");
    await expect(host.page.getByLabel("Description")).toHaveValue("A long description I would hate to retype");
  });

  test("F02-E14 two tabs editing the same event: the last save wins and nothing breaks", async ({ host, newPage }) => {
    const [et] = await sql<{ id: string }>("select id from event_types");
    const tab2 = await newPage({ tz: "America/New_York" });
    await tab2.context().addCookies(await host.page.context().cookies());
    await host.page.goto(`/event-types/${et.id}`);
    await tab2.goto(`/event-types/${et.id}`);
    await host.page.getByLabel(/^Name/).fill("From tab one");
    await tab2.getByLabel(/^Name/).fill("From tab two");
    await host.page.getByRole("button", { name: "Save changes" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    await tab2.getByRole("button", { name: "Save changes" }).click();
    await expect(tab2).toHaveURL(/\/event-types$/);
    const [row] = await sql<{ name: string }>("select name from event_types");
    expect(row.name).toBe("From tab two");
  });

  test("F02-E15 an event type can be created with the keyboard alone", async ({ host }) => {
    const { page } = host;
    await page.goto("/event-types/new");
    await page.getByLabel(/^Name/).focus();
    await page.keyboard.type("Keyboard only");
    await page.getByRole("button", { name: "Create event type" }).focus();
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/\/event-types$/);
    await expect(page.getByRole("heading", { name: "Keyboard only" })).toBeVisible();
  });

  test("F02-E16 colour choice is saved and shown on the booking page", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Magenta one");
    await host.page.getByRole("radio", { name: "Magenta" }).check({ force: true });
    await host.page.getByRole("button", { name: "Create event type" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    const [row] = await sql<{ color_index: number }>("select color_index from event_types where slug = 'magenta-one'");
    expect(row.color_index).toBe(4);
  });

  test("F02-E17 limits and buffers are applied to what guests can book", async ({ host }) => {
    await host.page.goto("/event-types");
    await host.page.getByRole("link", { name: /Edit.*30 minute meeting/ }).click();
    await host.page.getByLabel("Most per day").fill("1");
    await host.page.getByLabel("Gap after").selectOption("60");
    await host.page.getByRole("button", { name: "Save changes" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    const day = weekdayAhead(10);
    const b = await apiBook("sam", "30-minute-meeting", { day });
    expect(b.status).toBe(201);
    const again = await apiSlots("sam", "30-minute-meeting", day.toISODate()!, day.toISODate()!);
    expect(again.slots).toHaveLength(0);
  });

  test("F02-N2 the 'Cancel' button leaves without saving", async ({ host }) => {
    await host.page.goto("/event-types/new");
    await host.page.getByLabel(/^Name/).fill("Never saved");
    await host.page.getByRole("link", { name: "Cancel" }).click();
    await expect(host.page).toHaveURL(/\/event-types$/);
    expect(await slugs()).toEqual(["30-minute-meeting"]);
  });
});
