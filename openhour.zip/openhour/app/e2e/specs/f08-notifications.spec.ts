import { DateTime } from "luxon";
import { test, expect, sql, apiBook, apiSlots, weekdayAhead, flushJobs, emailsTo, mockState, mockControl, runJobs, BASE, CRON, until } from "../fixtures";

const EVENT = "30-minute-meeting";
type Mail = Awaited<ReturnType<typeof emailsTo>>[number];
const ics = (m: Mail) => Buffer.from(m.attachments![0].content, "base64").toString("utf8");
const field = (text: string, name: string) => text.split("\r\n").find((l) => l.startsWith(name + ":") || l.startsWith(name + ";"))?.replace(/^[^:]+:/, "");

test.describe("F08 emails, invites and reminders", () => {
  test("F08-H1 the guest's confirmation has the time in their zone, the place, a private link and an invite; the host gets a notice", async ({ host }) => {
    await sql("update event_types set confirmation_message = 'See you soon. Bring ID.', location_type = 'in_person', location_value = '12 Canal Street'");
    const b = await apiBook("sam", EVENT, { name: "Mia Mail", email: "mia@example.com", tz: "Asia/Tokyo", notes: "Allergic to cats" });
    await flushJobs();
    const [g] = await emailsTo("mia@example.com");
    expect(g.subject).toBe("Confirmed: 30 minute meeting with Sam Rivera");
    expect(g.from).toBe("Openhour <hello@example.com>");
    expect(g.text).toContain("12 Canal Street");
    expect(g.text).toContain("See you soon. Bring ID.");
    expect(g.text).toContain(`${BASE}/m/${b.token}`);
    const local = DateTime.fromISO(b.slot.start, { zone: "Asia/Tokyo" });
    expect(g.text).toContain(local.toFormat("h:mm a"));
    expect(g.text).toMatch(/GMT\+9|JST/);
    const [h] = await emailsTo("owner@example.com");
    expect(h.subject).toBe("New booking: Mia Mail, 30 minute meeting");
    expect(h.text).toContain("Allergic to cats");
    void host;
  });

  test("F08-H2 the invite attachment is a valid calendar event with the right times", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Ivy Invite", email: "ivy@example.com" });
    await flushJobs();
    const [g] = await emailsTo("ivy@example.com");
    expect(g.attachments![0].filename).toBe("meeting.ics");
    expect(g.attachments![0].content_type).toContain("method=REQUEST");
    const text = ics(g);
    expect(text.startsWith("BEGIN:VCALENDAR\r\n")).toBe(true);
    expect(text.endsWith("END:VCALENDAR\r\n")).toBe(true);
    expect(text.split("\r\n").filter(Boolean).every((l) => Buffer.byteLength(l) <= 75)).toBe(true);
    const [row] = await sql<{ start_at: Date; end_at: Date; id: string }>("select id, start_at, end_at from bookings");
    const z = (d: Date) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
    expect(field(text, "DTSTART")).toBe(z(row.start_at));
    expect(field(text, "DTEND")).toBe(z(row.end_at));
    expect(field(text, "METHOD")).toBe("REQUEST");
    expect(field(text, "UID")).toContain(row.id);
    expect(text).toContain("ORGANIZER;CN=Sam Rivera:mailto:owner@example.com");
    expect(text).toContain("ATTENDEE;CN=Ivy Invite");
    void host; void b;
  });

  test("F08-H3 a reminder is sent a day before with a working manage link", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Remy Reminder", email: "remy@example.com", day: weekdayAhead(10) });
    await flushJobs({ future: ["workflow.send"] });
    const reminders = (await emailsTo("remy@example.com")).filter((e) => /Reminder/.test(e.subject));
    expect(reminders).toHaveLength(1);
    const link = reminders[0].text.match(/https?:\/\/[^\s]+\/m\/[A-Za-z0-9_-]+/)![0];
    expect(link).toBe(`${BASE}/m/${b.token}`);
    const g = await newPage();
    await g.goto(link);
    await expect(g.getByRole("heading", { name: "Your meeting" })).toBeVisible();
    void host;
  });

  test("F08-E1 a booking made less than a day ahead gets no reminder, only the confirmation", async ({ host }) => {
    await sql("delete from availability_rules where schedule_id in (select id from availability_schedules)");
    for (let d = 0; d < 7; d++) await sql("insert into availability_rules (schedule_id, day_of_week, start_time, end_time) select id, $1, '00:00', '23:30' from availability_schedules", [d]);
    await sql("update event_types set min_notice_min = 0");
    const today = DateTime.now().setZone("America/New_York");
    const { slots } = await apiSlots("sam", EVENT, today.toISODate()!, today.plus({ days: 1 }).toISODate()!);
    const soon = slots.find((s) => Date.parse(s.start) - Date.now() > 3 * 3600_000 && Date.parse(s.start) - Date.now() < 12 * 3600_000)!;
    const r = await fetch(`${BASE}/api/public/sam/${EVENT}/book`, { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "198.51.100.50" }, body: JSON.stringify({ startAt: soon.start, name: "Soon Guest", email: "soon@example.com", timeZone: "UTC" }) });
    expect(r.status).toBe(201);
    await flushJobs();
    const mails = await emailsTo("soon@example.com");
    expect(mails.map((m) => m.subject)).toEqual(["Confirmed: 30 minute meeting with Sam Rivera"]);
    expect(await sql("select id from jobs where kind = 'workflow.send'")).toHaveLength(0);
    void host;
  });

  test("F08-E2 when the email service fails twice, the guest still gets exactly one confirmation", async ({ host }) => {
    await mockControl({ failEmails: 2 });
    const b = await apiBook("sam", EVENT, { name: "Retry Rita", email: "rita@example.com" });
    const s = await flushJobs();
    expect(s.failed).toBeGreaterThanOrEqual(1);
    expect(await emailsTo("rita@example.com")).toHaveLength(1);
    expect(await emailsTo("owner@example.com")).toHaveLength(1);
    const [j] = await sql<{ status: string; attempts: number }>("select status, attempts from jobs where kind = 'booking.confirmed'");
    expect(j.status).toBe("done");
    expect(j.attempts).toBeGreaterThanOrEqual(2);
    const log = await sql<{ status: string }>("select status from message_log");
    expect(log.every((l) => l.status === "sent")).toBe(true); // every failure ended in a sent message
    void host; void b;
  });

  test("F08-E3 moving a meeting updates the guest's calendar event instead of adding a second one", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Move Mo", email: "mo@example.com" });
    await flushJobs();
    const first = ics((await emailsTo("mo@example.com"))[0]);
    const { slots } = await apiSlots("sam", EVENT, weekdayAhead(12).toISODate()!, weekdayAhead(12).toISODate()!);
    await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: slots[2].start }) });
    await flushJobs();
    const moved = (await emailsTo("mo@example.com")).find((e) => /^Moved:/.test(e.subject))!;
    const second = ics(moved);
    expect(field(second, "UID")).toBe(field(first, "UID"));
    expect(Number(field(second, "SEQUENCE"))).toBeGreaterThan(Number(field(first, "SEQUENCE")));
    expect(field(second, "DTSTART")).not.toBe(field(first, "DTSTART"));
    void host;
  });

  test("F08-E4 cancelling sends a cancel notice that targets the same calendar event, even after a move", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Cancel Cy", email: "cy@example.com" });
    await flushJobs();
    const uid = field(ics((await emailsTo("cy@example.com"))[0]), "UID");
    const { slots } = await apiSlots("sam", EVENT, weekdayAhead(12).toISODate()!, weekdayAhead(12).toISODate()!);
    const mv = await (await fetch(`${BASE}/m/${b.token}/reschedule`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ startAt: slots[1].start }) })).json();
    await flushJobs();
    await fetch(`${BASE}/m/${mv.manageToken}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ reason: "nope" }) });
    await flushJobs();
    const cancel = (await emailsTo("cy@example.com")).find((e) => /^Cancelled/.test(e.subject))!;
    const text = ics(cancel);
    expect(field(text, "METHOD")).toBe("CANCEL");
    expect(field(text, "STATUS")).toBe("CANCELLED");
    expect(field(text, "UID")).toBe(uid);
    void host;
  });

  test("F08-E5 names with accents, emoji and apostrophes arrive intact in subject and body, with a text version", async ({ host }) => {
    const name = "Zoë Ñandú 🎉 O'Neil";
    await apiBook("sam", EVENT, { name, email: "zoe@example.com" });
    await flushJobs();
    const [h] = await emailsTo("owner@example.com");
    expect(h.subject).toContain(name);
    expect(h.text).toContain(name);
    expect(h.html).toContain("Zoë Ñandú 🎉 O&#39;Neil".replace("&#39;", "'"));
    expect(h.text).not.toMatch(/<[a-z]/i);
    void host;
  });

  test("F08-E6 running the jobs again and again never sends anything twice", async ({ host }) => {
    await apiBook("sam", EVENT, { name: "Once Only", email: "once@example.com" });
    await flushJobs();
    const n = (await mockState()).emails.length;
    await sql("update jobs set status = 'queued', run_at = now() where kind = 'booking.confirmed'");
    await flushJobs();
    await flushJobs();
    expect((await mockState()).emails.length).toBe(n);
    void host;
  });

  test("F08-E7 a cancelled meeting is never reminded about", async ({ host }) => {
    const b = await apiBook("sam", EVENT, { name: "Gone Gus", email: "gus@example.com", day: weekdayAhead(10) });
    await flushJobs({ future: ["workflow.send"] });
    const before = (await emailsTo("gus@example.com")).filter((e) => /Reminder/.test(e.subject)).length;
    expect(before).toBe(1);
    const b2 = await apiBook("sam", EVENT, { name: "Gone Gus Two", email: "gus2@example.com", day: weekdayAhead(11) });
    await flushJobs(); // confirmation goes out and the reminder is scheduled
    await fetch(`${BASE}/m/${b2.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    await flushJobs({ future: ["workflow.send"] });
    expect((await emailsTo("gus2@example.com")).filter((e) => /Reminder/.test(e.subject))).toHaveLength(0);
    void host; void b;
  });

  test("F08-E8 the jobs endpoint needs the secret, in a header, for GET and POST alike", async ({ host }) => {
    for (const method of ["GET", "POST"]) {
      expect((await fetch(`${BASE}/api/jobs/run`, { method })).status).toBe(401);
      expect((await fetch(`${BASE}/api/jobs/run`, { method, headers: { Authorization: "Bearer wrong" } })).status).toBe(401);
      expect((await fetch(`${BASE}/api/jobs/run?secret=${CRON}`, { method })).status).toBe(401);
      const ok = await fetch(`${BASE}/api/jobs/run`, { method, headers: { Authorization: `Bearer ${CRON}` } });
      expect(ok.status).toBe(200);
      expect(await ok.json()).toHaveProperty("ran");
    }
    void host;
  });

  test("F08-E9 guest emails reply to the host", async ({ host }) => {
    await apiBook("sam", EVENT, { name: "Reply Rae", email: "rae@example.com" });
    await flushJobs();
    const raw = (await mockState()).emails.find((e) => e.to[0] === "rae@example.com") as unknown as { reply_to?: string };
    expect(raw.reply_to).toBe("owner@example.com");
    void host;
  });

  test("F08-E10 line breaks and control characters in a guest's name cannot reach email headers", async ({ host }) => {
    const r = await fetch(`${BASE}/api/public/sam/${EVENT}/book`, {
      method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "198.51.100.60" },
      body: JSON.stringify({ startAt: (await apiSlots("sam", EVENT, weekdayAhead().toISODate()!, weekdayAhead().toISODate()!)).slots[0].start, name: "Evil\r\nBcc: attacker@example.com\u0000", email: "inject@example.com", timeZone: "UTC" }),
    });
    expect([201, 422]).toContain(r.status);
    await flushJobs();
    for (const m of (await mockState()).emails) {
      expect(m.subject).not.toMatch(/[\r\n\u0000-\u001f]/);
    }
    const [inv] = await sql<{ name: string }>("select name from booking_invitees");
    if (inv) expect(inv.name).not.toMatch(/[\r\n\u0000-\u001f]/);
    void host;
  });

  test("F08-E11 a dead job (the email service down for good) stays visible with its reason and nothing is sent", async ({ host }) => {
    await mockControl({ failEmails: 1000 });
    await apiBook("sam", EVENT, { name: "Dead Dan", email: "dan@example.com" });
    const s = await flushJobs();
    expect(s.dead).toBeGreaterThanOrEqual(1);
    const [j] = await sql<{ status: string; attempts: number; last_error: string }>("select status, attempts, last_error from jobs where kind = 'booking.confirmed'");
    expect(j.status).toBe("dead");
    expect(j.attempts).toBe(6);
    expect(j.last_error).toMatch(/resend is down|Resend 500/i);
    expect(await emailsTo("dan@example.com")).toHaveLength(0);
    const hostMeetings = await sql("select id from bookings where status = 'confirmed'");
    expect(hostMeetings).toHaveLength(1); // the booking itself is not lost
    void host;
  });
});
