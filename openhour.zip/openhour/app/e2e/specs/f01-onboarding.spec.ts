import { test, expect, BASE, sql, mockControl, mockState } from "../fixtures";

test.describe("F01 host signs in and connects a calendar", () => {
  test("F01-H1 first sign-in creates the account, starter event and hours; the zone prompt fixes the zone", async ({ page, login }) => {
    const u = await login(page);
    await expect(page.getByRole("heading", { name: "30 minute meeting" })).toBeVisible();
    const [row] = await sql<{ time_zone: string; sch: string }>("select u.time_zone, s.time_zone as sch from users u join availability_schedules s on s.user_id = u.id where u.id = $1", [u.id]);
    expect([row.time_zone, row.sch]).toEqual(["UTC", "UTC"]);
    const region = page.getByRole("region", { name: "Time zone" });
    await expect(region).toBeVisible();
    await region.getByRole("button", { name: "Use America/New York" }).click();
    await expect(region).toBeHidden();
    const [after] = await sql<{ time_zone: string; sch: string }>("select u.time_zone, s.time_zone as sch from users u join availability_schedules s on s.user_id = u.id where u.id = $1", [u.id]);
    expect([after.time_zone, after.sch]).toEqual(["America/New_York", "America/New_York"]);
    const rules = await sql("select day_of_week from availability_rules r join availability_schedules s on s.id = r.schedule_id where s.user_id = $1 order by 1", [u.id]);
    expect(rules.map((r) => r.day_of_week)).toEqual([1, 2, 3, 4, 5]);
    const wf = await sql("select trigger, offset_min from workflows where user_id = $1", [u.id]);
    expect(wf).toEqual([{ trigger: "before_event", offset_min: 1440 }]);
  });

  test("F01-H2 connecting Google Calendar lists calendars with the primary one as target", async ({ host }) => {
    await host.page.goto("/integrations");
    await host.page.getByRole("link", { name: "Connect Google Calendar" }).click();
    await host.page.waitForURL("**/integrations?calendar=connected");
    await expect(host.page.getByRole("rowheader", { name: "Sam Rivera" })).toBeVisible();
    await expect(host.page.getByRole("rowheader", { name: "Team calendar" })).toBeVisible();
    await expect(host.page.getByLabel("Add new bookings to Sam Rivera")).toBeChecked();
    await expect(host.page.getByLabel("Block busy times from Team calendar")).not.toBeChecked();
  });

  test("F01-E1 'Keep' on the zone prompt is remembered across a reload", async ({ page, login }) => {
    await login(page);
    const region = page.getByRole("region", { name: "Time zone" });
    await region.getByRole("button", { name: /^Keep UTC/ }).click();
    await expect(region).toBeHidden();
    await page.reload();
    await expect(page.getByRole("heading", { name: "Event types" })).toBeVisible();
    await expect(region).toBeHidden();
  });

  test("F01-E2 no prompt when the browser zone matches the account", async ({ host }) => {
    await host.page.reload();
    await expect(host.page.getByRole("heading", { name: "Event types" })).toBeVisible();
    await expect(host.page.getByRole("region", { name: "Time zone" })).toHaveCount(0);
  });

  test("F01-E3 signing in on a second device keeps one account and adds a session", async ({ page, login, newPage }) => {
    const u = await login(page);
    const other = await newPage({ tz: "Europe/Paris" });
    await login(other);
    const users = await sql("select id from users");
    expect(users).toHaveLength(1);
    const sessions = await sql("select id from sessions where user_id = $1", [u.id]);
    expect(sessions).toHaveLength(2);
  });

  test("F01-E4 the allow list ignores capitalisation and maps to the same account", async ({ page, login, newPage }) => {
    await login(page);
    const p2 = await newPage();
    await login(p2, { email: "Owner@Example.COM" });
    expect(await sql("select id from users")).toHaveLength(1);
  });

  test("F01-E5 two people with the same name get different link names", async ({ page, login, newPage }) => {
    await login(page, { email: "owner@example.com", name: "Sam Rivera", sub: "g-1" });
    const p2 = await newPage();
    await login(p2, { email: "second@example.com", name: "Sam Rivera", sub: "g-2" });
    const slugs = (await sql<{ slug: string }>("select slug from users order by created_at")).map((r) => r.slug);
    expect(slugs).toEqual(["sam-rivera", "sam-rivera-2"]);
  });

  test("F01-E6 a tampered session cookie is signed out, not an error", async ({ page, login, context }) => {
    await login(page);
    const c = (await context.cookies()).find((x) => x.name === "session")!;
    await context.addCookies([{ ...c, value: c.value.slice(0, -3) + "AAA" }]);
    await page.goto("/event-types");
    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByRole("heading", { name: "Sign in" })).toBeVisible();
  });

  test("F01-E7 every host screen sends a signed-out visitor to /login", async ({ page }) => {
    for (const path of ["/event-types", "/event-types/new", "/meetings", "/availability", "/integrations", "/settings", "/workflows", "/single-use-links", "/api/calendars/connect/google"]) {
      await page.goto(path);
      await expect(page, path).toHaveURL(/\/login$/);
    }
  });

  test("F01-E8 an expired session during use sends you to sign in, not to an error page", async ({ page, login }) => {
    const u = await login(page);
    await page.goto("/settings");
    await sql("delete from sessions where user_id = $1", [u.id]);
    await page.getByLabel(/^Name/).fill("Changed Name");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page).toHaveURL(/\/login/, { timeout: 15_000 });
    const [row] = await sql<{ name: string }>("select name from users where id = $1", [u.id]);
    expect(row.name).not.toBe("Changed Name");
  });

  test("F01-E9 removing a calendar permission in Google is detected and the reconnect button works", async ({ host }) => {
    const { page } = host;
    await page.goto("/integrations");
    await page.getByRole("link", { name: "Connect Google Calendar" }).click();
    await page.waitForURL("**/integrations?calendar=connected");
    // the person removes the app in their Google account: the access token we hold stops working and so does the refresh token
    await mockControl({ revokeRefresh: ["refresh-1"], rejectApiTokens: true });
    const day = new Date(Date.now() + 9 * 864e5).toISOString().slice(0, 10);
    const r = await fetch(`${BASE}/api/public/sam/30-minute-meeting/slots?from=${day}&to=${day}`);
    expect(r.status).toBe(503);
    await page.goto("/integrations");
    await expect(page.getByText("Needs reconnecting")).toBeVisible();
    await mockControl({ nextRefreshToken: "refresh-2", rejectApiTokens: false });
    await page.getByRole("link", { name: "Reconnect" }).click();
    await page.waitForURL("**/integrations?calendar=connected");
    await expect(page.getByText("Connected", { exact: true })).toBeVisible();
    const again = await fetch(`${BASE}/api/public/sam/30-minute-meeting/slots?from=${day}&to=${day}`);
    expect(again.status).toBe(200);
  });

  test("F01-E10 'Refresh list' picks up a calendar added in Google", async ({ host }) => {
    const { page } = host;
    await page.goto("/integrations");
    await page.getByRole("link", { name: "Connect Google Calendar" }).click();
    await page.waitForURL("**/integrations?calendar=connected");
    await expect(page.getByRole("rowheader")).toHaveCount(2);
    await mockControl({ extraCalendars: [{ id: "new@group.example.com", summary: "Side project", accessRole: "owner" }] });
    await page.getByRole("button", { name: "Refresh list" }).click();
    await expect(page.getByRole("rowheader", { name: "Side project" })).toBeVisible();
  });

  test("F01-N1 an account that is not on the allow list is refused and nothing is created", async ({ page, login, allowed }) => {
    await mockControl({ profile: { email: "stranger@example.com", email_verified: true, sub: "g-x", name: "Stranger" } });
    await page.goto("/login");
    await page.getByRole("link", { name: "Continue with Google" }).click();
    await expect(page).toHaveURL(/error=not_allowed/);
    await expect(page.getByText("isn't allowed to sign in")).toBeVisible();
    expect(await sql("select id from users")).toHaveLength(0);
    expect(await sql("select id from sessions")).toHaveLength(0);
    void login; void allowed;
  });

  test("F01-N2 an unverified Google email is refused", async ({ page }) => {
    await mockControl({ profile: { email: "owner@example.com", email_verified: false, sub: "g-u", name: "Sam" } });
    await page.goto("/login");
    await page.getByRole("link", { name: "Continue with Google" }).click();
    await expect(page).toHaveURL(/error=not_allowed/);
    expect(await sql("select id from users")).toHaveLength(0);
  });

  test("F01-N3 cancelling on Google's consent screen returns to sign-in with a message", async ({ page }) => {
    const r = await page.goto("/api/auth/google/callback?error=access_denied&state=x");
    expect(r?.url()).toContain("/login?error=sign_in_failed");
    await expect(page.getByText("Sign-in didn't complete")).toBeVisible();
  });

  test("F01-N4 a forged or replayed callback does nothing", async ({ page, request }) => {
    const forged = await request.get(`${BASE}/api/auth/google/callback?code=good-code&state=forged`, { maxRedirects: 0 });
    expect(forged.status()).toBe(307);
    expect(forged.headers()["location"]).toContain("sign_in_failed");
    // a real flow, then the same callback URL again
    await page.goto("/login");
    let callbackUrl = "";
    page.on("request", (r) => { if (r.url().includes("/api/auth/google/callback")) callbackUrl = r.url(); });
    await page.getByRole("link", { name: "Continue with Google" }).click();
    await page.waitForURL("**/event-types");
    expect(callbackUrl).toContain("state=");
    const [before] = await sql<{ n: string }>("select count(*) as n from sessions");
    const replay = await request.get(callbackUrl, { maxRedirects: 0 });
    expect(replay.headers()["location"]).toContain("sign_in_failed");
    const [after] = await sql<{ n: string }>("select count(*) as n from sessions");
    expect(after.n).toBe(before.n);
  });

  test("F01-N5 declining calendar access leaves the account unconnected with a clear message", async ({ host }) => {
    const r = await host.page.goto("/api/calendars/callback/google?error=access_denied&state=x");
    expect(r?.url()).toContain("calendar=failed");
    await expect(host.page.getByText("We couldn't finish connecting")).toBeVisible();
    expect(await sql("select id from calendar_connections")).toHaveLength(0);
  });

  test("F01-N6 a calendar callback started by someone else is refused", async ({ page, login, newPage }) => {
    await login(page, { email: "owner@example.com", sub: "g-a" });
    const intruder = await newPage();
    await login(intruder, { email: "second@example.com", name: "Second", sub: "g-b" });
    // owner begins a connection; the second person's browser cannot finish it with owner's state
    let state = "";
    page.on("request", (r) => { if (r.url().includes("/oauth/auth")) state = new URL(r.url()).searchParams.get("state") ?? ""; });
    await page.goto("/api/calendars/connect/google");
    await page.waitForURL("**/integrations?calendar=connected");
    expect(state).not.toBe("");
    await intruder.goto(`/api/calendars/callback/google?code=good-code&state=${state}`);
    await expect(intruder).toHaveURL(/calendar=failed/);
    const conns = await sql<{ email: string }>("select u.email from calendar_connections c join users u on u.id = c.user_id");
    expect(conns.map((c) => c.email)).toEqual(["owner@example.com"]);
  });

  test("F01-E11 the same Google account cannot be connected twice", async ({ host }) => {
    const { page } = host;
    for (let i = 0; i < 2; i++) {
      await page.goto("/integrations");
      await page.getByRole("link", { name: /Connect (another Google account|Google Calendar)/ }).click();
      await page.waitForURL("**/integrations?calendar=connected");
    }
    expect(await sql("select id from calendar_connections")).toHaveLength(1);
    expect(await sql("select id from calendars")).toHaveLength(2);
  });

  test("F01-E12 signed-in visitors skip the login page", async ({ host }) => {
    await host.page.goto("/login");
    await expect(host.page).toHaveURL(/\/event-types$/);
  });

  test("F01-E13 mock outage: Google unreachable during sign-in gives a message, not a crash", async ({ page, allowed }) => {
    allowed.status.push(500);
    await mockControl({ profile: { email: "owner@example.com", email_verified: true, sub: "g-down", name: "Sam" } });
    // a state that passes our checks but a code Google rejects
    await page.goto("/login");
    let cb = "";
    page.on("request", (r) => { if (r.url().includes("/api/auth/google/callback")) cb = r.url(); });
    await page.getByRole("link", { name: "Continue with Google" }).click();
    await page.waitForURL("**/event-types");
    await page.context().clearCookies();
    await page.goto("/login");
    await page.getByRole("link", { name: "Continue with Google" }).click();
    await page.waitForURL("**/event-types");
    expect(cb).toContain("code=good-code");
  });
});
