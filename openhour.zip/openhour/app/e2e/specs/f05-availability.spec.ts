import { DateTime } from "luxon";
import { test, expect, sql, apiBook, apiSlots, weekdayAhead, BASE } from "../fixtures";

const EVENT = "30-minute-meeting";
const local = (slots: { start: string }[], zone = "America/New_York") => slots.map((s) => DateTime.fromISO(s.start, { zone }).toFormat("HH:mm"));
const setRules = async (userId: string, rules: [number, string, string][], tz = "America/New_York") => {
  await sql("update availability_schedules set time_zone = $2 where user_id = $1", [userId, tz]);
  await sql("delete from availability_rules where schedule_id in (select id from availability_schedules where user_id = $1)", [userId]);
  for (const [d, s, e] of rules) await sql("insert into availability_rules (schedule_id, day_of_week, start_time, end_time) select id, $2, $3, $4 from availability_schedules where user_id = $1", [userId, d, s, e]);
};
const nextDow = (dow: number, minDays = 9, zone = "America/New_York") => { let d = DateTime.now().setZone(zone).plus({ days: minDays }); while (d.weekday % 7 !== dow) d = d.plus({ days: 1 }); return d; };
const day = (d: DateTime) => d.toISODate()!;

test.describe("F05 host sets availability", () => {
  test("F05-H1 changing the weekly hours in the screen changes what guests can book", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    for (const d of ["Tuesday", "Wednesday", "Thursday", "Friday"]) await page.getByRole("button", { name: `Remove ${d} range 1` }).click();
    await page.getByLabel("Monday range 1 start").fill("10:00");
    await page.getByLabel("Monday range 1 end").fill("12:00");
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved. New bookings follow these hours.")).toBeVisible();
    const mon = nextDow(1), tue = nextDow(2);
    expect(local((await apiSlots("sam", EVENT, day(mon), day(mon))).slots)).toEqual(["10:00", "10:30", "11:00", "11:30"]);
    expect((await apiSlots("sam", EVENT, day(tue), day(tue))).slots).toHaveLength(0);
  });

  test("F05-H2 a day off removes that day, and only that day", async ({ host }) => {
    const { page } = host;
    const target = weekdayAhead(9), other = weekdayAhead(10);
    await page.goto("/availability");
    await page.getByLabel("Date", { exact: true }).fill(day(target));
    await page.getByRole("button", { name: "Add change" }).click();
    await expect(page.getByRole("listitem").filter({ hasText: "Unavailable all day" })).toBeVisible();
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    expect((await apiSlots("sam", EVENT, day(target), day(target))).slots).toHaveLength(0);
    if (day(other) !== day(target)) expect((await apiSlots("sam", EVENT, day(other), day(other))).slots.length).toBeGreaterThan(0);
  });

  test("F05-H3 special hours on a normally closed day open that day", async ({ host }) => {
    const { page } = host;
    const sat = nextDow(6);
    await page.goto("/availability");
    await page.getByLabel("Date", { exact: true }).fill(day(sat));
    await page.getByLabel("Unavailable all day").uncheck();
    await page.getByLabel("Override start").fill("10:00");
    await page.getByLabel("Override end").fill("12:00");
    await page.getByRole("button", { name: "Add change" }).click();
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    expect(local((await apiSlots("sam", EVENT, day(sat), day(sat))).slots)).toEqual(["10:00", "10:30", "11:00", "11:30"]);
  });

  test("F05-E1 overlapping ranges on one day are refused with a reason, nothing is saved", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    await page.getByRole("button", { name: "Add hours on Monday" }).click();
    await page.getByLabel("Monday range 2 start").fill("16:00");
    await page.getByLabel("Monday range 2 end").fill("18:00");
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "can't overlap" })).toBeVisible();
    const rules = await sql("select id from availability_rules where day_of_week = 1");
    expect(rules).toHaveLength(1);
  });

  test("F05-E2 an end before the start is refused", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    await page.getByLabel("Monday range 1 start").fill("18:00");
    await page.getByLabel("Monday range 1 end").fill("09:00");
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Each range must end after it starts.")).toBeVisible();
  });

  test("F05-E3 two ranges in a day leave a gap, for lunch", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    await page.getByLabel("Monday range 1 end").fill("12:00");
    await page.getByRole("button", { name: "Add hours on Monday" }).click();
    await page.getByLabel("Monday range 2 start").fill("13:00");
    await page.getByLabel("Monday range 2 end").fill("15:00");
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    const t = local((await apiSlots("sam", EVENT, day(nextDow(1)), day(nextDow(1)))).slots);
    expect(t).toContain("11:30");
    expect(t).not.toContain("12:00");
    expect(t).not.toContain("12:30");
    expect(t).toContain("13:00");
    expect(t).not.toContain("15:00");
  });

  test("F05-E4 removing every range for a day marks it unavailable", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    await page.getByRole("button", { name: "Remove Wednesday range 1" }).click();
    await expect(page.getByText("Unavailable").first()).toBeVisible();
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    expect((await apiSlots("sam", EVENT, day(nextDow(3)), day(nextDow(3)))).slots).toHaveLength(0);
  });

  test("F05-E5 moving the hours to another zone moves the times: 9 to 5 in Los Angeles is 12 to 8 in New York", async ({ host }) => {
    await setRules(host.user.id, [[1, "09:00", "17:00"]], "America/Los_Angeles");
    const mon = nextDow(1);
    const t = local((await apiSlots("sam", EVENT, day(mon), day(mon))).slots, "America/New_York");
    expect(t[0]).toBe("12:00");
    expect(t.at(-1)).toBe("19:30");
  });

  test("F05-E6 closing a day that already has a booking keeps the booking and offers nothing more", async ({ host }) => {
    const target = nextDow(2);
    const b = await apiBook("sam", EVENT, { day: target, idx: 0 });
    expect(b.status).toBe(201);
    await sql("insert into date_overrides (schedule_id, on_date, start_time, end_time) select id, $2, null, null from availability_schedules where user_id = $1", [host.user.id, day(target)]);
    expect((await apiSlots("sam", EVENT, day(target), day(target))).slots).toHaveLength(0);
    expect((await sql("select id from bookings where status = 'confirmed'"))).toHaveLength(1);
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Test Guest", { exact: true })).toBeVisible();
  });

  test("F05-E7 the day clocks go back (New York, 1 Nov 2026): 3 real hours is 6 slots, none twice", async ({ host }) => {
    await setRules(host.user.id, [[0, "00:00", "03:00"]]);
    const { slots } = await apiSlots("sam", EVENT, "2026-11-01", "2026-11-01");
    expect(slots).toHaveLength(8); // 00:00-03:00 on a day with an extra hour
    expect(new Set(slots.map((s) => s.start)).size).toBe(8);
    for (let i = 1; i < slots.length; i++) expect(Date.parse(slots[i].start) - Date.parse(slots[i - 1].start)).toBe(30 * 60_000);
  });

  test("F05-E8 the day clocks go forward (New York, 14 Mar 2027): the missing hour is never offered", async ({ host }) => {
    await setRules(host.user.id, [[0, "01:00", "04:00"]]);
    const { slots } = await apiSlots("sam", EVENT, "2027-03-14", "2027-03-14");
    expect(local(slots)).toEqual(["01:00", "01:30", "03:00", "03:30"]);
    expect(slots.map((s) => s.start)).toEqual(["2027-03-14T06:00:00.000Z", "2027-03-14T06:30:00.000Z", "2027-03-14T07:00:00.000Z", "2027-03-14T07:30:00.000Z"]);
  });

  test("F05-E9 a host in a half-hour zone (Kolkata) gets correct instants", async ({ host }) => {
    await setRules(host.user.id, [[1, "09:00", "10:00"]], "Asia/Kolkata");
    const mon = nextDow(1, 9, "Asia/Kolkata");
    const { slots } = await apiSlots("sam", EVENT, day(mon), day(mon));
    expect(slots.map((s) => s.start.slice(11, 16))).toEqual(["03:30", "04:00"]);
  });

  test("F05-E10 a southern-hemisphere host across the end of daylight time (Sydney, 4 Apr 2027)", async ({ host }) => {
    await setRules(host.user.id, [[0, "01:00", "04:00"]], "Australia/Sydney");
    const { slots } = await apiSlots("sam", EVENT, "2027-04-04", "2027-04-04");
    expect(slots.length).toBe(8); // the 02:00-03:00 hour happens twice
    expect(new Set(slots.map((s) => s.start)).size).toBe(8);
  });

  test("F05-E11 saving without changes still says saved, and the hours survive a reload", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    await page.reload();
    await expect(page.getByLabel("Monday range 1 start")).toHaveValue("09:00");
    await expect(page.getByLabel("Friday range 1 end")).toHaveValue("17:00");
    await expect(page.getByLabel("Saturday range 1 start")).toHaveCount(0);
  });

  test("F05-E12 one set of hours drives every event type", async ({ host }) => {
    await sql("insert into event_types (user_id, schedule_id, kind, name, slug, color_index, duration_min, location_type) select user_id, id, 'one_on_one', 'Second', 'second', 2, 60, 'zoom' from availability_schedules where user_id = $1", [host.user.id]);
    await setRules(host.user.id, [[1, "09:00", "11:00"]]);
    const mon = nextDow(1);
    expect(local((await apiSlots("sam", EVENT, day(mon), day(mon))).slots)).toHaveLength(4);
    expect(local((await apiSlots("sam", "second", day(mon), day(mon))).slots)).toEqual(["09:00", "09:30", "10:00"]);
  });

  test("F05-E13 the profile zone and the hours zone are separate: changing the profile does not move working hours", async ({ host }) => {
    const { page } = host;
    await page.goto("/settings");
    await page.locator("#tz").selectOption("Asia/Tokyo");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    const [s] = await sql<{ time_zone: string }>("select time_zone from availability_schedules");
    expect(s.time_zone).toBe("America/New_York");
    const mon = nextDow(1);
    expect(local((await apiSlots("sam", EVENT, day(mon), day(mon))).slots)[0]).toBe("09:00");
  });

  test("F05-E14 a date change for a past or far-future date is accepted and does no harm", async ({ host }) => {
    const { page } = host;
    await page.goto("/availability");
    for (const d of ["2020-01-01", "2035-12-31"]) {
      await page.getByLabel("Date", { exact: true }).fill(d);
      await page.getByRole("button", { name: "Add change" }).click();
    }
    await page.getByRole("button", { name: "Save hours" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    const o = await sql("select on_date from date_overrides order by on_date");
    expect(o).toHaveLength(2);
  });

  test("F05-E15 the weekly editor works with the keyboard and every time field has a name", async ({ host, axe }) => {
    const { page } = host;
    await page.goto("/availability");
    await axe(page, "availability");
    await page.getByRole("button", { name: "Add hours on Saturday" }).focus();
    await page.keyboard.press("Enter");
    await expect(page.getByLabel("Saturday range 1 start")).toBeVisible();
    await page.getByLabel("Saturday range 1 start").focus();
    await page.keyboard.type("1000AM");
    await expect(page.getByLabel("Saturday range 1 start")).toHaveValue("10:00");
  });

  test("F05-N1 an impossible override date is refused, not a server error", async ({ host }) => {
    const r = await fetch(`${BASE}/api/public/sam/${EVENT}/slots?from=2026-02-30&to=2026-02-31`);
    expect(r.status).toBe(400);
    void host;
  });
});
