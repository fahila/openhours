import { test, expect, sql, apiBook, flushJobs, BASE } from "../fixtures";
import fs from "node:fs";

/** Saves a picture of every screen at desktop and phone width for a human to look over. Only runs with SHOTS=<folder>. */
const OUT = process.env.SHOTS;

test("F15-S1 screenshots of every screen, desktop and phone", async ({ host, newPage }) => {
  test.skip(!OUT, "set SHOTS=<folder> to save screenshots");
  fs.mkdirSync(OUT!, { recursive: true });
  const b = await apiBook("sam", "30-minute-meeting", { name: "Screenshot Guest", email: "shot@example.com", notes: "Please bring a laptop and the signed form." });
  await apiBook("sam", "30-minute-meeting", { name: "Another Person With A Long Name Here", email: "long@example.com", idx: 2 });
  await sql("update event_types set description = 'A short call to see if we are a fit.\nBring your questions.'");
  await flushJobs();
  const [et] = await sql<{ id: string }>("select id from event_types");
  const hostPages: [string, string][] = [["event-types", "/event-types"], ["event-type-edit", `/event-types/${et.id}`], ["meetings", "/meetings"], ["availability", "/availability"], ["integrations", "/integrations"], ["settings", "/settings"]];
  for (const [w, h, tag] of [[1280, 900, "desktop"], [390, 844, "phone"]] as const) {
    const p = await newPage({ tz: "America/New_York", width: w, height: h });
    await p.context().addCookies(await host.page.context().cookies());
    for (const [name, path] of hostPages) { await p.goto(path); await p.screenshot({ path: `${OUT}/${name}-${tag}.png`, fullPage: true }); }
    const g = await newPage({ tz: "Europe/Paris", width: w, height: h });
    for (const [name, path] of [["profile", "/sam"], ["privacy", "/privacy"], ["not-found", "/nobody"], ["manage", `/m/${b.token}`], ["confirmed", `/booked/${b.token}`], ["login", "/login"]] as const) { await g.goto(path); await g.screenshot({ path: `${OUT}/guest-${name}-${tag}.png`, fullPage: true }); }
    await g.goto("/sam/30-minute-meeting");
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.screenshot({ path: `${OUT}/guest-booking-pick-${tag}.png`, fullPage: true });
    await g.locator('button[data-day]:not([aria-disabled="true"])').nth(1).click();
    await g.screenshot({ path: `${OUT}/guest-booking-times-${tag}.png`, fullPage: true });
    await g.locator('ul[aria-label="Available times"] button').first().click();
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.screenshot({ path: `${OUT}/guest-booking-errors-${tag}.png`, fullPage: true });
  }
  expect(fs.readdirSync(OUT!).length).toBeGreaterThanOrEqual(30);
  void BASE;
});
