import { test, expect, sql, apiBook, noHorizontalScroll, mockControl, BASE } from "../fixtures";

const EVENT = "30-minute-meeting";

test.describe("F13 every screen: accessibility, phone width, keyboard", () => {
  const hostScreens: [string, string][] = [
    ["event types", "/event-types"], ["new event type", "/event-types/new"], ["meetings", "/meetings"], ["availability", "/availability"],
    ["integrations", "/integrations"], ["settings", "/settings"], ["workflows (not built)", "/workflows"], ["one-time links (not built)", "/single-use-links"],
  ];

  test("F13-A1 every host screen has no accessibility violations (with data on screen)", async ({ host, axe }) => {
    await apiBook("sam", EVENT, { name: "Axe Guest", email: "axeg@example.com", notes: "a note" });
    for (const [label, path] of hostScreens) {
      await host.page.goto(path);
      await expect(host.page.locator("main")).toBeVisible();
      await axe(host.page, label);
    }
    const [et] = await sql<{ id: string }>("select id from event_types");
    await host.page.goto(`/event-types/${et.id}`);
    await axe(host.page, "edit event type");
    await host.page.goto("/meetings");
    await host.page.getByRole("tab", { name: /Past and cancelled/ }).click();
    await axe(host.page, "meetings, past tab");
  });

  test("F13-A2 the guest screens and error pages have no accessibility violations", async ({ host, newPage, axe }) => {
    const g = await newPage();
    const b = await apiBook("sam", EVENT, { name: "Axe Guest", email: "axeg@example.com" });
    for (const path of ["/sam", "/privacy", "/left", "/login", "/nobody", `/m/${b.token}`, `/booked/${b.token}`]) {
      await g.goto(path);
      await axe(g, path);
    }
    void host;
  });

  test("F13-A3 dialogs: opening moves focus inside, Tab stays inside, Escape closes and focus returns", async ({ host, newPage }) => {
    await apiBook("sam", EVENT, { name: "Dialog Guest", email: "dlg@example.com" });
    await host.page.goto("/meetings");
    const opener = host.page.getByRole("button", { name: /Cancel meeting with Dialog Guest/ });
    await opener.click();
    const dialog = host.page.getByRole("dialog");
    await expect(dialog).toBeVisible();
    for (let i = 0; i < 8; i++) {
      await host.page.keyboard.press("Tab");
      expect(await host.page.evaluate(() => !!document.activeElement?.closest('[role="dialog"]')), `Tab ${i + 1} left the dialog`).toBe(true);
    }
    await host.page.keyboard.press("Escape");
    await expect(dialog).toBeHidden();
    await expect(opener).toBeFocused();
    void newPage;
  });

  test("F13-A4 the delete and disconnect dialogs are labelled and keyboard operable", async ({ host, axe }) => {
    const [et] = await sql<{ id: string }>("select id from event_types");
    await host.page.goto(`/event-types/${et.id}`);
    await host.page.getByRole("button", { name: "Delete" }).click();
    await expect(host.page.getByRole("dialog", { name: "Delete this event type?" })).toBeVisible();
    await axe(host.page, "delete dialog");
    await host.page.keyboard.press("Escape");
    await host.page.goto("/integrations");
    await host.page.getByRole("link", { name: "Connect Google Calendar" }).click();
    await host.page.waitForURL("**/integrations?calendar=connected");
    await host.page.getByRole("button", { name: "Disconnect" }).click();
    await expect(host.page.getByRole("dialog", { name: "Disconnect this account?" })).toBeVisible();
    await axe(host.page, "disconnect dialog");
  });

  test("F13-M1 every host and guest screen fits a 390px phone with no sideways scrolling", async ({ host, newPage }) => {
    await apiBook("sam", EVENT, { name: "N".repeat(60), email: "phone@example.com", notes: "x".repeat(300) });
    const phone = await newPage({ tz: "America/New_York", width: 390, height: 844 });
    await phone.context().addCookies(await host.page.context().cookies());
    for (const [label, path] of hostScreens) {
      await phone.goto(path);
      expect(await noHorizontalScroll(phone), label).toBe(true);
    }
    const [row] = await sql<{ id: string }>("select id from event_types");
    await phone.goto(`/event-types/${row.id}`);
    expect(await noHorizontalScroll(phone), "edit event type").toBe(true);
    for (const path of ["/sam", `/sam/${EVENT}`, "/privacy", "/login", "/left", "/nobody"]) {
      await phone.goto(path);
      expect(await noHorizontalScroll(phone), path).toBe(true);
    }
  });

  test("F13-M2 on a phone the host navigation is reachable and every nav link works", async ({ host, newPage }) => {
    const phone = await newPage({ tz: "America/New_York", width: 390, height: 844 });
    await phone.context().addCookies(await host.page.context().cookies());
    await phone.goto("/event-types");
    for (const [name, url] of [["Meetings", /meetings/], ["Availability", /availability/], ["Integrations", /integrations/], ["Settings", /settings/], ["Event types", /event-types/]] as const) {
      await phone.getByRole("navigation", { name: "Main" }).getByRole("link", { name }).click();
      await expect(phone).toHaveURL(url);
    }
  });

  test("F13-M3 text can be enlarged to 200% without losing content or overflowing", async ({ host, newPage }) => {
    const g = await newPage({ tz: "America/New_York", width: 1280, height: 900 });
    await g.goto(`/sam/${EVENT}`);
    await g.addStyleTag({ content: "html { font-size: 200% !important; }" });
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    expect(await noHorizontalScroll(g)).toBe(true);
    await expect(g.getByRole("heading", { name: "30 minute meeting" })).toBeVisible();
    void host;
  });

  test("F13-K1 the whole host nav and the main actions are reachable by keyboard with a visible focus", async ({ host }) => {
    const { page } = host;
    await page.goto("/event-types");
    await page.keyboard.press("Tab");
    const seen = new Set<string>();
    for (let i = 0; i < 25; i++) {
      const info = await page.evaluate(() => {
        const el = document.activeElement as HTMLElement | null;
        if (!el || el === document.body || el.tagName === "NEXTJS-PORTAL") return null; // the dev server's own overlay, absent in production
        const cs = getComputedStyle(el);
        const outlined = cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0;
        return { name: (el.getAttribute("aria-label") || el.textContent || el.tagName).trim().slice(0, 30), outlined };
      });
      if (info) { seen.add(info.name); expect(info.outlined, `focus ring on "${info.name}"`).toBe(true); }
      await page.keyboard.press("Tab");
    }
    for (const n of ["Event types", "Meetings", "Availability", "Settings"]) expect([...seen].some((s) => s.includes(n)), `nav item ${n} is reachable`).toBe(true);
  });

  test("F13-K2 colour is never the only signal: statuses and errors always have text", async ({ host, newPage }) => {
    const b = await apiBook("sam", EVENT, { name: "Status Guest", email: "status@example.com" });
    await fetch(`${BASE}/m/${b.token}/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    await host.page.goto("/meetings");
    await host.page.getByRole("tab", { name: /Past and cancelled/ }).click();
    await expect(host.page.getByText("Cancelled", { exact: true })).toBeVisible();
    await host.page.goto("/event-types");
    await expect(host.page.getByText("Active", { exact: true })).toBeVisible();
    void newPage;
  });

  test("F13-K3 page titles say where you are", async ({ host, newPage }) => {
    const titles: [string, RegExp][] = [["/event-types", /./], ["/login", /Sign in/], ["/privacy", /How your details/], ["/sam", /Book time with Sam Rivera/], [`/sam/${EVENT}`, /30 minute meeting with Sam Rivera/]];
    const g = await newPage();
    for (const [path, re] of titles) { await g.goto(path); expect(await g.title(), path).toMatch(re); }
    void host; void mockControl;
  });
});
