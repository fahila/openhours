import { test, expect, sql, BASE, mockState } from "../fixtures";

test.describe("F10 host manages their account", () => {
  test("F10-H1 name, link name, zone and welcome message save and show on the public page", async ({ host, newPage }) => {
    const { page } = host;
    await page.goto("/settings");
    await page.getByLabel(/^Name/).fill("Samantha Rivera");
    await page.getByLabel(/^Link name/).fill("samantha");
    await page.getByLabel("Welcome message").fill("Welcome! Pick a time.");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    const g = await newPage();
    await g.goto("/samantha");
    await expect(g.getByRole("heading", { name: "Samantha Rivera" })).toBeVisible();
    await expect(g.getByText("Welcome! Pick a time.")).toBeVisible();
    expect((await fetch(`${BASE}/sam`)).status).toBe(404);
  });

  test("F10-E1 reserved words, spaces, capitals, symbols and too-short link names are refused with a reason", async ({ host }) => {
    const { page } = host;
    await page.goto("/settings");
    for (const bad of ["login", "settings", "api", "x", "has space", "emoji☕", "a".repeat(40), "-leading"]) {
      await page.getByLabel(/^Link name/).fill(bad);
      await page.getByRole("button", { name: "Save profile" }).click();
      await expect(page.getByText(/Use 2 to 39 lowercase letters, numbers or dashes|That link name is taken/), bad).toBeVisible();
    }
    const [u] = await sql<{ slug: string }>("select slug from users");
    expect(u.slug).toBe("sam");
    // capitals are tidied rather than refused
    await page.getByLabel(/^Link name/).fill("  Tidy-Name ");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText("Saved.")).toBeVisible();
    expect((await sql<{ slug: string }>("select slug from users"))[0].slug).toBe("tidy-name");
  });

  test("F10-E2 a link name another person already uses is refused", async ({ host, newPage, login }) => {
    const other = await newPage();
    await login(other, { email: "second@example.com", name: "Someone Else", sub: "g-2" });
    await sql("update users set slug = 'taken' where email = 'second@example.com'");
    await host.page.goto("/settings");
    await host.page.getByLabel(/^Link name/).fill("taken");
    await host.page.getByRole("button", { name: "Save profile" }).click();
    await expect(host.page.getByText("That link name is taken.")).toBeVisible();
  });

  test("F10-E3 a failed save keeps what you typed (no silent reset to the old values)", async ({ host }) => {
    const { page } = host;
    await page.goto("/settings");
    await page.getByLabel(/^Name/).fill("Typed Name");
    await page.getByLabel(/^Link name/).fill("login");
    await page.getByLabel("Welcome message").fill("Typed welcome message");
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText(/not a reserved word/)).toBeVisible();
    await expect(page.getByLabel(/^Name/)).toHaveValue("Typed Name");
    await expect(page.getByLabel(/^Link name/)).toHaveValue("login");
    await expect(page.getByLabel("Welcome message")).toHaveValue("Typed welcome message");
  });

  test("F10-E4 an empty name and an over-long welcome message are refused", async ({ host }) => {
    const { page } = host;
    await page.goto("/settings");
    await page.getByLabel(/^Name/).fill("");
    await page.getByLabel("Welcome message").evaluate((el: HTMLTextAreaElement) => el.removeAttribute("maxlength"));
    await page.getByLabel("Welcome message").fill("w".repeat(501));
    await page.getByRole("button", { name: "Save profile" }).click();
    await expect(page.getByText("Enter your name (up to 120 characters).")).toBeVisible();
    await expect(page.getByText("Keep the welcome message under 500 characters.")).toBeVisible();
  });

  test("F10-E5 changing the link name keeps old guests' manage links working", async ({ host }) => {
    const { apiBook } = await import("../fixtures");
    const b = await apiBook("sam", "30-minute-meeting");
    await host.page.goto("/settings");
    await host.page.getByLabel(/^Link name/).fill("newname");
    await host.page.getByRole("button", { name: "Save profile" }).click();
    await expect(host.page.getByText("Saved.")).toBeVisible();
    expect((await fetch(`${BASE}/m/${b.token}`)).status).toBe(200);
    expect((await fetch(`${BASE}/newname/30-minute-meeting`)).status).toBe(200);
  });

  test("F10-E6 'Your booking page' in the sidebar follows the link name", async ({ host }) => {
    await host.page.goto("/event-types");
    await expect(host.page.getByRole("link", { name: "Your booking page" })).toHaveAttribute("href", "/sam");
  });

  test("F10-E7 deleting the account needs the exact email, and removes everything including paid bookings", async ({ host }) => {
    const { apiBook } = await import("../fixtures");
    await apiBook("sam", "30-minute-meeting");
    await sql("insert into payments (booking_id, provider_session_id, amount_cents, currency, status) select id, 'cs_x', 1000, 'usd', 'paid' from bookings");
    const { page } = host;
    await page.goto("/settings");
    await page.getByLabel(/^Type owner@example.com/).fill("OWNER@example.com ");
    await page.getByRole("button", { name: "Delete my account" }).click();
    await page.waitForURL("**/login?error=deleted", { timeout: 20_000 });
    for (const t of ["users", "event_types", "bookings", "booking_invitees", "payments", "sessions", "workflows", "availability_schedules"]) {
      expect((await sql(`select 1 from ${t}`)).length, t).toBe(0);
    }
    expect((await fetch(`${BASE}/sam`)).status).toBe(404);
  });

  test("F10-N1 'Sign out' ends only this device; 'Sign out on every device' ends all", async ({ host, newPage, login }) => {
    const other = await newPage({ tz: "America/New_York" });
    await login(other);
    await host.page.goto("/settings");
    await host.page.getByRole("button", { name: "Sign out", exact: true }).click();
    await host.page.waitForURL("**/login");
    await other.goto("/event-types");
    await expect(other.getByRole("heading", { name: "Event types" })).toBeVisible();
    await other.goto("/settings");
    await other.getByRole("button", { name: "Sign out on every device" }).click();
    await other.waitForURL("**/login");
    expect(await sql("select id from sessions")).toHaveLength(0);
  });

  test("F10-A1 the settings screen passes an accessibility scan, with and without errors", async ({ host, axe }) => {
    await host.page.goto("/settings");
    await axe(host.page, "settings");
    await host.page.getByLabel(/^Link name/).fill("login");
    await host.page.getByRole("button", { name: "Save profile" }).click();
    await expect(host.page.getByText(/not a reserved word/)).toBeVisible();
    await axe(host.page, "settings with error");
  });
});
