import { DateTime } from "luxon";
import { test, expect, sql, apiSlots, flushJobs, emailsTo, BASE } from "../fixtures";

const EVENT = "30-minute-meeting";
const setHours = async (userId: string, tz: string, rules: [number, string, string][]) => {
  await sql("update availability_schedules set time_zone = $2 where user_id = $1", [userId, tz]);
  await sql("delete from availability_rules where schedule_id in (select id from availability_schedules where user_id = $1)", [userId]);
  for (const [d, s, e] of rules) await sql("insert into availability_rules (schedule_id, day_of_week, start_time, end_time) select id, $2, $3, $4 from availability_schedules where user_id = $1", [userId, d, s, e]);
};
const allDays = (s: string, e: string): [number, string, string][] => [0, 1, 2, 3, 4, 5, 6].map((d) => [d, s, e]);
const labelsOn = async (g: import("@playwright/test").Page, ymd: string) => {
  await g.locator(`button[data-day="${ymd}"]`).click();
  return g.locator('ul[aria-label="Available times"] button').allInnerTexts();
};

test.describe("F14 time zones and daylight saving", () => {
  test("F14-H1 a London host and a New York guest: the gap between them changes on 25 Oct and 1 Nov, and the page follows", async ({ host, newPage }) => {
    await setHours(host.user.id, "Europe/London", allDays("09:00", "10:00"));
    await sql("update event_types set min_notice_min = 0");
    const g = await newPage({ tz: "America/New_York" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    // 22 Oct: London is on summer time (UTC+1): 09:00 there is 04:00 in New York
    expect((await labelsOn(g, "2026-10-22"))[0]).toBe("4:00 AM");
    // 27 Oct: London is back on UTC, New York is still on summer time (UTC-4): 09:00 there is 05:00
    expect((await labelsOn(g, "2026-10-27"))[0]).toBe("5:00 AM");
    await g.getByRole("button", { name: "Next month" }).click();
    await g.waitForSelector('button[data-day="2026-11-03"]:not([aria-disabled="true"])');
    // 3 Nov: both on winter time: 09:00 in London is 04:00 in New York again
    expect((await labelsOn(g, "2026-11-03"))[0]).toBe("4:00 AM");
  });

  test("F14-E1 the day clocks go back, the same wall-clock time happens twice: the page tells the two apart", async ({ host, newPage }) => {
    await setHours(host.user.id, "America/New_York", [[0, "00:00", "03:00"]]);
    await sql("update event_types set min_notice_min = 0");
    const g = await newPage({ tz: "America/New_York" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.getByRole("button", { name: "Next month" }).click();
    await g.waitForSelector('button[data-day="2026-11-01"]:not([aria-disabled="true"])');
    const labels = await labelsOn(g, "2026-11-01");
    expect(labels).toHaveLength(8);
    expect(new Set(labels).size, `two buttons read the same: ${labels.join(" | ")}`).toBe(8);
    expect(labels.filter((l) => /EDT/.test(l)).length + labels.filter((l) => /EST/.test(l)).length).toBeGreaterThanOrEqual(4);
  });

  test("F14-E2 a booking made in the repeated hour is stored at the right instant and shown with its zone name", async ({ host, newPage }) => {
    await setHours(host.user.id, "America/New_York", [[0, "00:00", "03:00"]]);
    await sql("update event_types set min_notice_min = 0");
    const { slots } = await apiSlots("sam", EVENT, "2026-11-01", "2026-11-01");
    const second130 = slots.find((s) => s.start === "2026-11-01T06:30:00.000Z")!; // 01:30 EST, the second time round
    expect(second130).toBeTruthy();
    const g = await newPage({ tz: "America/New_York" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    await g.getByRole("button", { name: "Next month" }).click();
    await g.waitForSelector('button[data-day="2026-11-01"]:not([aria-disabled="true"])');
    await g.locator('button[data-day="2026-11-01"]').click();
    await g.locator('ul[aria-label="Available times"] button', { hasText: /1:30 AM.*EST/ }).click();
    await g.getByLabel(/^Name/).fill("Repeat Hour");
    await g.getByLabel(/^Email/).fill("repeat@example.com");
    await g.getByRole("button", { name: "Book this time" }).click();
    await g.waitForURL("**/booked/**");
    const [b] = await sql<{ start_at: Date }>("select start_at from bookings");
    expect(b.start_at.toISOString()).toBe("2026-11-01T06:30:00.000Z");
    await flushJobs();
    const mail = (await emailsTo("repeat@example.com"))[0];
    expect(mail.text).toMatch(/EST/);
  });

  test("F14-E3 half-hour and 45-minute zones read correctly: a Kolkata host seen from Kathmandu", async ({ host, newPage }) => {
    await setHours(host.user.id, "Asia/Kolkata", [[1, "09:00", "10:00"], [2, "09:00", "10:00"], [3, "09:00", "10:00"], [4, "09:00", "10:00"], [5, "09:00", "10:00"]]);
    const g = await newPage({ tz: "Asia/Kathmandu" });
    await g.goto(`/sam/${EVENT}`);
    await g.waitForSelector('button[data-day]:not([aria-disabled="true"])');
    const first = g.locator('button[data-day]:not([aria-disabled="true"])').first();
    await first.click();
    const t = await g.locator('ul[aria-label="Available times"] button').allInnerTexts();
    expect(t).toEqual(["9:15 AM", "9:45 AM"]); // 09:00 and 09:30 in Kolkata are 15 minutes later in Kathmandu
  });

  test("F14-E4 changing the hours' zone later does not move meetings already booked", async ({ host }) => {
    const { apiBook } = await import("../fixtures");
    const b = await apiBook("sam", EVENT, { name: "Stays Put", email: "stays@example.com" });
    await setHours(host.user.id, "Pacific/Auckland", allDays("09:00", "17:00"));
    const [row] = await sql<{ start_at: Date }>("select start_at from bookings");
    expect(row.start_at.toISOString()).toBe(b.slot.start);
    await host.page.goto("/meetings");
    await expect(host.page.getByText("Stays Put", { exact: true })).toBeVisible();
  });

  test("F14-E5 the host sees meetings in their profile zone, whatever the guest's zone is", async ({ host }) => {
    const { apiBook } = await import("../fixtures");
    const b = await apiBook("sam", EVENT, { name: "Far Away", email: "faraway@example.com", tz: "Pacific/Kiritimati" });
    await host.page.goto("/meetings");
    const expected = DateTime.fromISO(b.slot.start, { zone: "America/New_York" }).toFormat("h:mm a");
    await expect(host.page.getByText(expected, { exact: false }).first()).toBeVisible();
  });

  test("F14-E6 a guest's own zone name appears in their confirmation email", async ({ host }) => {
    const { apiBook } = await import("../fixtures");
    await apiBook("sam", EVENT, { name: "Tokyo Tom", email: "tom@example.com", tz: "Asia/Tokyo" });
    await flushJobs();
    expect((await emailsTo("tom@example.com"))[0].text).toMatch(/GMT\+9|JST/);
    void host; void BASE;
  });
});
