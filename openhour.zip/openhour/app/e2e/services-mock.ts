/**
 * One local server that plays Google (OAuth + Calendar), Resend and Stripe for the browser run.
 *   tsx e2e/services-mock.ts <port> <app url>
 * Inspect with GET /__state, change behaviour with POST /__control, reset with POST /__reset.
 */
import Stripe from "stripe";
import { json, startMock } from "../tests/mock";
import { makeGoogleHandler, newGoogleState } from "../tests/google-mock";

const port = Number(process.argv[2] ?? 4010);
const app = process.argv[3] ?? "http://localhost:3055";
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET ?? "whsec_e2e";

let g = newGoogleState();
const emails: Record<string, unknown>[] = [];
const sessions = new Map<string, { success_url: string; cancel_url: string; booking_id: string; amount: string; currency: string; payment_status: string }>();
const stripeLog = { expired: [] as string[], refunds: [] as string[] };
let n = 0;
const faults = { failEmails: 0, failCheckout: false, failExpire: false };
const googleHandler = (...a: Parameters<ReturnType<typeof makeGoogleHandler>>) => makeGoogleHandler(g)(...a);

async function main() {
const server = await startMock(async (req, res) => {
  const url = new URL(req.path, "http://x");
  const p = url.pathname;

  if (p === "/__state") {
    return json(res, 200, {
      emails, stripe: { sessions: Object.fromEntries(sessions), ...stripeLog },
      google: { events: [...g.events].map(([id, e]) => ({ id, calendarId: e.calendarId, body: e.body })), deleted: g.deleted, revoked: g.revoked },
    });
  }
  if (p === "/__control" && req.method === "POST") {
    const patch = JSON.parse(req.body) as Record<string, unknown>;
    if (patch.profile) Object.assign(g.profile, patch.profile);
    if (typeof patch.failEmails === "number") faults.failEmails = patch.failEmails;
    if (typeof patch.failCheckout === "boolean") faults.failCheckout = patch.failCheckout;
    for (const k of ["scope", "rejectApiTokens", "failFreebusy", "failEventInsert", "meetAfterGets", "nextRefreshToken", "busy", "calendarErrors"] as const) if (k in patch) (g as unknown as Record<string, unknown>)[k] = patch[k];
    if (Array.isArray(patch.extraCalendars)) g.calendars.push(...(patch.extraCalendars as typeof g.calendars));
    if (Array.isArray(patch.revokeRefresh)) for (const t of patch.revokeRefresh) g.revokedRefreshTokens.add(t as string);
    return json(res, 200, { ok: true });
  }
  if (p === "/__reset" && req.method === "POST") {
    g = newGoogleState(); faults.failEmails = 0; faults.failCheckout = false; emails.length = 0; sessions.clear(); stripeLog.expired.length = 0; stripeLog.refunds.length = 0;
    return json(res, 200, { ok: true });
  }

  // Resend
  if (p === "/emails" && req.method === "POST") {
    if (!req.headers.authorization?.startsWith("Bearer re_")) return json(res, 401, { message: "bad key" });
    if (faults.failEmails > 0) { faults.failEmails--; return json(res, 500, { message: "resend is down" }); }
    const b = JSON.parse(req.body);
    emails.push({ ...b, idempotencyKey: req.headers["idempotency-key"] });
    return json(res, 200, { id: `em_${emails.length}` });
  }

  // Stripe API
  if (p === "/v1/checkout/sessions" && req.method === "POST") {
    if (faults.failCheckout) return json(res, 500, { error: { type: "api_error", message: "stripe is down" } });
    const f = new URLSearchParams(req.body);
    const id = `cs_test_${++n}`;
    sessions.set(id, {
      success_url: f.get("success_url")!, cancel_url: f.get("cancel_url")!, booking_id: f.get("metadata[booking_id]")!,
      amount: f.get("line_items[0][price_data][unit_amount]")!, currency: f.get("line_items[0][price_data][currency]")!, payment_status: "unpaid",
    });
    return json(res, 200, { id, object: "checkout.session", url: `http://127.0.0.1:${port}/pay/${id}`, payment_status: "unpaid" });
  }
  const exp = p.match(/^\/v1\/checkout\/sessions\/([^/]+)\/expire$/);
  if (exp && req.method === "POST") {
    if (sessions.get(exp[1])?.payment_status === "paid") return json(res, 400, { error: { type: "invalid_request_error", message: "Only open sessions can be expired" } });
    stripeLog.expired.push(exp[1]);
    return json(res, 200, { id: exp[1], object: "checkout.session", status: "expired" });
  }
  if (p === "/v1/refunds" && req.method === "POST") {
    stripeLog.refunds.push(new URLSearchParams(req.body).get("payment_intent") ?? "");
    return json(res, 200, { id: "re_1", object: "refund", status: "succeeded" });
  }

  // Stand-in for Stripe's hosted payment page
  const pay = p.match(/^\/pay\/([^/]+)$/);
  if (pay) {
    const s = sessions.get(pay[1]);
    res.setHeader("Content-Type", "text/html");
    return void res.end(`<!doctype html><title>Mock checkout</title><h1>Mock checkout</h1><p>${s ? `${(Number(s.amount) / 100).toFixed(2)} ${s.currency.toUpperCase()}` : "unknown"}</p><a id="pay" href="/pay/${pay[1]}/complete">Pay</a> <a id="back" href="${s?.cancel_url ?? "#"}">Back</a>`);
  }
  const done = p.match(/^\/pay\/([^/]+)\/complete$/);
  if (done) {
    const s = sessions.get(done[1]);
    if (!s) return json(res, 404, {});
    s.payment_status = "paid";
    const payload = JSON.stringify({ id: `evt_${++n}`, object: "event", type: "checkout.session.completed", created: Math.floor(Date.now() / 1000), data: { object: { id: done[1], object: "checkout.session", payment_status: "paid", payment_intent: `pi_${done[1]}` } } });
    const sig = new Stripe("sk_test_x").webhooks.generateTestHeaderString({ payload, secret: WEBHOOK_SECRET });
    // a real Stripe retries until it gets a 2xx; the browser leaves straight away either way
    fetch(`${app}/api/webhooks/stripe`, { method: "POST", headers: { "stripe-signature": sig, "content-type": "application/json" }, body: payload }).catch(() => {});
    res.statusCode = 302;
    res.setHeader("Location", s.success_url);
    return void res.end();
  }

  googleHandler(req, res);
}, port);

console.log(`ready ${server.url}`);
process.on("SIGTERM", () => server.close().then(() => process.exit(0)));
process.on("SIGINT", () => server.close().then(() => process.exit(0)));
}

main().catch((e) => { console.error(e); process.exit(1); });
