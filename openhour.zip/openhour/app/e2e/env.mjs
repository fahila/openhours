import { randomBytes } from "node:crypto";

/** Shared by the stack launcher and the specs. */
export const APP_PORT = 3055;
export const MOCK_PORT = 4010;
export const BASE = `http://localhost:${APP_PORT}`;
export const MOCK = `http://127.0.0.1:${MOCK_PORT}`;
export const PG = process.env.TEST_PG ?? "postgres://postgres@127.0.0.1:5545";
export const DB_NAME = "scheduler_e2e";
export const DATABASE_URL = `${PG}/${DB_NAME}`;
export const CRON = "cron-secret-for-e2e";
export const WEBHOOK_SECRET = "whsec_e2e";
// a fixed key keeps the suite repeatable; it only protects throwaway test data
export const KEY = process.env.E2E_KEY ?? Buffer.from("e2e-key-e2e-key-e2e-key-e2e-key-").toString("base64");
export const randomKey = () => randomBytes(32).toString("base64");
