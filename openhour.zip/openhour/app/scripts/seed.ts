import { randomBytes } from "node:crypto";
import { DateTime } from "luxon";
import { createBooking, createUserWithDefaults, getUserByEmail, listEventTypes, listSchedules, saveEventType, saveSchedule, getSlots, getEventType } from "../lib/data";
import { closePool, query } from "../lib/db";
import { env } from "../lib/env";

/**
 * Fake data for local development. Every person here is invented and every address is example.com.
 * Refuses to run in production, and refuses to touch a database that already has users unless --force.
 *   npm run db:seed            demo host: demo@example.com, booking page /demo
 */
async function main() {
  if (env().isProd) throw new Error("Refusing to seed a production database");
  const existing = await getUserByEmail("demo@example.com");
  const has = existing ? Number((await query<{ n: string }>("select count(*) as n from bookings where host_id = $1", [existing.id]))[0].n) : 0;
  if (has > 0 && !process.argv.includes("--force")) { console.log("Demo data is already there. Use --force to add more bookings."); return; }
  const user = existing ?? (await createUserWithDefaults({ email: "demo@example.com", name: "Demo Host" }));
  const zone = "America/New_York";
  const [sch] = await listSchedules(user.id);
  await saveSchedule(user.id, sch.id, { name: sch.name, timeZone: zone, rules: sch.rules, overrides: [] });
  await query("update users set time_zone = $2, welcome_message = $3 where id = $1", [user.id, zone, "Pick a time that suits you."]);

  const base = {
    scheduleId: sch.id, description: null, colorIndex: 1, maxInvitees: 1, locationValue: null, bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 240,
    rollingDays: 60, startIncrementMin: 30, limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null,
    requirePayment: false, priceCents: null, currency: null,
  };
  const have = new Set((await listEventTypes(user.id)).map((e) => e.slug));
  const deep = have.has("deep-dive") ? null : await saveEventType(user.id, null, { ...base, kind: "one_on_one", name: "Deep dive working session", slug: "deep-dive", colorIndex: 2, durationMin: 60, locationType: "zoom", bufferBeforeMin: 15, bufferAfterMin: 15, limitPerDay: 2 });
  const hours = have.has("office-hours") ? null : await saveEventType(user.id, null, { ...base, kind: "group", name: "Open office hours", slug: "office-hours", colorIndex: 3, durationMin: 60, maxInvitees: 5, locationType: "in_person", locationValue: "Studio 4, 12 Canal Street" });
  const intro = (await listEventTypes(user.id)).find((e) => e.slug === "30-minute-meeting")!;

  const people = [["Ada Example", "ada"], ["Ben Sample", "ben"], ["Cleo Placeholder", "cleo"]];
  const from = DateTime.now().plus({ days: 2 }).toISODate()!;
  for (const [i, et] of [intro, deep ?? intro, hours ?? intro].entries()) {
    const full = (await getEventType(user.id, et.id))!;
    const slots = await getSlots(full, from, DateTime.fromISO(from).plus({ days: 10 }).toISODate()!);
    const [name, handle] = people[i];
    if (slots[i * 3]) await createBooking({ eventTypeId: full.id, startAt: slots[i * 3].start, name, email: `${handle}@example.com`, timeZone: "Europe/London" });
  }
  // two meetings in the past, inserted directly because the slot rules rightly refuse past times
  for (const [n, [name, handle]] of [["Dev Fixture", "dev"], ["Eli Test", "eli"]].entries()) {
    const start = DateTime.now().setZone(zone).minus({ days: 3 + n }).set({ hour: 11, minute: 0, second: 0, millisecond: 0 });
    const b = (await query<{ id: string }>("insert into bookings (event_type_id, host_id, start_at, end_at, status) values ($1, $2, $3, $4, 'confirmed') returning id", [intro.id, user.id, start.toUTC().toISO(), start.plus({ minutes: 30 }).toUTC().toISO()]))[0];
    await query("insert into booking_invitees (booking_id, name, email, time_zone, manage_token_hash) values ($1, $2, $3, 'Europe/London', $4)", [b.id, name, `${handle}@example.com`, randomBytes(32)]);
  }
  console.log("Seeded. Sign in as demo@example.com (DEV_LOGIN=1) and open /demo");
}

main().catch((e) => { console.error(e.message); process.exit(1); }).finally(closePool);
