import { closePool } from "../lib/db";
import { runDueJobs } from "../lib/jobs/run";

/** Self-hosting alternative to a scheduler hitting /api/jobs/run: `npm run worker`. */
let stop = false;
for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { stop = true; });

(async () => {
  console.log("worker started");
  while (!stop) {
    try {
      const s = await runDueJobs(10_000);
      if (s.ran || s.failed) console.log(JSON.stringify({ level: "info", msg: "jobs run", ...s }));
    } catch (e) {
      console.error(JSON.stringify({ level: "error", msg: "worker loop", error: e instanceof Error ? e.message : String(e) }));
    }
    await new Promise((r) => setTimeout(r, 15_000));
  }
  await closePool();
})();
