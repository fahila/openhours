import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { Client } from "pg";

/** Applies db/migrations/*.sql in order, each in its own transaction, and refuses to run if an applied file was edited. */
export async function migrate(url: string, log: (m: string) => void = console.log) {
  const dir = path.join(process.cwd(), "db", "migrations");
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".sql")).sort();
  const c = new Client({ connectionString: url });
  await c.connect();
  try {
    await c.query("create table if not exists schema_migrations (name text primary key, checksum text not null, applied_at timestamptz not null default now())");
    const applied = new Map((await c.query("select name, checksum from schema_migrations")).rows.map((r) => [r.name, r.checksum]));
    for (const f of files) {
      const sql = fs.readFileSync(path.join(dir, f), "utf8");
      const sum = createHash("sha256").update(sql).digest("hex");
      if (applied.has(f)) {
        if (applied.get(f) !== sum) throw new Error(`Migration ${f} was changed after it was applied. Add a new migration instead.`);
        continue;
      }
      await c.query("begin");
      try {
        await c.query(sql);
        await c.query("insert into schema_migrations (name, checksum) values ($1, $2)", [f, sum]);
        await c.query("commit");
        log(`applied ${f}`);
      } catch (e) {
        await c.query("rollback");
        throw e;
      }
    }
    if (files.every((f) => applied.has(f))) log("up to date");
  } finally {
    await c.end();
  }
}

if (process.argv[1]?.endsWith("migrate.ts")) {
  const url = process.env.DATABASE_URL;
  if (!url) { console.error("DATABASE_URL is not set"); process.exit(1); }
  migrate(url).catch((e) => { console.error(e.message); process.exit(1); });
}
