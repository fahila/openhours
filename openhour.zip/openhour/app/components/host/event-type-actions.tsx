"use client";

import { useState, useTransition } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toggleActiveAction } from "@/app/(host)/event-types/actions";

export function CopyLinkButton({ path }: { path: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      size="sm"
      variant="secondary"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(window.location.origin + path);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        } catch {
          window.prompt("Copy this link", window.location.origin + path);
        }
      }}
    >
      {copied ? <Check aria-hidden className="size-4" /> : <Copy aria-hidden className="size-4" />}
      {copied ? "Copied" : "Copy link"}
      <span aria-live="polite" className="sr-only">{copied ? "Link copied" : ""}</span>
    </Button>
  );
}

export function ActiveSwitch({ id, name, active }: { id: string; name: string; active: boolean }) {
  const [pending, start] = useTransition();
  return (
    <Switch
      label={`${name} is ${active ? "on" : "off"}`}
      checked={active}
      disabled={pending}
      onCheckedChange={(v) => start(() => toggleActiveAction(id, v))}
    />
  );
}
