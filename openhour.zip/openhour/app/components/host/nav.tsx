"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CalendarClock, CalendarDays, Clock, Link2, Plug, Settings, Workflow } from "lucide-react";
import { cn } from "@/lib/cn";

const ITEMS = [
  { href: "/event-types", label: "Event types", icon: CalendarClock },
  { href: "/meetings", label: "Meetings", icon: CalendarDays },
  { href: "/availability", label: "Availability", icon: Clock },
  { href: "/single-use-links", label: "One-time links", icon: Link2 },
  { href: "/workflows", label: "Workflows", icon: Workflow },
  { href: "/integrations", label: "Integrations", icon: Plug },
  { href: "/settings", label: "Settings", icon: Settings },
] as const;

export function HostNav() {
  const path = usePathname();
  return (
    <nav aria-label="Main">
      <ul className="flex gap-1 overflow-x-auto md:flex-col">
        {ITEMS.map(({ href, label, icon: Icon }) => {
          const active = path === href || path.startsWith(href + "/");
          return (
            <li key={href} className="shrink-0">
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex h-10 items-center gap-2 rounded-md px-3 text-sm font-semibold",
                  active ? "bg-accent-subtle text-accent" : "text-text hover:bg-surface",
                )}
              >
                <Icon aria-hidden className="size-4" />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
