"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Textarea } from "@/components/ui/field";
import { cancelMeetingAction } from "@/app/(host)/meetings/actions";

export function CancelMeeting({ id, label }: { id: string; label: string }) {
  const [reason, setReason] = useState("");
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm" variant="secondary">Cancel<span className="sr-only"> meeting with {label}</span></Button></DialogTrigger>
      <DialogContent title="Cancel this meeting?" description={`The time with ${label} opens up again.`}>
        <Field label="Reason (optional)"><Textarea value={reason} onChange={(ev) => setReason(ev.target.value)} rows={3} /></Field>
        <div className="mt-4 flex justify-end gap-2">
          <DialogClose asChild><Button variant="ghost">Keep it</Button></DialogClose>
          <Button variant="danger" loading={pending} onClick={() => start(async () => { await cancelMeetingAction(id, reason); setOpen(false); })}>Cancel meeting</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
