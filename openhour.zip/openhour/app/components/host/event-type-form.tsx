"use client";

import Link from "next/link";
import { startTransition, useActionState, useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, FieldRow, Input, Select, Textarea } from "@/components/ui/field";
import { cn } from "@/lib/cn";
import type { EventType, Schedule } from "@/lib/types";
import { LOCATION_LABELS } from "@/lib/types";
import { saveEventTypeAction, type FormState } from "@/app/(host)/event-types/actions";
import { DeleteEventType } from "./delete-event-type";

const COLOR_NAMES = ["Teal", "Blue", "Violet", "Magenta", "Rose", "Orange", "Amber", "Green"];
const swatch: Record<number, string> = {
  1: "bg-event-1", 2: "bg-event-2", 3: "bg-event-3", 4: "bg-event-4", 5: "bg-event-5", 6: "bg-event-6", 7: "bg-event-7", 8: "bg-event-8",
};
const BUFFERS = [0, 5, 10, 15, 30, 45, 60];
const NOTICE: [number, string][] = [[0, "None"], [60, "1 hour"], [120, "2 hours"], [240, "4 hours"], [480, "8 hours"], [1440, "1 day"], [2880, "2 days"], [10080, "1 week"]];
const INCREMENTS = [5, 10, 15, 20, 30, 60];

const withCurrent = (list: number[], v: number) => (list.includes(v) ? list : [...list, v].sort((a, b) => a - b));

export function EventTypeForm({ eventType, schedules, paymentsEnabled }: { eventType: EventType | null; schedules: Schedule[]; paymentsEnabled: boolean }) {
  const action = saveEventTypeAction.bind(null, eventType?.id ?? null);
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, { errors: {} });
  const v = (k: keyof EventType, fallback: string | number | null = "") => state.values?.[k as string] ?? String(eventType?.[k] ?? fallback ?? "");
  const e = state.errors;
  const [kind, setKind] = useState(v("kind", "one_on_one"));
  const [loc, setLoc] = useState(v("locationType", "google_meet"));
  const [color, setColor] = useState(Number(v("colorIndex", 1)));
  const noticeNow = Number(v("minNoticeMin", 240));
  const notice = NOTICE.some(([m]) => m === noticeNow) ? NOTICE : [...NOTICE, [noticeNow, `${noticeNow} minutes`] as [number, string]];
  const [pay, setPay] = useState(state.values ? state.values.requirePayment === "on" : Boolean(eventType?.requirePayment));
  const needsDetails = loc === "in_person" || loc === "custom" || loc === "phone_host" || loc === "phone_invitee";

  const errorKeys = Object.keys(e);
  return (
    <form
      // Not <form action>: React 19 resets the form's DOM after an action, which snaps controlled selects (kind, place) back
      // to their first option while the page still shows the state they were in, so the wrong values would be saved.
      onSubmit={(ev) => { ev.preventDefault(); const fd = new FormData(ev.currentTarget); startTransition(() => formAction(fd)); }}
      className="grid max-w-2xl gap-8"
      noValidate
    >
      {errorKeys.length > 0 && (
        <div role="alert" className="rounded-md border border-danger bg-danger-subtle p-3 text-sm text-danger">
          Some details need fixing: {errorKeys.filter((k) => k !== "_").map((k) => e[k]).join(" ")} {e._}
        </div>
      )}

      <fieldset className="grid gap-4">
        <legend className="mb-2 text-lg font-semibold">Basics</legend>
        <Field label="Name" required error={e.name}><Input name="name" defaultValue={v("name")} maxLength={120} /></Field>
        <FieldRow>
          <Field label="Link name" hint="Part of the booking link. Leave empty to build it from the name." error={e.slug}>
            <Input name="slug" defaultValue={v("slug")} placeholder="30-minute-intro" />
          </Field>
          <Field label="Duration in minutes" required error={e.durationMin}>
            <Input name="durationMin" type="number" inputMode="numeric" min={5} max={720} step={5} defaultValue={v("durationMin", 30)} />
          </Field>
        </FieldRow>
        <Field label="Description" hint="Shown above the times on the booking page."><Textarea name="description" defaultValue={v("description")} rows={3} /></Field>
        <fieldset>
          <legend className="mb-1 text-sm font-semibold">Colour</legend>
          <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Colour">
            {COLOR_NAMES.map((n, i) => (
              <label key={n} className={cn("relative grid size-10 cursor-pointer place-items-center rounded-pill border-2 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-focus-ring", color === i + 1 ? "border-text" : "border-transparent")}>
                <input type="radio" name="colorIndex" value={i + 1} checked={color === i + 1} onChange={() => setColor(i + 1)} className="sr-only" />
                <span aria-hidden className={cn("size-6 rounded-pill", swatch[i + 1])} />
                <span className="sr-only">{n}</span>
              </label>
            ))}
          </div>
          {e.colorIndex && <p role="alert" className="mt-1 text-xs font-medium text-danger">{e.colorIndex}</p>}
        </fieldset>
      </fieldset>

      <fieldset className="grid gap-4">
        <legend className="mb-2 text-lg font-semibold">Type and place</legend>
        <FieldRow>
          <Field label="Who can book a time">
            <Select name="kind" value={kind} onChange={(ev) => setKind(ev.target.value)}>
              <option value="one_on_one">One guest at a time</option>
              <option value="group">Several guests share a time</option>
            </Select>
          </Field>
          {kind === "group" && (
            <Field label="Places per time" required error={e.maxInvitees}>
              <Input name="maxInvitees" type="number" inputMode="numeric" min={2} max={500} defaultValue={v("maxInvitees", 5)} />
            </Field>
          )}
        </FieldRow>
        <FieldRow>
          <Field label="Where it happens" error={e.locationType}>
            <Select name="locationType" value={loc} onChange={(ev) => setLoc(ev.target.value)}>
              {Object.entries(LOCATION_LABELS).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
            </Select>
          </Field>
          {needsDetails && (
            <Field label={loc === "in_person" ? "Address" : loc === "custom" ? "Details" : "Phone number"} error={e.locationValue} required={loc === "in_person" || loc === "custom"}>
              <Input name="locationValue" defaultValue={v("locationValue")} />
            </Field>
          )}
        </FieldRow>
        <Field label="Hours this event uses" error={e.scheduleId}>
          <Select name="scheduleId" defaultValue={v("scheduleId", schedules.find((s) => s.isDefault)?.id ?? "")}>
            {schedules.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.timeZone})</option>)}
          </Select>
        </Field>
      </fieldset>

      <fieldset className="grid gap-4">
        <legend className="mb-2 text-lg font-semibold">Limits</legend>
        <FieldRow>
          <Field label="Gap before" error={e.bufferBeforeMin}>
            <Select name="bufferBeforeMin" defaultValue={v("bufferBeforeMin", 0)}>{withCurrent(BUFFERS, Number(v("bufferBeforeMin", 0))).map((m) => <option key={m} value={m}>{m === 0 ? "None" : `${m} minutes`}</option>)}</Select>
          </Field>
          <Field label="Gap after" error={e.bufferAfterMin}>
            <Select name="bufferAfterMin" defaultValue={v("bufferAfterMin", 0)}>{withCurrent(BUFFERS, Number(v("bufferAfterMin", 0))).map((m) => <option key={m} value={m}>{m === 0 ? "None" : `${m} minutes`}</option>)}</Select>
          </Field>
        </FieldRow>
        <FieldRow>
          <Field label="Earliest booking from now" error={e.minNoticeMin}>
            <Select name="minNoticeMin" defaultValue={String(noticeNow)}>{notice.map(([m, l]) => <option key={m} value={m}>{l}</option>)}</Select>
          </Field>
          <Field label="Bookable days ahead" hint="Empty means no limit." error={e.rollingDays}>
            <Input name="rollingDays" type="number" inputMode="numeric" min={1} max={365} defaultValue={v("rollingDays", "")} />
          </Field>
        </FieldRow>
        <Field label="Times start every" error={e.startIncrementMin}>
          <Select name="startIncrementMin" defaultValue={v("startIncrementMin", 30)}>{INCREMENTS.map((m) => <option key={m} value={m}>{m} minutes</option>)}</Select>
        </Field>
        <FieldRow>
          <Field label="Most per day" error={e.limitPerDay}><Input name="limitPerDay" type="number" inputMode="numeric" min={1} defaultValue={v("limitPerDay", "")} /></Field>
          <Field label="Most per week" error={e.limitPerWeek}><Input name="limitPerWeek" type="number" inputMode="numeric" min={1} defaultValue={v("limitPerWeek", "")} /></Field>
        </FieldRow>
        <Field label="Most per month" hint="Leave any limit empty for no cap." error={e.limitPerMonth}><Input name="limitPerMonth" type="number" inputMode="numeric" min={1} defaultValue={v("limitPerMonth", "")} /></Field>
      </fieldset>

      {(paymentsEnabled || eventType?.requirePayment) && (
        <fieldset className="grid gap-4">
          <legend className="mb-2 text-lg font-semibold">Payment</legend>
          {!paymentsEnabled && <p className="text-sm text-warning">Stripe isn't configured on this server, so guests can't book this event until it is.</p>}
          <label className="flex items-center gap-2 text-sm font-semibold">
            <input type="checkbox" name="requirePayment" className="size-4 accent-accent" checked={pay} onChange={(ev) => setPay(ev.target.checked)} /> Take payment when guests book
          </label>
          {e.requirePayment && <p role="alert" className="text-xs font-medium text-danger">{e.requirePayment}</p>}
          {pay && (
            <FieldRow>
              <Field label="Price" error={e.price}><Input name="price" inputMode="decimal" defaultValue={state.values?.price ?? (eventType?.priceCents != null ? (eventType.priceCents / 100).toFixed(2) : "")} /></Field>
              <Field label="Currency" error={e.currency}>
                <Select name="currency" defaultValue={state.values?.currency ?? eventType?.currency ?? "usd"}>{["usd", "eur", "gbp", "cad", "aud", "inr", "sgd"].map((c) => <option key={c} value={c}>{c.toUpperCase()}</option>)}</Select>
              </Field>
            </FieldRow>
          )}
          <p className="text-xs text-text-muted">Guests pay on Stripe's page. The time is held for 35 minutes while they pay. Refunds are done from your Stripe dashboard.</p>
        </fieldset>
      )}

      <fieldset className="grid gap-4">
        <legend className="mb-2 text-lg font-semibold">After booking</legend>
        <Field label="Message on the confirmation page" hint="Optional. Say what happens next."><Textarea name="confirmationMessage" defaultValue={v("confirmationMessage")} rows={3} /></Field>
      </fieldset>

      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" loading={pending}>{eventType ? "Save changes" : "Create event type"}</Button>
        <Link href="/event-types"><Button variant="ghost">Cancel</Button></Link>
        {eventType && <span className="ml-auto"><DeleteEventType id={eventType.id} name={eventType.name} /></span>}
      </div>
    </form>
  );
}
