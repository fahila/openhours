"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { deleteEventTypeAction } from "@/app/(host)/event-types/actions";

export function DeleteEventType({ id, name }: { id: string; name: string }) {
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  return (
    <Dialog onOpenChange={() => setError(null)}>
      <DialogTrigger asChild><Button variant="ghost" className="text-danger">Delete</Button></DialogTrigger>
      <DialogContent title="Delete this event type?" description={`"${name}" and its booking link stop working. This can't be undone.`}>
        {error && <p role="alert" className="mb-3 text-sm font-medium text-danger">{error}</p>}
        <div className="flex justify-end gap-2">
          <DialogClose asChild><Button variant="ghost">Keep it</Button></DialogClose>
          <Button
            variant="danger"
            loading={pending}
            onClick={() => start(async () => { const r = await deleteEventTypeAction(id); if (r?.errors._) setError(r.errors._); })}
          >
            Delete
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
