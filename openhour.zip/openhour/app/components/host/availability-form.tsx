"use client";

import { useActionState, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { TimezoneSelect } from "@/components/ui/timezone-select";
import type { DateOverride, Schedule, WeeklyRule } from "@/lib/types";
import { saveAvailabilityAction, type AvailabilityState } from "@/app/(host)/availability/actions";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const ORDER = [1, 2, 3, 4, 5, 6, 0];

const timeInput = "h-10 rounded-md border border-border-input bg-bg px-2 text-sm";

export function AvailabilityForm({ schedule }: { schedule: Schedule }) {
  const action = saveAvailabilityAction.bind(null, schedule.id);
  const [state, formAction, pending] = useActionState<AvailabilityState, FormData>(action, { errors: {} });
  const [name, setName] = useState(schedule.name);
  const [tz, setTz] = useState(schedule.timeZone);
  const [rules, setRules] = useState<WeeklyRule[]>(schedule.rules);
  const [overrides, setOverrides] = useState<DateOverride[]>(schedule.overrides);
  const [newDate, setNewDate] = useState("");
  const [newOff, setNewOff] = useState(true);
  const [newStart, setNewStart] = useState("09:00");
  const [newEnd, setNewEnd] = useState("12:00");

  const dayRules = (d: number) => rules.map((r, i) => ({ r, i })).filter(({ r }) => r.dayOfWeek === d);
  const setRule = (i: number, patch: Partial<WeeklyRule>) => setRules((rs) => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  const addRule = (d: number) => {
    const last = dayRules(d).at(-1)?.r;
    const start = last ? last.end : "09:00";
    setRules((rs) => [...rs, { dayOfWeek: d, start, end: start >= "17:00" ? "23:00" : "17:00" }]);
  };
  const sortedOverrides = [...overrides].map((o, i) => ({ o, i })).sort((a, b) => a.o.date.localeCompare(b.o.date));
  const e = state.errors;

  return (
    <form action={formAction} className="grid max-w-2xl gap-8" noValidate>
      <input type="hidden" name="payload" value={JSON.stringify({ name, timeZone: tz, rules, overrides })} />

      {Object.keys(e).length > 0 && (
        <div role="alert" className="rounded-md border border-danger bg-danger-subtle p-3 text-sm text-danger">
          {Object.values(e).join(" ")}
        </div>
      )}
      {state.saved && Object.keys(e).length === 0 && (
        <div role="status" className="rounded-md border border-success bg-success-subtle p-3 text-sm text-success">Saved. New bookings follow these hours.</div>
      )}

      <section className="grid gap-4 sm:grid-cols-2">
        <Field label="Name"><Input value={name} onChange={(ev) => setName(ev.target.value)} /></Field>
        <div className="flex flex-col gap-1">
          <label htmlFor="tz" className="text-sm font-semibold">Time zone</label>
          <TimezoneSelect id="tz" value={tz} onChange={setTz} />
        </div>
      </section>

      <section aria-labelledby="weekly">
        <h2 id="weekly" className="mb-1 text-lg">Weekly hours</h2>
        <p className="mb-4 text-sm text-text-muted">Times are in {tz.replaceAll("_", " ")}. A day with no ranges is unavailable.</p>
        <ul className="divide-y divide-border rounded-lg border border-border">
          {ORDER.map((d) => {
            const list = dayRules(d);
            return (
              <li key={d} className="grid gap-2 p-3 sm:grid-cols-[120px_1fr] sm:items-start">
                <span className="pt-2 text-sm font-semibold">{DAYS[d]}</span>
                <div className="grid gap-2">
                  {list.length === 0 && <p className="pt-2 text-sm text-text-muted">Unavailable</p>}
                  {list.map(({ r, i }, n) => (
                    <div key={i} className="flex flex-wrap items-center gap-2">
                      <input type="time" aria-label={`${DAYS[d]} range ${n + 1} start`} className={timeInput} value={r.start} onChange={(ev) => setRule(i, { start: ev.target.value })} />
                      <span aria-hidden>to</span>
                      <input type="time" aria-label={`${DAYS[d]} range ${n + 1} end`} className={timeInput} value={r.end} onChange={(ev) => setRule(i, { end: ev.target.value })} />
                      <Button variant="ghost" size="sm" aria-label={`Remove ${DAYS[d]} range ${n + 1}`} onClick={() => setRules((rs) => rs.filter((_, j) => j !== i))}>
                        <Trash2 aria-hidden className="size-4" />
                      </Button>
                    </div>
                  ))}
                  <div><Button variant="ghost" size="sm" onClick={() => addRule(d)}><Plus aria-hidden className="size-4" /> Add hours<span className="sr-only"> on {DAYS[d]}</span></Button></div>
                </div>
              </li>
            );
          })}
        </ul>
      </section>

      <section aria-labelledby="overrides">
        <h2 id="overrides" className="mb-1 text-lg">Changes for specific dates</h2>
        <p className="mb-4 text-sm text-text-muted">Take a day off, or set different hours for one date.</p>
        {sortedOverrides.length === 0 ? (
          <p className="mb-4 rounded-md border border-dashed border-border-input bg-surface p-4 text-sm text-text-muted">No date changes. Add one below.</p>
        ) : (
          <ul className="mb-4 divide-y divide-border rounded-lg border border-border">
            {sortedOverrides.map(({ o, i }) => (
              <li key={i} className="flex items-center justify-between gap-2 p-3 text-sm">
                <span><strong>{new Intl.DateTimeFormat("en", { dateStyle: "full", timeZone: "UTC" }).format(new Date(o.date + "T00:00:00Z"))}</strong>{" "}
                  {o.start ? `${o.start} to ${o.end}` : "Unavailable all day"}</span>
                <Button variant="ghost" size="sm" aria-label={`Remove change for ${o.date}`} onClick={() => setOverrides((os) => os.filter((_, j) => j !== i))}><Trash2 aria-hidden className="size-4" /></Button>
              </li>
            ))}
          </ul>
        )}
        <div className="grid gap-3 rounded-lg border border-border bg-surface p-3 sm:grid-cols-[auto_auto_1fr] sm:items-end">
          <Field label="Date"><Input type="date" value={newDate} onChange={(ev) => setNewDate(ev.target.value)} /></Field>
          <label className="flex h-10 items-center gap-2 text-sm"><input type="checkbox" className="size-4 accent-accent" checked={newOff} onChange={(ev) => setNewOff(ev.target.checked)} /> Unavailable all day</label>
          <div className="flex flex-wrap items-end gap-2">
            {!newOff && (
              <>
                <input type="time" aria-label="Override start" className={timeInput} value={newStart} onChange={(ev) => setNewStart(ev.target.value)} />
                <span aria-hidden className="pb-2">to</span>
                <input type="time" aria-label="Override end" className={timeInput} value={newEnd} onChange={(ev) => setNewEnd(ev.target.value)} />
              </>
            )}
            <Button
              variant="secondary"
              disabled={!newDate}
              onClick={() => { setOverrides((os) => [...os, { date: newDate, start: newOff ? null : newStart, end: newOff ? null : newEnd }]); setNewDate(""); }}
            >
              Add change
            </Button>
          </div>
        </div>
      </section>

      <div><Button type="submit" loading={pending}>Save hours</Button></div>
    </form>
  );
}
