"use client";

import { useEffect, useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { adoptTimeZoneAction } from "@/app/(host)/timezone-actions";

const KEY = "tz-prompt-dismissed";

/** Shown when the browser's zone differs from the account's, which is always true on a brand new account (UTC). */
export function TimezonePrompt({ accountZone }: { accountZone: string }) {
  const [browserZone, setBrowserZone] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const z = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (z && z !== accountZone && localStorage.getItem(KEY) !== z) setBrowserZone(z);
      else setBrowserZone(null);
    } catch { /* storage blocked: no prompt */ }
  }, [accountZone]);

  if (!browserZone) return null;
  const label = (z: string) => z.replaceAll("_", " ");
  return (
    <div role="region" aria-label="Time zone" className="mb-6 rounded-md border border-border bg-accent-subtle p-3 text-sm">
      <p>
        Your account is set to <strong>{label(accountZone)}</strong> but this browser is in <strong>{label(browserZone)}</strong>. Your working hours are read in the account's zone.
      </p>
      {error && <p role="alert" className="mt-1 font-medium text-danger">{error}</p>}
      <div className="mt-2 flex flex-wrap gap-2">
        <Button size="sm" loading={pending} onClick={() => start(async () => { const r = await adoptTimeZoneAction(browserZone); if (r.error) setError(r.error); else setBrowserZone(null); })}>
          Use {label(browserZone)}
        </Button>
        <Button size="sm" variant="ghost" onClick={() => { try { localStorage.setItem(KEY, browserZone); } catch { /* ignore */ } setBrowserZone(null); }}>Keep {label(accountZone)}</Button>
      </div>
    </div>
  );
}
