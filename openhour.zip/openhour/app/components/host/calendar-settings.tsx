"use client";

import { useState, useTransition } from "react";
import { RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import type { ConnectionView } from "@/lib/calendar/connections";
import { disconnectAction, refreshCalendarsAction, setCalendarFlagsAction } from "@/app/(host)/integrations/actions";

export function CalendarConnection({ conn }: { conn: ConnectionView }) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  return (
    <section aria-label={`Google account ${conn.email}`} className="rounded-lg border border-border bg-bg p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="break-all text-lg">{conn.email}</h3>
          <p className="text-sm text-text-muted">Google Calendar</p>
        </div>
        <div className="flex items-center gap-2">
          {conn.status === "active" ? <Badge tone="success">Connected</Badge> : <Badge tone="danger">Needs reconnecting</Badge>}
          <Button size="sm" variant="ghost" loading={pending} onClick={() => start(async () => { const r = await refreshCalendarsAction(conn.id); setError(r.error ?? null); })}>
            <RefreshCw aria-hidden className="size-4" /> Refresh list
          </Button>
        </div>
      </div>

      {conn.status !== "active" && (
        <p role="alert" className="mt-3 rounded-md border border-danger bg-danger-subtle p-3 text-sm text-danger">
          Google stopped letting us see this account. Until you reconnect it, guests can't book times that depend on it.{" "}
          <a className="font-semibold underline" href="/api/calendars/connect/google">Reconnect</a>
        </p>
      )}
      {error && <p role="alert" className="mt-3 text-sm font-medium text-danger">{error}</p>}

      <table className="mt-4 w-full text-left text-sm">
        <caption className="sr-only">Calendars in {conn.email}</caption>
        <thead>
          <tr className="border-b border-border text-text-muted">
            <th scope="col" className="py-2 pr-2 font-medium">Calendar</th>
            <th scope="col" className="px-2 py-2 font-medium">Block busy times</th>
            <th scope="col" className="px-2 py-2 font-medium">Add new bookings</th>
          </tr>
        </thead>
        <tbody>
          {conn.calendars.map((c) => (
            <tr key={c.id} className="border-b border-border last:border-0">
              <th scope="row" className="break-words py-2 pr-2 font-medium">{c.name}</th>
              <td className="px-2 py-2">
                <input type="checkbox" className="size-4 accent-accent" aria-label={`Block busy times from ${c.name}`} checked={c.checkConflicts} disabled={pending}
                  onChange={(e) => start(() => setCalendarFlagsAction(c.id, { checkConflicts: e.target.checked }))} />
              </td>
              <td className="px-2 py-2">
                <input type="radio" name="target" className="size-4 accent-accent" aria-label={`Add new bookings to ${c.name}`} checked={c.isBookingTarget} disabled={pending}
                  onChange={() => start(() => setCalendarFlagsAction(c.id, { isBookingTarget: true }))} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-4">
        <Dialog>
          <DialogTrigger asChild><Button size="sm" variant="ghost" className="text-danger">Disconnect</Button></DialogTrigger>
          <DialogContent title="Disconnect this account?" description="We stop reading its busy times and stop adding bookings to it. Meetings already on it stay there.">
            <div className="flex justify-end gap-2">
              <DialogClose asChild><Button variant="ghost">Keep it</Button></DialogClose>
              <DialogClose asChild><Button variant="danger" onClick={() => start(() => disconnectAction(conn.id))}>Disconnect</Button></DialogClose>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
