"use client";

import { startTransition, useActionState, useState } from "react";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { TimezoneSelect } from "@/components/ui/timezone-select";
import type { User } from "@/lib/types";
import { deleteAccountAction, saveProfileAction, signOutAction, signOutEverywhereAction, type SettingsState } from "@/app/(host)/settings/actions";

export function ProfileForm({ user }: { user: User }) {
  const [state, action, pending] = useActionState<SettingsState, FormData>(saveProfileAction, { errors: {} });
  const [tz, setTz] = useState(user.timeZone);
  const e = state.errors;
  return (
    <form onSubmit={(ev) => { ev.preventDefault(); const fd = new FormData(ev.currentTarget); startTransition(() => action(fd)); }} className="grid max-w-xl gap-4" noValidate>
      {state.saved && <p role="status" className="rounded-md border border-success bg-success-subtle p-3 text-sm text-success">Saved.</p>}
      <Field label="Name" required error={e.name}><Input name="name" defaultValue={user.name} maxLength={120} /></Field>
      <Field label="Link name" hint="Your booking page is /your-link-name." error={e.slug}><Input name="slug" defaultValue={user.slug} /></Field>
      <div className="flex flex-col gap-1">
        <label htmlFor="tz" className="text-sm font-semibold">Time zone</label>
        <TimezoneSelect id="tz" value={tz} onChange={setTz} />
        <input type="hidden" name="timeZone" value={tz} />
        {e.timeZone && <p role="alert" className="text-xs font-medium text-danger">{e.timeZone}</p>}
      </div>
      <Field label="Welcome message" hint="Shown at the top of your booking page." error={e.welcomeMessage}><Textarea name="welcomeMessage" defaultValue={user.welcomeMessage ?? ""} rows={3} maxLength={500} /></Field>
      <div><Button type="submit" loading={pending}>Save profile</Button></div>
    </form>
  );
}

export function SessionControls() {
  return (
    <div className="flex flex-wrap gap-3">
      <form action={signOutAction}><Button type="submit" variant="secondary">Sign out</Button></form>
      <form action={signOutEverywhereAction}><Button type="submit" variant="secondary">Sign out on every device</Button></form>
    </div>
  );
}

export function DeleteAccountForm({ email }: { email: string }) {
  const [state, action, pending] = useActionState<SettingsState, FormData>(deleteAccountAction, { errors: {} });
  return (
    <form onSubmit={(ev) => { ev.preventDefault(); const fd = new FormData(ev.currentTarget); startTransition(() => action(fd)); }} className="grid max-w-xl gap-3" noValidate>
      <p className="text-sm text-text-muted">This deletes your profile, event types, availability, meetings, calendar connections and every guest's details. It can't be undone.</p>
      <Field label={`Type ${email} to confirm`} error={state.errors.confirm}><Input name="confirm" autoComplete="off" /></Field>
      <div><Button type="submit" variant="danger" loading={pending}>Delete my account</Button></div>
    </form>
  );
}
