import type { ReactNode } from "react";
import { Clock, MapPin } from "lucide-react";
import { Badge } from "./badge";
import { cn } from "@/lib/cn";

interface EventTypeCardProps {
  name: string;
  durationMin: number;
  location: string;
  /** index 1..8 into the event-N colour tokens */
  colorIndex: number;
  kind: "one_on_one" | "group";
  active: boolean;
  actions?: ReactNode;
  /** heading level for the name; pick the one that follows the page's outline */
  headingLevel?: 2 | 3;
}

const dot: Record<number, string> = {
  1: "bg-event-1", 2: "bg-event-2", 3: "bg-event-3", 4: "bg-event-4",
  5: "bg-event-5", 6: "bg-event-6", 7: "bg-event-7", 8: "bg-event-8",
};
const bar: Record<number, string> = {
  1: "border-t-event-1", 2: "border-t-event-2", 3: "border-t-event-3", 4: "border-t-event-4",
  5: "border-t-event-5", 6: "border-t-event-6", 7: "border-t-event-7", 8: "border-t-event-8",
};

export function EventTypeCard({ name, durationMin, location, colorIndex, kind, active, actions, headingLevel = 3 }: EventTypeCardProps) {
  const Heading = `h${headingLevel}` as const;
  return (
    <article className={cn("rounded-lg border border-border border-t-4 bg-bg p-4 shadow-card", bar[colorIndex])}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <Heading className="flex items-start gap-2 text-lg">
            <span aria-hidden className={cn("mt-2 size-3 shrink-0 rounded-pill", dot[colorIndex])} />
            <span className="min-w-0 break-words">{name}</span>
          </Heading>
          <p className="mt-1 flex items-center gap-1 text-sm text-text-muted">
            <Clock aria-hidden className="size-4" /> {durationMin} min
            <span aria-hidden>·</span>
            {kind === "group" ? "Group" : "One-on-one"}
          </p>
          <p className="mt-1 flex items-center gap-1 text-sm text-text-muted">
            <MapPin aria-hidden className="size-4" /> {location}
          </p>
        </div>
        <span className="shrink-0"><Badge tone={active ? "success" : "neutral"}>{active ? "Active" : "Off"}</Badge></span>
      </div>
      {actions ? <div className="mt-4 flex items-center gap-2">{actions}</div> : null}
    </article>
  );
}
