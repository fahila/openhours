"use client";

import { useMemo } from "react";
import { Select } from "./field";

/** Native select: searchable by typing on every platform, free screen reader support. */
export function TimezoneSelect({ value, onChange, id }: { value: string; onChange: (tz: string) => void; id?: string }) {
  const zones = useMemo(() => {
    const all = (Intl as unknown as { supportedValuesOf?: (k: string) => string[] }).supportedValuesOf?.("timeZone") ?? [];
    return all.includes(value) ? all : [value, ...all];
  }, [value]);
  return (
    <Select id={id} value={value} onChange={(e) => onChange(e.target.value)} aria-label="Time zone">
      {zones.map((z) => (
        <option key={z} value={z}>{z.replaceAll("_", " ")}</option>
      ))}
    </Select>
  );
}
