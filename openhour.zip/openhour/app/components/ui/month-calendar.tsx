"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/cn";

/** Dates are plain "YYYY-MM-DD" strings in the viewer's chosen zone. No Date math on instants here. */
type Ymd = string;

const pad = (n: number) => String(n).padStart(2, "0");
const ymd = (y: number, m: number, d: number): Ymd => `${y}-${pad(m + 1)}-${pad(d)}`;
const parse = (s: Ymd) => ({ y: +s.slice(0, 4), m: +s.slice(5, 7) - 1, d: +s.slice(8, 10) });
const addDays = (s: Ymd, n: number): Ymd => {
  const { y, m, d } = parse(s);
  const dt = new Date(Date.UTC(y, m, d + n));
  return ymd(dt.getUTCFullYear(), dt.getUTCMonth(), dt.getUTCDate());
};

interface Props {
  /** first month shown, "YYYY-MM-DD" (day ignored) */
  month: Ymd;
  today: Ymd;
  selected: Ymd | null;
  /** days that have at least one open slot */
  available: ReadonlySet<Ymd>;
  loading?: boolean;
  onSelect: (day: Ymd) => void;
  onMonthChange: (month: Ymd) => void;
  weekStartsOn?: 0 | 1;
}

export function MonthCalendar({ month, today, selected, available, loading, onSelect, onMonthChange, weekStartsOn = 0 }: Props) {
  const { y, m } = parse(month);
  const [focus, setFocus] = useState<Ymd>(selected ?? today);
  const grid = useRef<HTMLDivElement>(null);
  const moved = useRef(false);

  const label = new Intl.DateTimeFormat("en", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(y, m, 1)));
  const dayNames = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => {
        const dt = new Date(Date.UTC(2024, 0, 7 + ((i + weekStartsOn) % 7))); // 2024-01-07 is a Sunday
        return {
          short: new Intl.DateTimeFormat("en", { weekday: "short", timeZone: "UTC" }).format(dt),
          long: new Intl.DateTimeFormat("en", { weekday: "long", timeZone: "UTC" }).format(dt),
        };
      }),
    [weekStartsOn],
  );

  const firstDow = (new Date(Date.UTC(y, m, 1)).getUTCDay() - weekStartsOn + 7) % 7;
  const daysInMonth = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const cells: (Ymd | null)[] = [
    ...Array.from({ length: firstDow }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => ymd(y, m, i + 1)),
  ];
  while (cells.length % 7) cells.push(null);
  const weeks = Array.from({ length: cells.length / 7 }, (_, i) => cells.slice(i * 7, i * 7 + 7));

  const inView = (d: Ymd) => d.startsWith(`${y}-${pad(m + 1)}`);
  const rovingTarget = inView(focus) ? focus : ymd(y, m, 1);

  useEffect(() => {
    if (moved.current) grid.current?.querySelector<HTMLButtonElement>(`[data-day="${focus}"]`)?.focus();
  }, [focus, month]);

  const monthStart = (n: number): Ymd => {
    const dt = new Date(Date.UTC(y, m + n, 1));
    return ymd(dt.getUTCFullYear(), dt.getUTCMonth(), 1);
  };
  const shiftMonth = (n: number) => onMonthChange(monthStart(n));

  const onKey = (e: React.KeyboardEvent) => {
    const step: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
    let next: Ymd | null = null;
    if (e.key in step) next = addDays(rovingTarget, step[e.key]);
    else if (e.key === "Home") next = addDays(rovingTarget, -((parse(rovingTarget).d - 1 + firstDow) % 7));
    else if (e.key === "PageDown") { e.preventDefault(); shiftMonth(1); setFocus(monthStart(1)); moved.current = true; return; }
    else if (e.key === "PageUp") { e.preventDefault(); shiftMonth(-1); setFocus(monthStart(-1)); moved.current = true; return; }
    if (!next) return;
    e.preventDefault();
    moved.current = true;
    setFocus(next);
    if (!inView(next)) onMonthChange(ymd(parse(next).y, parse(next).m, 1));
  };

  return (
    <div className="w-full max-w-sm" aria-busy={loading || undefined}>
      <div className="mb-2 flex items-center justify-between">
        <h2 id="cal-label" className="text-lg" aria-live="polite">{label}</h2>
        <div className="flex gap-1">
          <button type="button" aria-label="Previous month" onClick={() => shiftMonth(-1)} className="grid size-10 place-items-center rounded-md text-text hover:bg-surface">
            <ChevronLeft aria-hidden className="size-5" />
          </button>
          <button type="button" aria-label="Next month" onClick={() => shiftMonth(1)} className="grid size-10 place-items-center rounded-md text-text hover:bg-surface">
            <ChevronRight aria-hidden className="size-5" />
          </button>
        </div>
      </div>
      <div ref={grid} role="grid" aria-labelledby="cal-label" onKeyDown={onKey}>
        <div role="row" className="grid grid-cols-7">
          {dayNames.map((n) => (
            <div key={n.long} role="columnheader" aria-label={n.long} className="py-1 text-center text-xs font-medium text-text-muted">
              {n.short}
            </div>
          ))}
        </div>
        {weeks.map((week, wi) => (
          <div key={wi} role="row" className="grid grid-cols-7">
            {week.map((day, di) => {
              if (!day) return <div key={di} role="gridcell" />;
              const isAvail = available.has(day);
              const isSel = day === selected;
              const isToday = day === today;
              const full = new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric", timeZone: "UTC" }).format(
                new Date(Date.UTC(parse(day).y, parse(day).m, parse(day).d)),
              );
              return (
                <div key={day} role="gridcell" aria-selected={isSel} className="grid place-items-center p-0.5">
                  <button
                    type="button"
                    data-day={day}
                    tabIndex={day === rovingTarget ? 0 : -1}
                    aria-disabled={!isAvail}
                    aria-label={`${full}${isAvail ? "" : ", no times available"}${isToday ? ", today" : ""}`}
                    aria-pressed={isSel}
                    onClick={() => { setFocus(day); if (isAvail) onSelect(day); }}
                    className={cn(
                      "size-10 rounded-pill text-sm transition-colors duration-[120ms]",
                      isSel && "bg-accent font-semibold text-on-accent",
                      !isSel && isAvail && "bg-accent-subtle font-semibold text-accent hover:bg-accent hover:text-on-accent",
                      !isAvail && "cursor-not-allowed text-text-muted",
                      isToday && !isSel && "ring-1 ring-inset ring-border-input",
                    )}
                  >
                    {parse(day).d}
                  </button>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
