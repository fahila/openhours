import type { ReactNode } from "react";

/** `level` is the heading level of the title: 2 under a page title, 3 under a section heading. */
export function EmptyState({ title, body, action, level = 2 }: { title: string; body: string; action?: ReactNode; level?: 2 | 3 }) {
  const Heading = `h${level}` as const;
  return (
    <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed border-border-input bg-surface px-6 py-12 text-center">
      <Heading className="text-lg">{title}</Heading>
      <p className="max-w-sm text-sm text-text-muted">{body}</p>
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}
