"use client";

import * as RadixDialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import type { ReactNode } from "react";

export const Dialog = RadixDialog.Root;
export const DialogTrigger = RadixDialog.Trigger;
export const DialogClose = RadixDialog.Close;

interface DialogContentProps {
  title: string;
  description?: string;
  children: ReactNode;
}

/** Radix handles focus trap, Escape, scroll lock and returns focus to the trigger. */
export function DialogContent({ title, description, children }: DialogContentProps) {
  return (
    <RadixDialog.Portal>
      <RadixDialog.Overlay className="fixed inset-0 bg-text/40" />
      <RadixDialog.Content
        className="fixed left-1/2 top-1/2 w-[calc(100%-32px)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-lg bg-bg p-6 shadow-pop"
        {...(description ? {} : { "aria-describedby": undefined })}
      >
        <RadixDialog.Title className="text-lg">{title}</RadixDialog.Title>
        {description ? (
          <RadixDialog.Description className="mt-1 text-sm text-text-muted">{description}</RadixDialog.Description>
        ) : null}
        <div className="mt-4">{children}</div>
        <RadixDialog.Close
          aria-label="Close"
          className="absolute right-3 top-3 grid size-8 place-items-center rounded-md text-text-muted hover:bg-surface"
        >
          <X aria-hidden className="size-4" />
        </RadixDialog.Close>
      </RadixDialog.Content>
    </RadixDialog.Portal>
  );
}
