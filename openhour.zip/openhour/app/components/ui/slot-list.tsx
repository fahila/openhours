"use client";

import { cn } from "@/lib/cn";

export interface Slot {
  /** UTC instant, ISO 8601 */
  start: string;
  taken?: boolean;
}

interface Props {
  slots: Slot[];
  timeZone: string;
  hour12: boolean;
  selected: string | null;
  onSelect: (startIso: string) => void;
}

export function SlotList({ slots, timeZone, hour12, selected, onSelect }: Props) {
  const fmt = new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12, timeZone });
  // On the day clocks go back, one wall-clock time happens twice. Only those get a zone name (1:30 AM EDT / 1:30 AM EST).
  const withZone = new Intl.DateTimeFormat("en", { hour: "numeric", minute: "2-digit", hour12, timeZone, timeZoneName: "short" });
  const plain = slots.map((s) => fmt.format(new Date(s.start)));
  const repeated = new Set(plain.filter((l, i) => plain.indexOf(l) !== i));
  return (
    <ul className="flex max-h-96 flex-col gap-2 overflow-y-auto pr-1" aria-label="Available times">
      {slots.map((s, i) => {
        const isSel = s.start === selected;
        const text = repeated.has(plain[i]) ? withZone.format(new Date(s.start)) : plain[i];
        return (
          <li key={s.start}>
            <button
              type="button"
              disabled={s.taken}
              aria-pressed={isSel}
              onClick={() => onSelect(s.start)}
              className={cn(
                "h-12 w-full rounded-md border px-3 text-sm font-semibold transition-colors duration-[120ms]",
                isSel
                  ? "border-accent bg-accent text-on-accent"
                  : "border-accent bg-bg text-accent hover:bg-accent-subtle",
                s.taken && "cursor-not-allowed border-border bg-surface font-normal text-text-muted line-through hover:bg-surface",
              )}
            >
              {text}
              {s.taken ? <span className="sr-only"> (no longer available)</span> : null}
            </button>
          </li>
        );
      })}
    </ul>
  );
}
