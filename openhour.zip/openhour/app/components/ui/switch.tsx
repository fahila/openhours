"use client";

import * as RadixSwitch from "@radix-ui/react-switch";
import { cn } from "@/lib/cn";

interface SwitchProps extends RadixSwitch.SwitchProps {
  label: string;
}

export function Switch({ label, className, ...rest }: SwitchProps) {
  return (
    <RadixSwitch.Root
      aria-label={label}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-pill border border-border-input bg-bg transition-colors duration-[120ms]",
        "data-[state=checked]:border-accent data-[state=checked]:bg-accent",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...rest}
    >
      <RadixSwitch.Thumb
        className={cn(
          "block size-4 translate-x-1 rounded-pill bg-border-input transition-transform duration-[120ms]",
          "data-[state=checked]:translate-x-6 data-[state=checked]:bg-on-accent",
        )}
      />
    </RadixSwitch.Root>
  );
}
