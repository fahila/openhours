"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Clock, Globe, MapPin, Users, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, FieldRow, Input, Textarea } from "@/components/ui/field";
import { MonthCalendar } from "@/components/ui/month-calendar";
import { SlotList } from "@/components/ui/slot-list";
import { TimezoneSelect } from "@/components/ui/timezone-select";
import { cn } from "@/lib/cn";

interface ApiSlot { start: string; remaining: number }

export interface BookingFlowProps {
  host: { name: string; slug: string; timeZone: string };
  event: { slug: string; name: string; durationMin: number; locationLabel: string; description: string | null; kind: "one_on_one" | "group"; colorIndex: number; priceLabel: string | null };
  /** server clock, used for the first render so server and client agree */
  nowIso: string;
  mode: { type: "book" } | { type: "reschedule"; token: string; guestName: string; currentStart: string };
  /** a one-off message shown above the times, e.g. after backing out of payment */
  notice?: string | null;
}

const pad = (n: number) => String(n).padStart(2, "0");
const dayIn = (iso: string, tz: string) => new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(iso));
const monthStartOf = (ymd: string) => ymd.slice(0, 8) + "01";
const addMonths = (ymd: string, n: number) => {
  const dt = new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(5, 7) - 1 + n, 1));
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-01`;
};
const addDays = (ymd: string, n: number) => {
  const dt = new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(5, 7) - 1, +ymd.slice(8, 10) + n));
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
};
const lastOfMonth = (ymd: string) => addDays(addMonths(ymd, 1), -1);

const dot: Record<number, string> = { 1: "bg-event-1", 2: "bg-event-2", 3: "bg-event-3", 4: "bg-event-4", 5: "bg-event-5", 6: "bg-event-6", 7: "bg-event-7", 8: "bg-event-8" };

export function BookingFlow({ host, event, nowIso, mode, notice: initialNotice = null }: BookingFlowProps) {
  const router = useRouter();
  const reschedule = mode.type === "reschedule";
  const [tz, setTz] = useState(host.timeZone);
  const [mounted, setMounted] = useState(false);
  const [h12, setH12] = useState(true);
  const [month, setMonth] = useState(() => monthStartOf(dayIn(nowIso, host.timeZone)));
  const [day, setDay] = useState<string | null>(null);
  const [slots, setSlots] = useState<ApiSlot[] | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [picked, setPicked] = useState<string | null>(null);
  const [stage, setStage] = useState<"pick" | "details">("pick");
  const [notice, setNotice] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [reload, setReload] = useState(0);
  const advanced = useRef(0);
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
    try {
      const z = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (z) setTz(z);
    } catch { /* keep the host zone */ }
    try { setH12(new Intl.DateTimeFormat(undefined, { hour: "numeric" }).resolvedOptions().hour12 ?? true); } catch { /* keep 12h */ }
  }, []);

  const today = useMemo(() => dayIn(mounted ? new Date().toISOString() : nowIso, tz), [mounted, nowIso, tz]);

  // Slots for the visible month. Host dates are fetched with one day of slack either side because the
  // guest's calendar day and the host's calendar day can differ.
  useEffect(() => {
    const ctl = new AbortController();
    setSlots(null);
    setLoadError(false);
    const from = addDays(month, -1);
    const to = addDays(lastOfMonth(month), 1);
    const qs = new URLSearchParams({ from, to });
    if (mode.type === "reschedule") qs.set("reschedule", mode.token);
    fetch(`/api/public/${host.slug}/${event.slug}/slots?${qs}`, { signal: ctl.signal })
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.json() as Promise<{ slots: ApiSlot[] }>; })
      .then((j) => setSlots(j.slots))
      .catch((e) => { if (e.name !== "AbortError") setLoadError(true); });
    return () => ctl.abort();
  }, [month, host.slug, event.slug, mode, reload]);

  const byDay = useMemo(() => {
    const map = new Map<string, ApiSlot[]>();
    for (const s of slots ?? []) {
      const d = dayIn(s.start, tz);
      if (!d.startsWith(month.slice(0, 7))) continue;
      map.set(d, [...(map.get(d) ?? []), s]);
    }
    return map;
  }, [slots, tz, month]);
  const available = useMemo(() => new Set(byDay.keys()), [byDay]);

  // First visit: if this month is empty, look ahead a few months so the guest lands on real times.
  useEffect(() => {
    if (slots && available.size === 0 && advanced.current < 3) {
      advanced.current += 1;
      setMonth((m) => addMonths(m, 1));
    } else if (slots && available.size > 0) advanced.current = 3;
  }, [slots, available]);

  // Drop the selected day only once times have loaded and it truly has none. While a reload is under way `available`
  // is briefly empty, which used to clear the guest's choice right after a "just taken" message.
  useEffect(() => {
    if (slots && day && !available.has(day)) setDay(null);
  }, [slots, available, day]);

  const daySlots = day ? byDay.get(day) ?? [] : [];
  const loading = slots === null && !loadError;
  const pickedSlot = picked ? slots?.find((s) => s.start === picked) : null;

  const goDetails = useCallback((iso: string) => {
    setPicked(iso);
    setNotice(null);
    setFieldErrors({});
    setStage("details");
  }, []);

  useEffect(() => { if (stage === "details") nameRef.current?.focus(); }, [stage]);

  // onSubmit, not <form action>: React 19 resets uncontrolled fields after an action, which would wipe what
  // the guest typed whenever a booking fails.
  async function submit(ev: React.FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    if (!picked) return;
    const fd = new FormData(ev.currentTarget);
    setSubmitting(true);
    setNotice(null);
    setFieldErrors({});
    try {
      const url = mode.type === "reschedule" ? `/m/${mode.token}/reschedule` : `/api/public/${host.slug}/${event.slug}/book`;
      const body = mode.type === "reschedule"
        ? { startAt: picked }
        : { startAt: picked, name: fd.get("name"), email: fd.get("email"), timeZone: tz, answers: fd.get("notes") ? { notes: fd.get("notes") } : {} };
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const json = await res.json().catch(() => ({}));
      if (res.status === 201 && json.checkoutUrl) {
        window.location.assign(json.checkoutUrl); // Stripe hosts the payment page
        return;
      }
      if (res.status === 201 || (res.ok && json.manageToken)) {
        router.push(`/booked/${json.manageToken}`);
        return;
      }
      if (res.status === 409) {
        setNotice("That time was just taken. Please pick another.");
        setPicked(null);
        setStage("pick");
        setReload((n) => n + 1);
      } else if (res.status === 422) {
        const errs = (json.errors ?? {}) as Record<string, string>;
        setFieldErrors(errs);
        if (errs._) setNotice(errs._);
      } else if (res.status === 503) {
        setNotice(json.message ?? "We couldn't check the host's calendar just now. Please try again in a moment.");
      } else if (res.status === 429) {
        setNotice(json.message ?? "Too many attempts. Wait a minute and try again.");
      } else {
        // e.g. 502 when payment could not be started: the server's message says what happened and that nothing was charged
        setNotice(json.message ?? "Something went wrong on our side. Please try again.");
      }
    } catch {
      setNotice("We couldn't reach the server. Check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  const fullDay = day ? new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric", timeZone: "UTC" }).format(new Date(day + "T00:00:00Z")) : null;
  const pickedLabel = picked
    ? new Intl.DateTimeFormat("en", { weekday: "long", month: "long", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: h12, timeZone: tz }).format(new Date(picked))
    : "";

  return (
    <div className="mx-auto w-full max-w-[880px] rounded-lg border border-border bg-bg shadow-card md:grid md:grid-cols-[260px_1fr]">
      <aside className="border-b border-border p-6 md:border-b-0 md:border-r">
        <p className="text-sm text-text-muted">{host.name}</p>
        <h1 className="mt-1 flex items-start gap-2 text-lg">
          <span aria-hidden className={cn("mt-2 size-3 shrink-0 rounded-pill", dot[event.colorIndex])} />
          <span className="min-w-0 break-words">{event.name}</span>
        </h1>
        <ul className="mt-4 grid gap-2 text-sm text-text-muted">
          <li className="flex items-center gap-2"><Clock aria-hidden className="size-4 shrink-0" /> {event.durationMin} min</li>
          <li className="flex items-start gap-2"><MapPin aria-hidden className="mt-0.5 size-4 shrink-0" /> <span className="break-words">{event.locationLabel}</span></li>
          {event.priceLabel && <li className="flex items-center gap-2 font-semibold text-text"><Wallet aria-hidden className="size-4 shrink-0 text-text-muted" /> {event.priceLabel}</li>}
          {event.kind === "group" && <li className="flex items-center gap-2"><Users aria-hidden className="size-4 shrink-0" /> Shared with other guests</li>}
          {stage === "details" && picked && <li className="flex items-start gap-2 font-semibold text-text"><Globe aria-hidden className="mt-0.5 size-4 shrink-0" /> {pickedLabel}</li>}
        </ul>
        {event.description && <p className="mt-4 whitespace-pre-line break-words text-sm text-text-muted">{event.description}</p>}
        {mode.type === "reschedule" && (
          <p className="mt-4 rounded-md bg-accent-subtle p-3 text-sm text-accent">
            Moving the meeting for {mode.guestName}. Pick a new time below.
          </p>
        )}
      </aside>

      <section className="p-6" aria-live="polite">
        {initialNotice && !notice && <p role="status" className="mb-4 rounded-md border border-border bg-accent-subtle p-3 text-sm text-text">{initialNotice}</p>}
        {notice && <p role="alert" className="mb-4 rounded-md border border-danger bg-danger-subtle p-3 text-sm font-medium text-danger">{notice}</p>}

        {stage === "pick" ? (
          <div className="grid gap-6 lg:grid-cols-[auto_200px]">
            <div>
              <h2 className="sr-only">Pick a day</h2>
              {loadError ? (
                <div className="max-w-sm rounded-md border border-border bg-surface p-4 text-sm">
                  <p className="font-semibold">We couldn't load the times.</p>
                  <p className="mt-1 text-text-muted">Check your connection and try again.</p>
                  <Button className="mt-3" size="sm" onClick={() => setReload((n) => n + 1)}>Try again</Button>
                </div>
              ) : loading ? (
                <div aria-busy="true" className="w-full max-w-sm">
                  <p className="sr-only">Loading times</p>
                  <div className="mb-3 h-7 w-40 animate-pulse rounded-md bg-surface" />
                  <div className="grid grid-cols-7 gap-1">{Array.from({ length: 35 }).map((_, i) => <div key={i} className="size-10 animate-pulse rounded-pill bg-surface" />)}</div>
                </div>
              ) : (
                <MonthCalendar
                  month={month}
                  today={today}
                  selected={day}
                  available={available}
                  onSelect={setDay}
                  onMonthChange={(m) => { advanced.current = 3; setMonth(m); }}
                />
              )}
              {!loading && !loadError && available.size === 0 && (
                <p className="mt-3 max-w-sm text-sm text-text-muted">No times this month. Try the next month.</p>
              )}
              <div className="mt-6 flex max-w-sm flex-col gap-2">
                <label htmlFor="guest-tz" className="text-sm font-semibold">Your time zone</label>
                <TimezoneSelect id="guest-tz" value={tz} onChange={setTz} />
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" className="size-4 accent-accent" checked={!h12} onChange={(ev) => setH12(!ev.target.checked)} /> 24-hour time
                </label>
              </div>
            </div>
            <div>
              {day ? (
                <>
                  <h2 className="mb-2 text-sm font-semibold">{fullDay}</h2>
                  <SlotList
                    slots={daySlots.map((s) => ({ start: s.start }))}
                    timeZone={tz}
                    hour12={h12}
                    selected={picked}
                    onSelect={goDetails}
                  />
                </>
              ) : (
                <p className="text-sm text-text-muted">{loading ? "" : "Choose a highlighted day to see times."}</p>
              )}
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="grid max-w-md gap-4" noValidate>
            <button type="button" onClick={() => { setStage("pick"); setNotice(null); }} className="flex w-fit items-center gap-1 text-sm font-semibold text-accent">
              <ArrowLeft aria-hidden className="size-4" /> Back to times
            </button>
            <h2 className="text-lg">{reschedule ? "Confirm the new time" : "Your details"}</h2>
            {pickedSlot && event.kind === "group" && <p className="text-sm text-text-muted">{pickedSlot.remaining} {pickedSlot.remaining === 1 ? "place" : "places"} left at this time.</p>}
            {!reschedule && (
              <>
                <FieldRow>
                  <Field label="Name" required error={fieldErrors.name}><Input ref={nameRef} name="name" autoComplete="name" maxLength={120} /></Field>
                  <Field label="Email" required error={fieldErrors.email}><Input name="email" type="email" autoComplete="email" /></Field>
                </FieldRow>
                <Field label="Anything to share beforehand?" hint="Optional."><Textarea name="notes" rows={3} maxLength={2000} /></Field>
                <p className="text-xs text-text-muted">Your details are used only to arrange this meeting. <a href="/privacy" target="_blank" rel="noopener" className="font-semibold text-accent underline">How they're used<span className="sr-only"> (opens in a new tab)</span></a></p>
              </>
            )}
            <div><Button type="submit" loading={submitting}>{reschedule ? "Move my meeting" : event.priceLabel ? "Continue to payment" : "Book this time"}</Button></div>
          </form>
        )}
      </section>
    </div>
  );
}
