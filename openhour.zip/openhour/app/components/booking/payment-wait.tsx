"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

/** Stripe tells us about a payment a moment after the guest returns, so check again every few seconds. */
export function PaymentWait() {
  const router = useRouter();
  const [tries, setTries] = useState(0);
  useEffect(() => {
    if (tries >= 20) return;
    const t = setTimeout(() => { setTries((n) => n + 1); router.refresh(); }, 3000);
    return () => clearTimeout(t);
  }, [tries, router]);
  return (
    <div role="status" aria-live="polite">
      <h1 className="flex items-center gap-2 text-xl">
        {tries < 20 && <Loader2 aria-hidden className="size-5 animate-spin text-accent" />}
        {tries < 20 ? "Confirming your payment" : "Still waiting for the payment"}
      </h1>
      <p className="mt-2 text-sm text-text-muted">
        {tries < 20
          ? "This usually takes a few seconds. The time is held for you."
          : "It's taking longer than usual. If you paid, you'll get an email when it's confirmed. If you didn't, the time is released shortly."}
      </p>
    </div>
  );
}
