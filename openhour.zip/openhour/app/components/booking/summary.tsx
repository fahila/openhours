import { CalendarDays, Clock, Globe, MapPin, User } from "lucide-react";
import { fmtDay, fmtRange, zoneLabel } from "@/lib/format";
import { LOCATION_LABELS } from "@/lib/types";
import type { ManagedBooking } from "@/lib/data";

export function locationText(m: ManagedBooking) {
  const { eventType: et } = m;
  if (et.locationValue) return et.locationValue;
  if (et.locationType === "google_meet" || et.locationType === "zoom") return `${LOCATION_LABELS[et.locationType]}. The link is in your calendar invite.`;
  return LOCATION_LABELS[et.locationType];
}

export function BookingSummary({ m }: { m: ManagedBooking }) {
  const zone = m.invitee.timeZone;
  return (
    <dl className="grid gap-3 text-sm">
      <div className="flex items-start gap-3"><dt className="sr-only">Event</dt><dd className="flex items-start gap-3"><CalendarDays aria-hidden className="mt-0.5 size-4 shrink-0 text-text-muted" /><span className="break-words font-semibold">{m.eventType.name}</span></dd></div>
      <div className="flex items-start gap-3"><dt className="sr-only">With</dt><dd className="flex items-start gap-3"><User aria-hidden className="mt-0.5 size-4 shrink-0 text-text-muted" /><span>{m.host.name}</span></dd></div>
      <div className="flex items-start gap-3"><dt className="sr-only">When</dt><dd className="flex items-start gap-3"><Clock aria-hidden className="mt-0.5 size-4 shrink-0 text-text-muted" /><span>{fmtDay(m.booking.startAt, zone)}<br />{fmtRange(m.booking.startAt, m.booking.endAt, zone)}</span></dd></div>
      <div className="flex items-start gap-3"><dt className="sr-only">Time zone</dt><dd className="flex items-start gap-3"><Globe aria-hidden className="mt-0.5 size-4 shrink-0 text-text-muted" /><span>{zoneLabel(zone)}</span></dd></div>
      <div className="flex items-start gap-3"><dt className="sr-only">Where</dt><dd className="flex items-start gap-3"><MapPin aria-hidden className="mt-0.5 size-4 shrink-0 text-text-muted" /><span className="break-words">{locationText(m)}</span></dd></div>
    </dl>
  );
}
