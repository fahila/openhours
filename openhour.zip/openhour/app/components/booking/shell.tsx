import type { ReactNode } from "react";

export function GuestShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-surface px-4 py-8 md:py-14">
      <main className="mx-auto w-full max-w-[880px]">{children}</main>
    </div>
  );
}
