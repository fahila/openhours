"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Field, Textarea } from "@/components/ui/field";

export function CancelMyMeeting({ token }: { token: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function cancel() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/m/${token}/cancel`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reason }) });
      const j = await res.json().catch(() => ({}));
      // someone leaving a shared meeting no longer has a page of their own to come back to
      if (res.ok && j.left) { setOpen(false); router.push("/left"); return; }
      if (res.ok) { setOpen(false); router.push(`/m/${token}`); router.refresh(); return; }
      setError(j.errors?._ ?? "We couldn't cancel this meeting. Try again in a moment.");
    } catch {
      setError("We couldn't reach the server. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setError(null); }}>
      <DialogTrigger asChild><Button variant="secondary">Cancel meeting</Button></DialogTrigger>
      <DialogContent title="Cancel this meeting?" description="The host is told and the time opens up for someone else.">
        {error && <p role="alert" className="mb-3 text-sm font-medium text-danger">{error}</p>}
        <Field label="Reason (optional)"><Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={3} maxLength={500} /></Field>
        <div className="mt-4 flex justify-end gap-2">
          <DialogClose asChild><Button variant="ghost">Keep it</Button></DialogClose>
          <Button variant="danger" loading={busy} onClick={cancel}>Cancel meeting</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
