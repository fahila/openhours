import { EmptyState } from "@/components/ui/empty-state";

/** Placeholder for a screen that is in the recon map but not built yet. */
export function StubPage({ id, title, note }: { id: string; title: string; note: string }) {
  return (
    <div>
      <h1 className="text-xl">{title}</h1>
      <p className="mt-1 text-sm text-text-muted">Screen {id}</p>
      <div className="mt-6">
        <EmptyState title="Not built yet" body={note} />
      </div>
    </div>
  );
}
