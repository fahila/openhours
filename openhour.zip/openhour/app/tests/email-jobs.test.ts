import { closeAll, firstSlots, guest, makeHost, resetDatabase } from "./setup";
import { after, before, beforeEach, test } from "node:test";
import assert from "node:assert/strict";
import * as data from "../lib/data";
import { one, query } from "../lib/db";
import { resetEnvCache } from "../lib/env";
import { setTransport, type Email } from "../lib/email/transport";
import { runDueJobs } from "../lib/jobs/run";
import { calendarIdentity } from "../lib/data/bookings";
import { BRAND } from "../lib/brand";
import { json, startMock } from "./mock";

let host: Awaited<ReturnType<typeof makeHost>>;
const sent: Email[] = [];
let failNext = 0;

before(async () => {
  await resetDatabase();
  host = await makeHost("owner@example.com", "Sam Rivera");
  setTransport({
    async send(e) {
      if (failNext > 0) { failNext--; throw new Error("provider down"); }
      sent.push(e);
      return { id: "msg-" + sent.length };
    },
  });
});
beforeEach(() => { sent.length = 0; failNext = 0; });
after(async () => { setTransport(null); await closeAll(); });

const book = async (name: string, daysAhead = 8, idx = 0) => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, daysAhead);
  return { ...(await data.createBooking({ eventTypeId: et.id, startAt: slots[idx].start, ...guest(name) })), slot: slots[idx] };
};
const to = (addr: string) => sent.filter((e) => e.to === addr);

test("a booking sends a confirmation to the guest with a working link and invite, and a notice to the host", async () => {
  const b = await book("Ann");
  await runDueJobs();
  const g = to("ann@example.com");
  assert.equal(g.length, 1);
  assert.match(g[0].subject, /^Confirmed:/);
  assert.ok(g[0].text.includes(`/m/${b.manageToken}`), "guest email carries the manage link");
  const ics = Buffer.from(g[0].attachments![0].content, "base64").toString();
  assert.match(g[0].attachments![0].contentType, /method=REQUEST/);
  assert.ok(ics.includes("METHOD:REQUEST") && ics.includes(`UID:${b.booking.id}@${BRAND.icsDomain}`) && ics.includes("\r\n"));
  const h = to("owner@example.com");
  assert.equal(h.length, 1);
  assert.match(h[0].subject, /^New booking: Ann/);
});

test("running the jobs again sends nothing twice", async () => {
  await book("Bea");
  await runDueJobs();
  const n = sent.length;
  await query("update jobs set status = 'queued', run_at = now() where kind = 'booking.confirmed'"); // simulate a redelivered job
  await runDueJobs();
  assert.equal(sent.length, n);
});

test("guest-supplied text is escaped in the host's email", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 9);
  await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, name: "<img src=x onerror=alert(1)>", email: "evil@example.com", timeZone: "UTC", answers: { notes: "<script>alert(1)</script>" } });
  await runDueJobs();
  const h = to("owner@example.com").find((e) => e.subject.includes("evil") || e.subject.includes("img"))!;
  assert.ok(!h.html.includes("<script>") && !h.html.includes("<img src=x"));
  assert.ok(h.html.includes("&lt;script&gt;"));
});

test("a failing provider retries with backoff, then succeeds exactly once", async () => {
  failNext = 2;
  const b = await book("Cal");
  const s1 = await runDueJobs();
  assert.equal(s1.failed, 1);
  let job = (await one<{ status: string; attempts: number; run_at: Date; last_error: string }>("select status, attempts, run_at, last_error from jobs where payload->>'bookingId' = $1 and kind = 'booking.confirmed'", [b.booking.id]))!;
  assert.equal(job.status, "queued");
  assert.equal(job.attempts, 1);
  assert.ok(job.run_at.getTime() > Date.now() + 30_000, "retry is delayed");
  assert.match(job.last_error, /provider down/);
  const failedRow = await one<{ status: string }>("select status from message_log where booking_id = $1 and status = 'failed' limit 1", [b.booking.id]);
  assert.ok(failedRow);
  await query("update jobs set run_at = now() where id in (select id from jobs where payload->>'bookingId' = $1)", [b.booking.id]);
  await runDueJobs(); // second failure
  await query("update jobs set run_at = now() where id in (select id from jobs where payload->>'bookingId' = $1)", [b.booking.id]);
  await runDueJobs(); // success
  assert.equal(to("cal@example.com").length, 1);
  assert.equal(to("owner@example.com").filter((e) => e.subject.includes("Cal")).length, 1);
});

test("a job that keeps failing ends in the dead-letter state with the reason kept", async () => {
  const b = await book("Dee");
  failNext = 1000;
  for (let i = 0; i < 6; i++) {
    await query("update jobs set run_at = now() where payload->>'bookingId' = $1 and status = 'queued'", [b.booking.id]);
    await runDueJobs();
  }
  const job = (await one<{ status: string; attempts: number; last_error: string }>("select status, attempts, last_error from jobs where payload->>'bookingId' = $1 and kind = 'booking.confirmed'", [b.booking.id]))!;
  assert.deepEqual([job.status, job.attempts], ["dead", 6]);
  assert.match(job.last_error, /provider down/);
});

test("a reminder is scheduled for 24 hours before and is sent with the cancel link", async () => {
  const b = await book("Eli", 10);
  await runDueJobs();
  const j = (await one<{ run_at: Date; status: string }>("select run_at, status from jobs where kind = 'workflow.send' and payload->>'bookingId' = $1", [b.booking.id]))!;
  assert.equal(j.status, "queued");
  assert.equal(j.run_at.toISOString(), new Date(Date.parse(b.booking.startAt) - 24 * 3600_000).toISOString());
  sent.length = 0;
  await query("update jobs set run_at = now() where kind = 'workflow.send' and payload->>'bookingId' = $1", [b.booking.id]);
  await runDueJobs();
  const r = to("eli@example.com");
  assert.equal(r.length, 1);
  assert.match(r[0].subject, /Reminder/);
  assert.ok(r[0].text.includes(`/m/${b.manageToken}`));
});

test("a cancelled booking is not reminded", async () => {
  const b = await book("Fay", 11);
  await runDueJobs();
  await data.cancelByToken(b.manageToken, "plans changed");
  sent.length = 0;
  await query("update jobs set run_at = now() where kind = 'workflow.send' and payload->>'bookingId' = $1", [b.booking.id]);
  await runDueJobs();
  assert.equal(to("fay@example.com").filter((e) => /Reminder/.test(e.subject)).length, 0);
  assert.equal(to("fay@example.com").filter((e) => /^Cancelled/.test(e.subject)).length, 1, "the guest gets the cancellation notice");
  assert.equal(to("owner@example.com").filter((e) => /^Cancelled/.test(e.subject)).length, 1, "and so does the host");
  const cancelIcs = Buffer.from(to("fay@example.com").find((e) => /^Cancelled/.test(e.subject))!.attachments![0].content, "base64").toString();
  assert.ok(cancelIcs.includes("METHOD:CANCEL") && cancelIcs.includes("STATUS:CANCELLED"));
});

test("rescheduling sends one 'moved' email and no cancellation notice", async () => {
  const b = await book("Gil", 12, 0);
  await runDueJobs();
  sent.length = 0;
  const { slots } = await firstSlots(host.eventType.id, host.user.id, 12);
  await data.rescheduleByToken(b.manageToken, slots.find((s) => s.start !== b.booking.startAt)!.start);
  await runDueJobs();
  assert.equal(to("gil@example.com").length, 1);
  assert.match(to("gil@example.com")[0].subject, /^Moved:/);
  assert.equal(sent.filter((e) => /^Cancelled/.test(e.subject)).length, 0);
});

test("the host cancelling notifies the guest", async () => {
  const b = await book("Hana", 13);
  await runDueJobs();
  sent.length = 0;
  await data.cancelBookingAsHost(host.user.id, b.booking.id, "I'm unwell");
  await runDueJobs();
  const g = to("hana@example.com");
  assert.equal(g.length, 1);
  assert.ok(g[0].text.includes("cancelled by Sam Rivera") && g[0].text.includes("I'm unwell"));
});

test("the Resend transport sends the right request, with an idempotency key, and reports failures", async () => {
  const mock = await startMock((req, res) => (req.headers.authorization === "Bearer re_test" ? json(res, 200, { id: "re_1" }) : json(res, 401, { message: "bad key" })));
  setTransport(null);
  Object.assign(process.env, { RESEND_API_KEY: "re_test", EMAIL_FROM: "Openhour <hello@example.com>", RESEND_API_BASE: mock.url });
  resetEnvCache();
  const { transport } = await import("../lib/email/transport");
  const r = await transport().send({ to: "a@example.com", subject: "Hi", html: "<p>x</p>", text: "x", idempotencyKey: "k-1", attachments: [{ filename: "meeting.ics", content: "QQ==", contentType: "text/calendar" }] });
  assert.equal(r.id, "re_1");
  const req = mock.requests[0];
  assert.equal(req.path, "/emails");
  assert.equal(req.headers["idempotency-key"], "k-1");
  const body = JSON.parse(req.body);
  assert.deepEqual([body.from, body.to, body.subject], ["Openhour <hello@example.com>", ["a@example.com"], "Hi"]);
  assert.deepEqual(body.attachments, [{ filename: "meeting.ics", content: "QQ==", content_type: "text/calendar" }]);
  process.env.RESEND_API_KEY = "wrong";
  resetEnvCache();
  await assert.rejects(() => transport().send({ to: "a@example.com", subject: "Hi", html: "x", text: "x" }), /Resend 401: bad key/);
  delete process.env.RESEND_API_KEY; delete process.env.EMAIL_FROM; delete process.env.RESEND_API_BASE;
  resetEnvCache();
  await mock.close();
});

test("a meeting keeps one calendar identity however often it moves, and the sequence rises each time", async () => {
  const first = await book("Chain", 20, 0);
  assert.deepEqual(await calendarIdentity(first.booking.id), { uid: first.booking.id, sequence: 0 });
  const { slots } = await firstSlots(host.eventType.id, host.user.id, 20);
  const second = await data.rescheduleByToken(first.manageToken, slots[3].start);
  const third = await data.rescheduleByToken(second.manageToken, slots[5].start);
  assert.deepEqual(await calendarIdentity(second.booking.id), { uid: first.booking.id, sequence: 1 });
  assert.deepEqual(await calendarIdentity(third.booking.id), { uid: first.booking.id, sequence: 2 });
});
