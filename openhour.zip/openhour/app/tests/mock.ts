import http from "node:http";
import type { AddressInfo } from "node:net";

export interface Recorded { method: string; path: string; headers: http.IncomingHttpHeaders; body: string }
export type MockHandler = (req: Recorded, res: http.ServerResponse) => void | Promise<void>;

/** A tiny local HTTP server that records every request, standing in for Resend, Google or Stripe. */
export async function startMock(handler: MockHandler, listenPort = 0) {
  const requests: Recorded[] = [];
  const server = http.createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    const rec = { method: req.method ?? "GET", path: req.url ?? "/", headers: req.headers, body: Buffer.concat(chunks).toString("utf8") };
    requests.push(rec);
    try { await handler(rec, res); } catch (e) { res.statusCode = 500; res.end(String(e)); }
  });
  await new Promise<void>((r) => server.listen(listenPort, "127.0.0.1", r));
  const { port } = server.address() as AddressInfo;
  return { url: `http://127.0.0.1:${port}`, port, requests, close: () => new Promise<void>((r) => { server.closeAllConnections?.(); server.close(() => r()); }) };
}

export const json = (res: http.ServerResponse, status: number, body: unknown) => {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(body));
};
