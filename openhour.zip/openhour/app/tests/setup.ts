/** Import this first in every database test file. Points the app at TEST_DATABASE_URL and gives each file a clean schema. */
import { randomBytes } from "node:crypto";

const url = process.env.TEST_DATABASE_URL;
if (!url) throw new Error("Set TEST_DATABASE_URL to a scratch Postgres database (it is wiped). Example: postgres://postgres@127.0.0.1:5545/scheduler_test");
if (!/test/i.test(new URL(url).pathname)) throw new Error("TEST_DATABASE_URL must point at a database whose name contains 'test'. It gets wiped.");

process.env.DATABASE_URL = url;
process.env.APP_URL = "http://localhost:3055";
process.env.APP_ENCRYPTION_KEY ??= randomBytes(32).toString("base64");
process.env.ALLOWED_EMAILS = "owner@example.com";
(process.env as Record<string, string>).NODE_ENV = "test";

import { Client } from "pg";
import { DateTime } from "luxon";
import { migrate } from "../scripts/migrate";

export async function resetDatabase() {
  const c = new Client({ connectionString: url });
  await c.connect();
  await c.query("drop schema public cascade; create schema public;");
  await c.end();
  await migrate(url!, () => {});
}

export async function closeAll() {
  const { closePool } = await import("../lib/db");
  await closePool();
}

/** A host in New York with the default Monday to Friday 9 to 5 hours. */
export async function makeHost(email: string, name = "Test Host") {
  const { createUserWithDefaults, listSchedules, saveSchedule, listEventTypes } = await import("../lib/data");
  const user = await createUserWithDefaults({ email, name });
  const [sch] = await listSchedules(user.id);
  await saveSchedule(user.id, sch.id, { name: sch.name, timeZone: "America/New_York", rules: sch.rules, overrides: [] });
  const [et] = await listEventTypes(user.id);
  return { user, schedule: sch, eventType: et };
}

export async function firstSlots(eventTypeId: string, userId: string, daysAhead = 8) {
  const { getEventType, getSlots } = await import("../lib/data");
  const et = (await getEventType(userId, eventTypeId))!;
  const from = DateTime.now().plus({ days: daysAhead }).toISODate()!;
  return { et, slots: await getSlots(et, from, DateTime.fromISO(from).plus({ days: 7 }).toISODate()!) };
}

export const guest = (n: string) => ({ name: n, email: `${n.toLowerCase()}@example.com`, timeZone: "Asia/Kolkata" });
