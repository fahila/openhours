import { closeAll, firstSlots, guest, makeHost, resetDatabase } from "./setup";
import { after, before, test } from "node:test";
import assert from "node:assert/strict";
import { DateTime } from "luxon";
import * as data from "../lib/data";
import { one, query } from "../lib/db";

let host: Awaited<ReturnType<typeof makeHost>>;
let other: Awaited<ReturnType<typeof makeHost>>;

before(async () => {
  await resetDatabase();
  host = await makeHost("owner@example.com", "Sam Rivera");
  other = await makeHost("intruder@example.com", "Ivy Intruder");
});
after(closeAll);

test("a booking takes the slot; a second guest cannot book it", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id);
  const a = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Ann") });
  assert.equal(a.booking.status, "confirmed");
  await assert.rejects(() => data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Bob") }), data.SlotUnavailableError);
});

test("ten bookings racing for one slot: exactly one wins", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id);
  const target = slots[5].start;
  const results = await Promise.allSettled(Array.from({ length: 10 }, (_, i) => data.createBooking({ eventTypeId: et.id, startAt: target, ...guest("Racer" + i) })));
  assert.equal(results.filter((r) => r.status === "fulfilled").length, 1);
  assert.equal(results.filter((r) => r.status === "rejected" && r.reason instanceof data.SlotUnavailableError).length, 9);
});

test("the database refuses overlapping bookings even if application code is bypassed", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 20);
  await data.createBooking({ eventTypeId: et.id, startAt: slots[2].start, ...guest("Cy") });
  await assert.rejects(
    () => query("insert into bookings (event_type_id, host_id, start_at, end_at) values ($1, $2, $3, $4)", [et.id, host.user.id, slots[2].start, slots[2].end]),
    (e: { code?: string }) => e.code === "23P01",
  );
});

test("a time that is not an open slot is refused", async () => {
  await assert.rejects(() => data.createBooking({ eventTypeId: host.eventType.id, startAt: "2026-11-08T03:17:00.000Z", ...guest("Flo") }), data.SlotUnavailableError);
  await assert.rejects(() => data.createBooking({ eventTypeId: host.eventType.id, startAt: "garbage", ...guest("Flo") }), data.SlotUnavailableError);
});

test("bad input is rejected with field errors", async () => {
  const { slots } = await firstSlots(host.eventType.id, host.user.id);
  await assert.rejects(() => data.createBooking({ eventTypeId: host.eventType.id, startAt: slots[3].start, name: "", email: "nope", timeZone: "Asia/Kolkata" }),
    (e: unknown) => e instanceof data.ValidationError && "name" in e.errors && "email" in e.errors);
});

test("cancelling frees the slot", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id);
  const target = slots[8].start;
  const { manageToken } = await data.createBooking({ eventTypeId: et.id, startAt: target, ...guest("Gus") });
  await data.cancelByToken(manageToken, "clash");
  const again = await data.createBooking({ eventTypeId: et.id, startAt: target, ...guest("Hal") });
  assert.equal(again.booking.status, "confirmed");
});

test("rescheduling moves the guest, links the bookings, and the old time is free", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id);
  const { manageToken, booking } = await data.createBooking({ eventTypeId: et.id, startAt: slots[10].start, ...guest("Ivy") });
  const moved = await data.rescheduleByToken(manageToken, slots[12].start);
  assert.equal(moved.booking.rescheduledFrom, booking.id);
  assert.equal((await data.getBookingById(booking.id))!.status, "cancelled");
  assert.ok(await data.findByManageToken(moved.manageToken));
  const { slots: after } = await firstSlots(host.eventType.id, host.user.id);
  assert.ok(after.some((s) => s.start === slots[10].start));
});

test("a guest can move a booking onto its own neighbour slot without being blocked by their old time", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 25);
  const { manageToken } = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Jo") });
  const moved = await data.rescheduleByToken(manageToken, slots[0].start); // same time is allowed: it is their own
  assert.equal(moved.booking.startAt, slots[0].start);
});

test("group events let several guests share a slot until full", async () => {
  const gt = await data.saveEventType(host.user.id, null, {
    scheduleId: host.schedule.id, kind: "group", name: "Office hours", slug: "office-hours", description: null, colorIndex: 3, durationMin: 60, maxInvitees: 3,
    locationType: "custom", locationValue: "Studio", bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 60,
    limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: false, priceCents: null, currency: null,
  });
  const { slots } = await firstSlots(gt.id, host.user.id, 30);
  const t = slots[0].start;
  for (const n of ["Jan", "Kit", "Lee"]) await data.createBooking({ eventTypeId: gt.id, startAt: t, ...guest(n) });
  await assert.rejects(() => data.createBooking({ eventTypeId: gt.id, startAt: t, ...guest("Oz") }), data.SlotUnavailableError);
  const row = await one<{ n: string }>("select count(*) as n from bookings where event_type_id = $1 and start_at = $2", [gt.id, t]);
  assert.equal(row!.n, "1"); // one meeting, three guests
  await assert.rejects(() => data.createBooking({ eventTypeId: gt.id, startAt: slots[1].start, ...guest("Jan") }).then(() => data.createBooking({ eventTypeId: gt.id, startAt: slots[1].start, ...guest("Jan") })), data.ValidationError);
});

test("a daily limit closes the day", async () => {
  const lt = await data.saveEventType(host.user.id, null, {
    scheduleId: host.schedule.id, kind: "one_on_one", name: "Limited", slug: "limited", description: null, colorIndex: 4, durationMin: 30, maxInvitees: 1,
    locationType: "zoom", locationValue: null, bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 30,
    limitPerDay: 1, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: false, priceCents: null, currency: null,
  });
  const { slots } = await firstSlots(lt.id, host.user.id, 40);
  await data.createBooking({ eventTypeId: lt.id, startAt: slots[0].start, ...guest("Lim") });
  const sameDay = DateTime.fromISO(slots[0].start, { zone: "America/New_York" }).toISODate();
  const left = (await firstSlots(lt.id, host.user.id, 40)).slots.filter((s) => DateTime.fromISO(s.start, { zone: "America/New_York" }).toISODate() === sameDay);
  assert.equal(left.length, 0);
});

// ---- authorization: a second user gets nothing -----------------------------------

test("another user cannot read or change this host's rows", async () => {
  assert.equal(await data.getEventType(other.user.id, host.eventType.id), null);
  assert.equal(await data.getSchedule(other.user.id, host.schedule.id), null);
  await assert.rejects(() => data.saveSchedule(other.user.id, host.schedule.id, { name: "x", timeZone: "UTC", rules: [], overrides: [] }), data.NotFoundError);
  await assert.rejects(() => data.setEventTypeActive(other.user.id, host.eventType.id, false), data.NotFoundError);
  await assert.rejects(() => data.deleteEventType(other.user.id, host.eventType.id), data.NotFoundError);
  assert.deepEqual((await data.listEventTypes(other.user.id)).map((e) => e.userId), [other.user.id]);
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 50);
  const { booking } = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Zed") });
  await assert.rejects(() => data.cancelBookingAsHost(other.user.id, booking.id, null), data.NotFoundError);
  assert.equal((await data.listBookings(other.user.id, "upcoming")).length, 0);
  assert.equal((await data.getBookingById(booking.id))!.status, "confirmed");
});

test("another user cannot attach an event type to this host's hours", async () => {
  await assert.rejects(() => data.saveEventType(other.user.id, null, {
    scheduleId: host.schedule.id, kind: "one_on_one", name: "Sneaky", slug: "sneaky", description: null, colorIndex: 1, durationMin: 30, maxInvitees: 1,
    locationType: "zoom", locationValue: null, bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 30,
    limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: false, priceCents: null, currency: null,
  }), data.ValidationError);
});

test("a manage token only opens the one booking it belongs to", async () => {
  assert.equal(await data.findByManageToken("not-a-token"), null);
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 60);
  const a = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Tia") });
  const m = await data.findByManageToken(a.manageToken);
  assert.equal(m!.invitee.email, "tia@example.com");
  assert.ok(!JSON.stringify(m).includes(a.manageToken), "the raw token is never stored");
});

// ---- jobs are written with the change ---------------------------------------------

test("a booking enqueues its confirmation job in the same transaction", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 70);
  const { booking } = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Uma") });
  const j = await one("select kind, status from jobs where payload->>'bookingId' = $1", [booking.id]);
  assert.deepEqual(j, { kind: "booking.confirmed", status: "queued" });
});

test("a refused booking leaves no job behind", async () => {
  const before = await one<{ n: string }>("select count(*) as n from jobs");
  await assert.rejects(() => data.createBooking({ eventTypeId: host.eventType.id, startAt: "2026-11-08T03:17:00.000Z", ...guest("Vic") }));
  const after = await one<{ n: string }>("select count(*) as n from jobs");
  assert.equal(after!.n, before!.n);
});

// ---- account deletion --------------------------------------------------------------

test("deleting an account removes the person and everything of theirs", async () => {
  const doomed = await makeHost("doomed@example.com", "Doomed Host");
  const { et, slots } = await firstSlots(doomed.eventType.id, doomed.user.id, 80);
  const wes = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Wes") });
  await query("insert into payments (booking_id, provider_session_id, amount_cents, currency, status) values ($1, 'cs_doomed', 5000, 'usd', 'paid')", [wes.booking.id]);
  await data.deleteUser(doomed.user.id);
  assert.equal((await one<{ n: string }>("select count(*) as n from payments where provider_session_id = 'cs_doomed'"))!.n, "0");
  for (const t of ["users", "event_types", "availability_schedules", "bookings", "workflows", "login_identities"]) {
    const col = t === "users" ? "id" : t === "login_identities" ? "user_id" : t === "bookings" ? "host_id" : "user_id";
    const n = await one<{ n: string }>(`select count(*) as n from ${t} where ${col} = $1`, [doomed.user.id]);
    assert.equal(n!.n, "0", t);
  }
  const guestRows = await one<{ n: string }>("select count(*) as n from booking_invitees where email = 'wes@example.com'");
  assert.equal(guestRows!.n, "0");
  assert.ok(await data.getUserBySlug(host.user.slug), "other users are untouched");
});

// ---- time zones --------------------------------------------------------------------

test("slots are DST correct on the spring-forward day", async () => {
  const sch = await data.getSchedule(host.user.id, host.schedule.id);
  await data.saveSchedule(host.user.id, host.schedule.id, { name: sch!.name, timeZone: "America/New_York", rules: [{ dayOfWeek: 0, start: "01:00", end: "04:00" }], overrides: [] });
  const et = (await data.getEventType(host.user.id, host.eventType.id))!;
  const slots = await data.getSlots({ ...et, minNoticeMin: 0, rollingDays: null }, "2027-03-14", "2027-03-14");
  const local = slots.map((s) => DateTime.fromISO(s.start, { zone: "America/New_York" }).toFormat("HH:mm"));
  assert.deepEqual(local, ["01:00", "01:30", "03:00", "03:30"]);
});
