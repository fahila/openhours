import { test } from "node:test";
import assert from "node:assert/strict";
import { DateTime } from "luxon";
import { generateSlots } from "../lib/slots";
import type { Booking, EventType, Schedule } from "../lib/types";

const weekdays = [1, 2, 3, 4, 5].map((d) => ({ dayOfWeek: d, start: "09:00", end: "17:00" }));

const schedule = (over: Partial<Schedule> = {}): Schedule => ({
  id: "s1", userId: "u1", name: "Work", timeZone: "America/New_York", isDefault: true, rules: weekdays, overrides: [], ...over,
});
const eventType = (over: Partial<EventType> = {}): EventType => ({
  id: "e1", userId: "u1", scheduleId: "s1", kind: "one_on_one", name: "Intro", slug: "intro", description: null,
  colorIndex: 1, durationMin: 30, maxInvitees: 1, locationType: "google_meet", locationValue: null,
  bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 30,
  limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: false, priceCents: null, currency: null, active: true, hidden: false, ...over,
});
const booking = (start: string, mins = 30, over: Partial<Booking> = {}): Booking => ({
  id: "b" + start, eventTypeId: "e1", hostId: "u1", startAt: start,
  endAt: new Date(Date.parse(start) + mins * 60_000).toISOString(), status: "confirmed", meetingUrl: null,
  cancelReason: null, rescheduledFrom: null, createdAt: start,
  invitees: [{ id: "i", name: "G", email: "g@x.co", timeZone: "UTC", answers: {}, manageTokenHash: "h", noShow: false }], ...over,
});
const NOW = new Date("2026-01-01T00:00:00Z");
const run = (date: string, o: { et?: Partial<EventType>; sc?: Partial<Schedule>; bookings?: Booking[]; now?: Date; to?: string } = {}) =>
  generateSlots({ eventType: eventType(o.et), schedule: schedule(o.sc), bookings: o.bookings ?? [], now: o.now ?? NOW, fromDate: date, toDate: o.to ?? date });
const localTimes = (slots: { start: string }[], zone: string) => slots.map((s) => DateTime.fromISO(s.start, { zone }).toFormat("HH:mm"));

test("a weekday 9-17 in 30 minute steps gives 16 slots, none on a weekend", () => {
  const s = run("2026-11-02"); // Monday
  assert.equal(s.length, 16);
  assert.equal(localTimes(s, "America/New_York")[0], "09:00");
  assert.equal(localTimes(s, "America/New_York")[15], "16:30");
  assert.equal(run("2026-11-07").length, 0); // Saturday
});

test("spring forward: the missing 02:00 hour produces no slots", () => {
  const sc = { rules: [{ dayOfWeek: 0, start: "01:00", end: "04:00" }] };
  const s = run("2026-03-08", { sc });
  assert.deepEqual(localTimes(s, "America/New_York"), ["01:00", "01:30", "03:00", "03:30"]);
});

test("fall back: the repeated hour is offered once per real half hour", () => {
  const sc = { rules: [{ dayOfWeek: 0, start: "00:00", end: "03:00" }] };
  const s = run("2026-11-01", { sc });
  assert.equal(s.length, 8); // 4 real hours
  assert.equal(new Set(s.map((x) => x.start)).size, 8);
});

test("a half hour offset zone (Asia/Kolkata) maps to the right UTC instants", () => {
  const s = run("2026-11-02", { sc: { timeZone: "Asia/Kolkata" } });
  assert.equal(s[0].start, "2026-11-02T03:30:00.000Z");
});

test("minimum notice removes slots that are too soon", () => {
  const now = new Date("2026-11-02T14:00:00Z"); // 09:00 New York
  const s = run("2026-11-02", { now, et: { minNoticeMin: 120 } });
  assert.equal(localTimes(s, "America/New_York")[0], "11:00");
});

test("an existing booking removes its slot, and buffers remove the neighbours", () => {
  const b = booking("2026-11-02T15:00:00.000Z"); // 10:00 NY
  assert.ok(!run("2026-11-02", { bookings: [b] }).some((x) => x.start === b.startAt));
  const t = localTimes(run("2026-11-02", { bookings: [b], et: { bufferBeforeMin: 30, bufferAfterMin: 30 } }), "America/New_York");
  assert.ok(!t.includes("09:30") && !t.includes("10:30") && t.includes("09:00") && t.includes("11:00"));
});

test("a cancelled booking does not block", () => {
  const b = booking("2026-11-02T15:00:00.000Z", 30, { status: "cancelled" });
  assert.equal(run("2026-11-02", { bookings: [b] }).length, 16);
});

test("ignoreBookingId lets a booking move onto its own slot", () => {
  const b = booking("2026-11-02T15:00:00.000Z");
  const s = generateSlots({ eventType: eventType(), schedule: schedule(), bookings: [b], now: NOW, fromDate: "2026-11-02", toDate: "2026-11-02", ignoreBookingId: b.id });
  assert.ok(s.some((x) => x.start === b.startAt));
});

test("a group slot stays open until capacity is reached, then closes", () => {
  const et = { kind: "group" as const, maxInvitees: 2 };
  const inv = (id: string) => ({ id, name: id, email: id + "@x.co", timeZone: "UTC", answers: {}, manageTokenHash: id, noShow: false });
  const one = booking("2026-11-02T15:00:00.000Z");
  const open = run("2026-11-02", { et, bookings: [one] }).find((x) => x.start === one.startAt);
  assert.equal(open?.remaining, 1);
  const full = booking("2026-11-02T15:00:00.000Z", 30, { invitees: [inv("a"), inv("b")] });
  assert.ok(!run("2026-11-02", { et, bookings: [full] }).some((x) => x.start === full.startAt));
});

test("a booking for another event type blocks overlapping time", () => {
  const other = booking("2026-11-02T15:00:00.000Z", 60, { eventTypeId: "e2" });
  const t = localTimes(run("2026-11-02", { bookings: [other] }), "America/New_York");
  assert.ok(!t.includes("10:00") && !t.includes("10:30") && t.includes("11:00"));
});

test("daily and weekly limits close the day", () => {
  const b = booking("2026-11-02T15:00:00.000Z");
  assert.equal(run("2026-11-02", { bookings: [b], et: { limitPerDay: 1 } }).length, 0);
  assert.equal(run("2026-11-03", { bookings: [b], et: { limitPerDay: 1 } }).length, 16);
  assert.equal(run("2026-11-03", { bookings: [b], et: { limitPerWeek: 1 } }).length, 0);
});

test("date overrides: an off day, and extra hours on a Saturday", () => {
  assert.equal(run("2026-11-02", { sc: { overrides: [{ date: "2026-11-02", start: null, end: null }] } }).length, 0);
  const s = run("2026-11-07", { sc: { overrides: [{ date: "2026-11-07", start: "10:00", end: "12:00" }] } });
  assert.deepEqual(localTimes(s, "America/New_York"), ["10:00", "10:30", "11:00", "11:30"]);
});

test("rolling days cuts off the far end", () => {
  const now = new Date("2026-11-02T12:00:00Z");
  const s = run("2026-11-02", { now, to: "2026-11-30", et: { rollingDays: 7 } });
  const days = new Set(s.map((x) => DateTime.fromISO(x.start, { zone: "America/New_York" }).toISODate()));
  assert.ok(days.size <= 5 && !days.has("2026-11-10"));
});

test("start increments of 60 give half as many slots", () => {
  assert.equal(run("2026-11-02", { et: { startIncrementMin: 60 } }).length, 8);
});

test("busy times from a connected calendar block slots, with buffers applied", () => {
  const busy = [{ start: "2026-11-02T15:00:00.000Z", end: "2026-11-02T16:00:00.000Z" }]; // 10:00-11:00 New York
  const plain = localTimes(generateSlots({ eventType: eventType(), schedule: schedule(), bookings: [], busy, now: NOW, fromDate: "2026-11-02", toDate: "2026-11-02" }), "America/New_York");
  assert.ok(!plain.includes("10:00") && !plain.includes("10:30") && plain.includes("09:30") && plain.includes("11:00"));
  const buffered = localTimes(generateSlots({ eventType: eventType({ bufferAfterMin: 30, bufferBeforeMin: 30 }), schedule: schedule(), bookings: [], busy, now: NOW, fromDate: "2026-11-02", toDate: "2026-11-02" }), "America/New_York");
  assert.ok(!buffered.includes("09:30") && !buffered.includes("11:00") && buffered.includes("09:00") && buffered.includes("11:30"));
});
