import { json, startMock, type Recorded } from "./mock";
import type { ServerResponse } from "node:http";

export interface GoogleState {
  calendars: { id: string; summary: string; primary?: boolean; accessRole: string }[];
  busy: Record<string, { start: string; end: string }[]>;
  calendarErrors: Record<string, string>;
  events: Map<string, { calendarId: string; body: Record<string, unknown>; gets: number }>;
  revokedRefreshTokens: Set<string>;
  failFreebusy: number;
  failEventInsert: number;
  /** hangoutLink appears only after this many GETs of the event, like Google creating Meet links in the background */
  meetAfterGets: number;
  deleted: string[];
  revoked: string[];
  scope: string;
  profile: { sub: string; email: string; email_verified: boolean; name: string };
  nextRefreshToken: string;
  /** every Calendar API call answers 401, like an access token that was revoked */
  rejectApiTokens: boolean;
  /** only this one access token is refused (a refresh gives a new one that works) */
  rejectToken: string | null;
}

export function newGoogleState(): GoogleState {
  return {
    calendars: [
      { id: "primary@example.com", summary: "Sam Rivera", primary: true, accessRole: "owner" },
      { id: "team@group.example.com", summary: "Team calendar", accessRole: "reader" },
    ],
    busy: {}, calendarErrors: {}, events: new Map(), revokedRefreshTokens: new Set(), failFreebusy: 0, failEventInsert: 0, meetAfterGets: 0,
    deleted: [], revoked: [],
    scope: "openid https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/calendar.calendarlist.readonly https://www.googleapis.com/auth/calendar.freebusy https://www.googleapis.com/auth/calendar.events",
    profile: { sub: "g-123", email: "owner@example.com", email_verified: true, name: "Sam Rivera" },
    nextRefreshToken: "refresh-1", rejectApiTokens: false, rejectToken: null,
  };
}

export function makeGoogleHandler(state: GoogleState) {
  let tokenCounter = 0;
  return (req: Recorded, res: ServerResponse): void => {
    const url = new URL(req.path, "http://x");
    const p = url.pathname;
    const body = req.body && req.headers["content-type"]?.includes("json") ? JSON.parse(req.body) : {};

    // browser step of the OAuth dance: approve at once and send the person back with a code
    if (p === "/oauth/auth") {
      const back = new URL(url.searchParams.get("redirect_uri")!);
      back.searchParams.set("code", "good-code");
      back.searchParams.set("state", url.searchParams.get("state") ?? "");
      res.statusCode = 302;
      res.setHeader("Location", back.toString());
      return void res.end();
    }
    if (p === "/oauth/token") {
      const form = new URLSearchParams(req.body);
      if (form.get("grant_type") === "refresh_token") {
        if (state.revokedRefreshTokens.has(form.get("refresh_token") ?? "")) return json(res, 400, { error: "invalid_grant" });
        return json(res, 200, { access_token: `at-${++tokenCounter}`, expires_in: 3600 });
      }
      if (form.get("code") === "bad-code") return json(res, 400, { error: "invalid_grant" });
      return json(res, 200, { access_token: `at-${++tokenCounter}`, expires_in: 3600, refresh_token: state.nextRefreshToken, scope: state.scope });
    }
    if (p === "/oauth/userinfo") return json(res, 200, state.profile);
    if (p === "/oauth/revoke") { state.revoked.push(new URLSearchParams(req.body).get("token") ?? ""); return json(res, 200, {}); }

    if (state.rejectApiTokens || req.headers.authorization === `Bearer ${state.rejectToken}` || !req.headers.authorization?.startsWith("Bearer at-")) return json(res, 401, { error: { message: "no token" } });

    if (p === "/calendar/v3/users/me/calendarList") return json(res, 200, { items: state.calendars });
    if (p === "/calendar/v3/freeBusy") {
      if (state.failFreebusy > 0) { state.failFreebusy--; return json(res, 500, { error: { message: "backend error" } }); }
      const calendars: Record<string, unknown> = {};
      for (const it of body.items as { id: string }[]) {
        calendars[it.id] = state.calendarErrors[it.id] ? { errors: [{ reason: state.calendarErrors[it.id] }] } : { busy: state.busy[it.id] ?? [] };
      }
      return json(res, 200, { calendars });
    }
    const ev = p.match(/^\/calendar\/v3\/calendars\/([^/]+)\/events(?:\/([^/]+))?$/);
    if (ev) {
      const calendarId = decodeURIComponent(ev[1]);
      if (req.method === "POST") {
        if (state.failEventInsert > 0) { state.failEventInsert--; return json(res, 503, { error: { message: "unavailable" } }); }
        if (state.events.has(body.id)) return json(res, 409, { error: { message: "duplicate" } });
        state.events.set(body.id, { calendarId, body: { ...body, query: Object.fromEntries(url.searchParams) }, gets: 0 });
        const wantsMeet = Boolean(body.conferenceData);
        return json(res, 200, { id: body.id, ...(wantsMeet && state.meetAfterGets === 0 ? { hangoutLink: `https://meet.example.com/${body.id.slice(0, 8)}` } : {}) });
      }
      if (req.method === "GET") {
        const e = state.events.get(ev[2]);
        if (!e) return json(res, 404, { error: { message: "not found" } });
        e.gets++;
        const meet = Boolean(e.body.conferenceData) && e.gets >= state.meetAfterGets;
        return json(res, 200, { id: ev[2], ...(meet ? { hangoutLink: `https://meet.example.com/${ev[2].slice(0, 8)}` } : {}) });
      }
      if (req.method === "DELETE") {
        if (!state.events.has(ev[2])) return json(res, 404, { error: { message: "not found" } });
        state.events.delete(ev[2]);
        state.deleted.push(ev[2]);
        res.statusCode = 204;
        return void res.end();
      }
    }
    json(res, 404, { error: { message: `unhandled ${req.method} ${p}` } });
  };
}

export async function startGoogleMock() {
  const state = newGoogleState();
  const h = makeGoogleHandler(state);
  const mock = await startMock((req, res) => { h(req, res); });
  return { ...mock, state };
}

/** Point the app at the mock and make Google look configured. */
export function useGoogleMock(url: string) {
  Object.assign(process.env, { GOOGLE_CLIENT_ID: "test-client", GOOGLE_CLIENT_SECRET: "test-secret", GOOGLE_OAUTH_BASE: `${url}/oauth`, GOOGLE_API_BASE: url });
}
export function clearGoogleEnv() {
  for (const k of ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_OAUTH_BASE", "GOOGLE_API_BASE"]) delete process.env[k];
}
