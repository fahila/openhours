import { closeAll, firstSlots, guest, makeHost, resetDatabase } from "./setup";
import { after, before, beforeEach, mock, test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { DateTime } from "luxon";
import * as data from "../lib/data";
import { one, query } from "../lib/db";
import { resetEnvCache } from "../lib/env";
import { encrypt } from "../lib/crypto";
import { authUrl, exchangeCode, fetchProfile, newPending, readPending, redirectUri, CALENDAR_SCOPES } from "../lib/auth/google";
import { disconnect, listConnections, revokeAllConnections, saveGoogleConnection, setCalendarFlags } from "../lib/calendar/connections";
import { clearBusyCache } from "../lib/calendar/busy";
import { ensureCalendarEvent, eventIdFor } from "../lib/calendar/events";
import { forgetToken } from "../lib/calendar/google";
import { setTransport, type Email } from "../lib/email/transport";
import { runDueJobs } from "../lib/jobs/run";
import { clearGoogleEnv, startGoogleMock, useGoogleMock } from "./google-mock";

let g: Awaited<ReturnType<typeof startGoogleMock>>;
let host: Awaited<ReturnType<typeof makeHost>>;
let other: Awaited<ReturnType<typeof makeHost>>;
let connId: string;
const sent: Email[] = [];

const connect = async (userId = host.user.id, refresh = "refresh-1") =>
  saveGoogleConnection(userId, { sub: "g-" + userId.slice(0, 4), email: "owner@example.com", refreshToken: refresh, scopes: g.state.scope.split(" ") });

before(async () => {
  await resetDatabase();
  g = await startGoogleMock();
  useGoogleMock(g.url);
  resetEnvCache();
  host = await makeHost("owner@example.com", "Sam Rivera");
  other = await makeHost("other@example.com", "Other Person");
  setTransport({ async send(e) { sent.push(e); return { id: "m" + sent.length }; } });
});
beforeEach(() => {
  clearBusyCache();
  g.state.failFreebusy = 0; g.state.failEventInsert = 0; g.state.meetAfterGets = 0; g.state.busy = {}; g.state.calendarErrors = {};
  g.requests.length = 0; sent.length = 0;
});
after(async () => { setTransport(null); clearGoogleEnv(); resetEnvCache(); await g.close(); await closeAll(); });

// ---- OAuth plumbing ---------------------------------------------------------------

test("PKCE: the challenge is the S256 hash of the verifier, and the URL asks for offline access and consent", () => {
  const { pending, challenge } = newPending("calendar", "u1");
  assert.equal(challenge, createHash("sha256").update(pending.verifier).digest("base64url"));
  const u = new URL(authUrl({ scopes: CALENDAR_SCOPES, redirect: redirectUri("/api/calendars/callback/google"), state: pending.state, challenge, offline: true }));
  assert.equal(u.searchParams.get("code_challenge_method"), "S256");
  assert.equal(u.searchParams.get("access_type"), "offline");
  assert.equal(u.searchParams.get("prompt"), "consent");
  assert.equal(u.searchParams.get("client_id"), "test-client");
  assert.equal(u.searchParams.get("redirect_uri"), "http://localhost:3055/api/calendars/callback/google");
  assert.deepEqual(u.searchParams.get("scope")!.split(" "), CALENDAR_SCOPES);
});

test("the pending-OAuth cookie rejects a wrong state, a wrong purpose, tampering and expiry", () => {
  const { pending, cookie } = newPending("login");
  assert.ok(readPending(cookie, pending.state, "login"));
  assert.equal(readPending(cookie, "other-state", "login"), null);
  assert.equal(readPending(cookie, pending.state, "calendar"), null);
  assert.equal(readPending(cookie.slice(0, -4) + "AAAA", pending.state, "login"), null);
  assert.equal(readPending(undefined, pending.state, "login"), null);
  const stale = encrypt(JSON.stringify({ ...pending, exp: Date.now() - 1 })).toString("base64url");
  assert.equal(readPending(stale, pending.state, "login"), null);
});

test("code exchange and profile lookup talk to Google's endpoints with the right form", async () => {
  const t = await exchangeCode("auth-code", "verifier-123", "http://localhost:3055/cb");
  assert.equal(t.refresh_token, "refresh-1");
  const form = new URLSearchParams(g.requests.at(-1)!.body);
  assert.deepEqual([form.get("grant_type"), form.get("code"), form.get("code_verifier"), form.get("client_secret")], ["authorization_code", "auth-code", "verifier-123", "test-secret"]);
  assert.equal((await fetchProfile(t.access_token)).email, "owner@example.com");
  await assert.rejects(() => exchangeCode("bad-code", "v", "http://x"), /invalid_grant/);
});

// ---- connections -------------------------------------------------------------------

test("connecting stores the refresh token encrypted and imports the calendars", async () => {
  connId = await connect();
  const raw = await one<{ refresh_token_enc: Buffer }>("select refresh_token_enc from calendar_connections where id = $1", [connId]);
  assert.ok(!raw!.refresh_token_enc.toString("utf8").includes("refresh-1"), "no plaintext token in the database");
  const [c] = await listConnections(host.user.id);
  assert.equal(c.status, "active");
  const primary = c.calendars.find((x) => x.providerCalendarId === "primary@example.com")!;
  const team = c.calendars.find((x) => x.providerCalendarId === "team@group.example.com")!;
  assert.deepEqual([primary.checkConflicts, primary.isBookingTarget], [true, true]);
  assert.deepEqual([team.checkConflicts, team.isBookingTarget], [false, false], "a read-only calendar is never the target");
  await connect();
  assert.equal((await listConnections(host.user.id)).length, 1, "reconnecting updates instead of duplicating");
});

test("only one calendar receives bookings, and another user cannot change these flags", async () => {
  const [c] = await listConnections(host.user.id);
  const team = c.calendars.find((x) => x.providerCalendarId === "team@group.example.com")!;
  await setCalendarFlags(host.user.id, team.id, { isBookingTarget: true });
  const after = (await listConnections(host.user.id))[0].calendars;
  assert.equal(after.filter((x) => x.isBookingTarget).length, 1);
  assert.ok(after.find((x) => x.id === team.id)!.isBookingTarget);
  await assert.rejects(() => setCalendarFlags(other.user.id, team.id, { checkConflicts: true }), data.NotFoundError);
  const primary = c.calendars.find((x) => x.providerCalendarId === "primary@example.com")!;
  await setCalendarFlags(host.user.id, primary.id, { isBookingTarget: true });
  assert.equal((await listConnections(other.user.id)).length, 0);
});

// ---- busy times ----------------------------------------------------------------------

const nyDay = () => DateTime.now().plus({ days: 9 }).setZone("America/New_York");
const busyBlock = (hour: number) => {
  const d = nyDay().set({ hour, minute: 0, second: 0, millisecond: 0 });
  return { start: d.toUTC().toISO()!, end: d.plus({ hours: 1 }).toUTC().toISO()! };
};

test("busy time on a checked calendar removes those slots", async () => {
  g.state.busy["primary@example.com"] = [busyBlock(10)];
  const { slots } = await firstSlots(host.eventType.id, host.user.id, 9);
  const local = slots.map((s) => DateTime.fromISO(s.start, { zone: "America/New_York" })).filter((d) => d.toISODate() === nyDay().toISODate()).map((d) => d.toFormat("HH:mm"));
  assert.ok(local.length > 0 && !local.includes("10:00") && !local.includes("10:30") && local.includes("09:30") && local.includes("11:00"), local.join(","));
});

test("a calendar that is not checked does not block", async () => {
  g.state.busy["team@group.example.com"] = [busyBlock(14)];
  const { slots } = await firstSlots(host.eventType.id, host.user.id, 9);
  assert.ok(slots.some((s) => DateTime.fromISO(s.start, { zone: "America/New_York" }).toFormat("HH:mm") === "14:00" && DateTime.fromISO(s.start, { zone: "America/New_York" }).toISODate() === nyDay().toISODate()));
});

test("booking over a time that went busy a moment ago is refused", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 9); // listing saw it free
  const target = slots.find((s) => DateTime.fromISO(s.start, { zone: "America/New_York" }).toFormat("HH:mm") === "13:00" && DateTime.fromISO(s.start, { zone: "America/New_York" }).toISODate() === nyDay().toISODate())!;
  g.state.busy["primary@example.com"] = [{ start: target.start, end: target.end }];
  await assert.rejects(() => data.createBooking({ eventTypeId: et.id, startAt: target.start, ...guest("Race") }), data.SlotUnavailableError);
});

test("if Google cannot be asked, a booking is refused and no times are offered", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 9);
  clearBusyCache();
  g.state.failFreebusy = 10;
  await assert.rejects(() => data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, ...guest("Down") }), data.CalendarUnavailableError);
  await assert.rejects(() => firstSlots(host.eventType.id, host.user.id, 9), data.CalendarUnavailableError);
});

test("a recent cached answer covers a short Google outage, an old one does not", async () => {
  mock.timers.enable({ apis: ["Date"], now: Date.now() });
  try {
    await firstSlots(host.eventType.id, host.user.id, 9); // fills the cache
    mock.timers.tick(2 * 60_000);
    g.state.failFreebusy = 10;
    assert.ok((await firstSlots(host.eventType.id, host.user.id, 9)).slots.length > 0, "stale cache under ten minutes is used");
    mock.timers.tick(10 * 60_000);
    await assert.rejects(() => firstSlots(host.eventType.id, host.user.id, 9), data.CalendarUnavailableError);
  } finally {
    mock.timers.reset();
  }
});

test("a calendar Google cannot read is not treated as empty", async () => {
  g.state.calendarErrors["primary@example.com"] = "notFound";
  await assert.rejects(() => firstSlots(host.eventType.id, host.user.id, 9), data.CalendarUnavailableError);
});

// ---- events on the host's calendar -------------------------------------------------------

const book = async (name: string, days = 12, idx = 0) => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, days);
  return data.createBooking({ eventTypeId: et.id, startAt: slots[idx].start, ...guest(name) });
};

test("a booking creates one event with a Meet link, and the link reaches the guest", async () => {
  const b = await book("Meet", 12, 0);
  await runDueJobs();
  const id = eventIdFor(b.booking.id);
  assert.match(id, /^[0-9a-f]{32}$/);
  const ev = g.state.events.get(id)!;
  assert.equal(ev.calendarId, "primary@example.com");
  assert.equal(ev.body.query && (ev.body.query as Record<string, string>).sendUpdates, "none");
  assert.equal((ev.body.query as Record<string, string>).conferenceDataVersion, "1");
  assert.ok(ev.body.conferenceData, "asks Google for a Meet room");
  assert.equal(ev.body.attendees, undefined, "guests are not added as attendees, so Google sends them nothing of its own");
  assert.equal((ev.body.start as { dateTime: string }).dateTime, b.booking.startAt, "the instant is exact; the zone name is only for display");
  assert.equal((ev.body.end as { dateTime: string }).dateTime, b.booking.endAt);
  const row = await one<{ meeting_url: string; provider_event_id: string; provider_calendar_id: string }>("select meeting_url, provider_event_id, provider_calendar_id from bookings where id = $1", [b.booking.id]);
  assert.deepEqual([row!.provider_event_id, row!.provider_calendar_id], [id, "primary@example.com"]);
  assert.match(row!.meeting_url, /^https:\/\/meet\.example\.com\//);
  const mail = sent.find((e) => e.to === "meet@example.com")!;
  assert.ok(mail.text.includes(row!.meeting_url) && mail.attachments![0] && Buffer.from(mail.attachments![0].content, "base64").toString().includes(row!.meeting_url));
});

test("running the job again does not create a second event, and a duplicate insert is absorbed", async () => {
  const b = await book("Twice", 12, 2);
  await runDueJobs();
  const posts = () => g.requests.filter((r) => r.method === "POST" && r.path.includes("/events")).length;
  const before = posts();
  await query("update jobs set status = 'queued', run_at = now() where kind = 'booking.confirmed'");
  await runDueJobs();
  assert.equal(posts(), before);
  // and if our record of the event were lost, Google's 409 is turned into a lookup instead of an error
  const ctx = (await import("../lib/data/bookings")).getBookingContext;
  const base = (await ctx(b.booking.id))!;
  const again = await ensureCalendarEvent(base);
  assert.equal(again!.providerEventId, eventIdFor(b.booking.id));
});

test("a Meet link that appears a moment later is still picked up", async () => {
  g.state.meetAfterGets = 1;
  const b = await book("Slow", 12, 4);
  await runDueJobs();
  const row = await one<{ meeting_url: string | null }>("select meeting_url from bookings where id = $1", [b.booking.id]);
  assert.match(row!.meeting_url!, /meet\.example\.com/);
});

test("a temporary Google failure delays the email instead of losing it", async () => {
  g.state.failEventInsert = 1;
  const b = await book("Retry", 12, 6);
  const s1 = await runDueJobs();
  assert.equal(s1.failed, 1);
  assert.equal(sent.filter((e) => e.to === "retry@example.com").length, 0, "no email without the calendar event yet");
  await query("update jobs set run_at = now() where payload->>'bookingId' = $1", [b.booking.id]);
  await runDueJobs();
  assert.equal(sent.filter((e) => e.to === "retry@example.com").length, 1);
  assert.ok(g.state.events.has(eventIdFor(b.booking.id)));
});

test("cancelling deletes the event; an event that is already gone is fine", async () => {
  const b = await book("Gone", 13, 0);
  await runDueJobs();
  await data.cancelByToken(b.manageToken, null);
  await runDueJobs();
  assert.deepEqual(g.state.deleted.slice(-1), [eventIdFor(b.booking.id)]);
  const b2 = await book("Gone2", 13, 3);
  await runDueJobs();
  g.state.events.delete(eventIdFor(b2.booking.id));
  await data.cancelByToken(b2.manageToken, null);
  const stats = await runDueJobs();
  assert.equal(stats.failed, 0);
});

test("one guest leaving a group does not delete the host's event", async () => {
  const gt = await data.saveEventType(host.user.id, null, {
    scheduleId: host.schedule.id, kind: "group", name: "Open hours", slug: "open-hours", description: null, colorIndex: 3, durationMin: 60, maxInvitees: 3,
    locationType: "in_person", locationValue: "Studio", bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 60,
    limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: false, priceCents: null, currency: null,
  });
  const { slots } = await firstSlots(gt.id, host.user.id, 20);
  const a = await data.createBooking({ eventTypeId: gt.id, startAt: slots[0].start, ...guest("Ga") });
  await data.createBooking({ eventTypeId: gt.id, startAt: slots[0].start, ...guest("Gb") });
  await runDueJobs();
  assert.ok(g.state.events.has(eventIdFor(a.booking.id)));
  assert.equal(g.state.events.get(eventIdFor(a.booking.id))!.body.location, "Studio");
  await data.cancelByToken(a.manageToken, null);
  await runDueJobs();
  assert.ok(g.state.events.has(eventIdFor(a.booking.id)), "still there for the guest who stayed");
});

// ---- revoked access ------------------------------------------------------------------------

test("revoked access is detected, flagged, and stops bookings that cannot be checked; reconnecting fixes it", async () => {
  g.state.revokedRefreshTokens.add("refresh-1");
  forgetToken(connId);
  clearBusyCache();
  const { et } = await firstSlots(host.eventType.id, host.user.id, 9).catch(() => ({ et: null as never }));
  void et;
  const row = await one<{ status: string }>("select status from calendar_connections where id = $1", [connId]);
  assert.equal(row!.status, "needs_reauth");
  assert.equal((await listConnections(host.user.id))[0].status, "needs_reauth");
  const ev = (await data.getEventType(host.user.id, host.eventType.id))!;
  await assert.rejects(() => data.getSlots(ev, "2030-01-07", "2030-01-08"), data.CalendarUnavailableError);
  g.state.nextRefreshToken = "refresh-2";
  await connect(host.user.id, "refresh-2");
  assert.equal((await listConnections(host.user.id))[0].status, "active");
  clearBusyCache();
  assert.ok((await firstSlots(host.eventType.id, host.user.id, 9)).slots.length > 0);
});

test("an existing booking still gets its email when calendar access is gone", async () => {
  const b = await book("Late", 14, 0);
  g.state.revokedRefreshTokens.add("refresh-2");
  forgetToken(connId);
  await runDueJobs();
  assert.equal(sent.filter((e) => e.to === "late@example.com").length, 1);
  assert.equal(g.state.events.has(eventIdFor(b.booking.id)), false);
  g.state.revokedRefreshTokens.delete("refresh-2");
  await connect(host.user.id, "refresh-2");
});

// ---- disconnecting ----------------------------------------------------------------------------

test("disconnecting hands the token back to Google and removes the rows; account deletion does the same", async () => {
  await disconnect(host.user.id, connId);
  assert.ok(g.state.revoked.includes("refresh-2"));
  assert.equal((await listConnections(host.user.id)).length, 0);
  assert.equal((await one<{ n: string }>("select count(*) as n from calendars"))!.n, "0");
  await assert.rejects(() => disconnect(other.user.id, connId), data.NotFoundError);
  clearBusyCache();
  assert.ok((await firstSlots(host.eventType.id, host.user.id, 9)).slots.length > 0, "with no calendar connected nothing blocks");

  g.state.nextRefreshToken = "refresh-other";
  await connect(other.user.id, "refresh-other");
  await revokeAllConnections(other.user.id);
  assert.ok(g.state.revoked.includes("refresh-other"));
});

test("a 401 on the cached access token causes one refresh and a retry; a revoked grant marks the connection and stops", async () => {
  const id = await connect(host.user.id, "refresh-401");
  clearBusyCache();
  const from = new Date(Date.now() + 9 * 864e5).toISOString(), to = new Date(Date.now() + 10 * 864e5).toISOString();
  const { busyFor } = await import("../lib/calendar/busy");
  await busyFor(host.user.id, from, to, { fresh: true }); // caches an access token
  const tokenCalls = () => g.requests.filter((r) => r.path === "/oauth/token" && r.body.includes("refresh_token")).length;
  const before = tokenCalls();
  const lastBearer = g.requests.filter((r) => r.path === "/calendar/v3/freeBusy").at(-1)!.headers.authorization!.replace("Bearer ", "");
  g.state.rejectToken = lastBearer;                      // that token stops working; a fresh one will
  clearBusyCache();
  await busyFor(host.user.id, from, to, { fresh: true });
  assert.equal(tokenCalls(), before + 1, "exactly one refresh");
  g.state.rejectToken = null;
  // now the person removes the app: every token and the refresh token are refused
  g.state.rejectApiTokens = true;
  g.state.revokedRefreshTokens.add("refresh-401");
  clearBusyCache();
  await assert.rejects(() => busyFor(host.user.id, from, to, { fresh: true }));
  const row = await one<{ status: string }>("select status from calendar_connections where id = $1", [id]);
  assert.equal(row!.status, "needs_reauth", "the host is told right away");
  g.state.rejectApiTokens = false;
  await disconnect(host.user.id, id);
});
