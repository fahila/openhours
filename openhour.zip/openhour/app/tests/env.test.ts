import { test } from "node:test";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { parseEnv } from "../lib/env";
import { sessionCookie } from "../lib/auth/session";

const key = randomBytes(32).toString("base64");
const prod = {
  NODE_ENV: "production", DATABASE_URL: "postgres://x", APP_URL: "https://cal.example.com", APP_ENCRYPTION_KEY: key, CRON_SECRET: "s".repeat(32),
  RESEND_API_KEY: "re_x", EMAIL_FROM: "Cal <hi@cal.example.com>", GOOGLE_CLIENT_ID: "id", GOOGLE_CLIENT_SECRET: "secret", ALLOWED_EMAILS: "Me@Example.com, you@example.com",
};

test("a complete production environment is accepted, and the allow list is lowercased", () => {
  const e = parseEnv(prod);
  assert.equal(e.isProd, true);
  assert.deepEqual(e.allowedEmails, ["me@example.com", "you@example.com"]);
  assert.equal(e.googleEnabled, true);
  assert.equal(e.stripeEnabled, false);
  assert.equal(e.devLoginEnabled, false);
});

test("production refuses to start when a required variable is missing, naming it", () => {
  for (const k of ["DATABASE_URL", "APP_ENCRYPTION_KEY", "CRON_SECRET", "RESEND_API_KEY", "EMAIL_FROM", "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "ALLOWED_EMAILS"]) {
    assert.throws(() => parseEnv({ ...prod, [k]: undefined }), new RegExp(k), k);
  }
});

test("production refuses http, dev login, and mock-server overrides", () => {
  assert.throws(() => parseEnv({ ...prod, APP_URL: "http://cal.example.com" }), /https/);
  assert.throws(() => parseEnv({ ...prod, DEV_LOGIN: "1" }), /DEV_LOGIN/);
  assert.throws(() => parseEnv({ ...prod, GOOGLE_API_BASE: "http://evil.test" }), /overrides/);
  assert.throws(() => parseEnv({ ...prod, STRIPE_API_HOST: "evil.test" }), /overrides/);
});

test("a short or malformed encryption key is rejected", () => {
  assert.throws(() => parseEnv({ ...prod, APP_ENCRYPTION_KEY: Buffer.from("short").toString("base64") }), /32 bytes/);
});

test("development is permissive but dev login needs an explicit switch", () => {
  const dev = { NODE_ENV: "development", DATABASE_URL: "postgres://x" };
  assert.equal(parseEnv(dev).devLoginEnabled, false);
  assert.equal(parseEnv({ ...dev, DEV_LOGIN: "1" }).devLoginEnabled, true);
  assert.deepEqual(parseEnv(dev).allowedEmails, [], "nobody is allowed by default");
});

test("session cookie: httpOnly and Lax always; Secure and the __Host- prefix in production", () => {
  const p = sessionCookie(true, 100);
  assert.deepEqual([p.name, p.options.secure, p.options.httpOnly, p.options.sameSite, p.options.path], ["__Host-session", true, true, "lax", "/"]);
  assert.ok(!("domain" in p.options), "__Host- cookies must not set a Domain");
  const d = sessionCookie(false, 100);
  assert.deepEqual([d.name, d.options.secure, d.options.httpOnly], ["session", false, true]);
});
