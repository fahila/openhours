import { closeAll, firstSlots, guest, makeHost, resetDatabase } from "./setup";
import { after, before, beforeEach, test } from "node:test";
import assert from "node:assert/strict";
import * as data from "../lib/data";
import { one, query } from "../lib/db";
import { resetEnvCache } from "../lib/env";
import { setTransport, type Email } from "../lib/email/transport";
import { runDueJobs } from "../lib/jobs/run";
import { expireUnpaidBooking, startCheckout, stripe } from "../lib/payments/stripe";
import { handleStripeWebhook } from "../lib/payments/webhook";
import { json, startMock } from "./mock";

const SECRET = "whsec_test_secret";
let mockServer: Awaited<ReturnType<typeof startMock>>;
let host: Awaited<ReturnType<typeof makeHost>>;
let paid: Awaited<ReturnType<typeof data.saveEventType>>;
const sent: Email[] = [];
const state = { sessions: new Map<string, { url: string }>(), expired: [] as string[], refunds: [] as string[], failCreate: false, completedSessions: new Set<string>(), n: 0 };

before(async () => {
  await resetDatabase();
  mockServer = await startMock((req, res) => {
    const form = new URLSearchParams(req.body);
    if (req.method === "POST" && req.path === "/v1/checkout/sessions") {
      if (state.failCreate) return json(res, 500, { error: { type: "api_error", message: "stripe is down" } });
      const id = `cs_test_${++state.n}`;
      state.sessions.set(id, { url: `https://checkout.stripe.test/pay/${id}` });
      return json(res, 200, { id, object: "checkout.session", url: `https://checkout.stripe.test/pay/${id}`, payment_status: "unpaid" });
    }
    const exp = req.path.match(/^\/v1\/checkout\/sessions\/([^/]+)\/expire$/);
    if (req.method === "POST" && exp) {
      if (state.completedSessions.has(exp[1])) return json(res, 400, { error: { type: "invalid_request_error", message: "Only open sessions can be expired" } });
      state.expired.push(exp[1]);
      return json(res, 200, { id: exp[1], object: "checkout.session", status: "expired" });
    }
    if (req.method === "POST" && req.path === "/v1/refunds") {
      state.refunds.push(form.get("payment_intent") ?? "");
      return json(res, 200, { id: "re_1", object: "refund", status: "succeeded" });
    }
    json(res, 404, { error: { type: "invalid_request_error", message: `unhandled ${req.method} ${req.path}` } });
  });
  Object.assign(process.env, { STRIPE_SECRET_KEY: "sk_test_abc", STRIPE_WEBHOOK_SECRET: SECRET, STRIPE_API_HOST: "127.0.0.1", STRIPE_API_PORT: String(mockServer.port), STRIPE_API_PROTOCOL: "http" });
  resetEnvCache();
  host = await makeHost("owner@example.com", "Sam Rivera");
  paid = await data.saveEventType(host.user.id, null, {
    scheduleId: host.schedule.id, kind: "one_on_one", name: "Paid consult", slug: "paid", description: null, colorIndex: 2, durationMin: 60, maxInvitees: 1,
    locationType: "zoom", locationValue: null, bufferBeforeMin: 0, bufferAfterMin: 0, minNoticeMin: 0, rollingDays: null, startIncrementMin: 60,
    limitPerDay: null, limitPerWeek: null, limitPerMonth: null, confirmationMessage: null, requirePayment: true, priceCents: 7500, currency: "usd",
  });
  setTransport({ async send(e) { sent.push(e); return { id: "m" + sent.length }; } });
});
beforeEach(() => { sent.length = 0; state.failCreate = false; mockServer.requests.length = 0; });
after(async () => {
  setTransport(null);
  for (const k of ["STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET", "STRIPE_API_HOST", "STRIPE_API_PORT", "STRIPE_API_PROTOCOL"]) delete process.env[k];
  resetEnvCache();
  await mockServer.close();
  await closeAll();
});

let evt = 0;
const event = (type: string, object: Record<string, unknown>) => JSON.stringify({ id: `evt_${++evt}`, object: "event", type, created: Math.floor(Date.now() / 1000), data: { object } });
const sign = (payload: string, at = Math.floor(Date.now() / 1000)) => stripe().webhooks.generateTestHeaderString({ payload, secret: SECRET, timestamp: at });
const deliver = (payload: string) => handleStripeWebhook(payload, sign(payload));

/** A guest books a paid slot and starts checkout. */
async function startPaid(name: string, days = 15, idx = 0) {
  const { slots } = await firstSlots(paid.id, host.user.id, days);
  const b = await data.createBooking({ eventTypeId: paid.id, startAt: slots[idx].start, ...guest(name) });
  const url = await startCheckout({ booking: b.booking, eventType: paid, host: host.user, manageToken: b.manageToken });
  const pay = (await one<{ provider_session_id: string; status: string }>("select provider_session_id, status from payments where booking_id = $1", [b.booking.id]))!;
  return { ...b, url, session: pay.provider_session_id, slot: slots[idx] };
}
const status = async (id: string) => (await data.getBookingById(id))!.status;
const completed = (session: string, intent = "pi_" + session) => event("checkout.session.completed", { id: session, object: "checkout.session", payment_status: "paid", payment_intent: intent });

test("booking a paid event holds the slot as pending and creates a Checkout Session with the right terms", async () => {
  const p = await startPaid("Pat");
  assert.equal(await status(p.booking.id), "pending_payment");
  assert.match(p.url, /^https:\/\/checkout\.stripe\.test\/pay\/cs_test_/);
  const req = mockServer.requests.find((r) => r.path === "/v1/checkout/sessions")!;
  const f = new URLSearchParams(req.body);
  assert.equal(req.headers.authorization, "Bearer sk_test_abc");
  assert.equal(f.get("mode"), "payment");
  assert.equal(f.get("line_items[0][price_data][unit_amount]"), "7500");
  assert.equal(f.get("line_items[0][price_data][currency]"), "usd");
  assert.equal(f.get("client_reference_id"), p.booking.id);
  assert.equal(f.get("metadata[booking_id]"), p.booking.id);
  assert.equal(f.get("customer_email"), "pat@example.com");
  assert.ok(f.get("success_url")!.includes(`/booked/${p.manageToken}`));
  assert.ok(Number(f.get("expires_at")) >= Date.now() / 1000 + 30 * 60, "Stripe needs at least 30 minutes");
  assert.equal(req.headers["idempotency-key"], `checkout:${p.booking.id}`);
  const pay = await one<{ amount_cents: number; currency: string; status: string }>("select amount_cents, currency, status from payments where booking_id = $1", [p.booking.id]);
  assert.deepEqual(pay, { amount_cents: 7500, currency: "usd", status: "pending" });
});

test("the pending slot is held: nobody else can take it, and no confirmation email goes out yet", async () => {
  const p = await startPaid("Quin", 15, 2);
  await assert.rejects(() => data.createBooking({ eventTypeId: paid.id, startAt: p.slot.start, ...guest("Late") }), data.SlotUnavailableError);
  await runDueJobs();
  assert.equal(sent.filter((e) => e.to === "quin@example.com").length, 0);
});

test("a signed 'paid' event confirms the booking and then the confirmation email is sent", async () => {
  const p = await startPaid("Rae", 16, 0);
  const r = await deliver(completed(p.session));
  assert.deepEqual([r.status, r.body], [200, "confirmed"]);
  assert.equal(await status(p.booking.id), "confirmed");
  assert.deepEqual(await one("select status, provider_payment_id from payments where booking_id = $1", [p.booking.id]), { status: "paid", provider_payment_id: "pi_" + p.session });
  await runDueJobs();
  assert.equal(sent.filter((e) => e.to === "rae@example.com" && /^Confirmed/.test(e.subject)).length, 1);
});

test("the same event delivered twice, or two different events for one payment, change nothing the second time", async () => {
  const p = await startPaid("Sid", 16, 2);
  const payload = completed(p.session);
  assert.equal((await deliver(payload)).body, "confirmed");
  assert.equal((await deliver(payload)).body, "duplicate");
  assert.equal((await deliver(completed(p.session))).body, "already confirmed"); // a different event id for the same payment
  const jobs = await one<{ n: string }>("select count(*) as n from jobs where kind = 'booking.confirmed' and payload->>'bookingId' = $1", [p.booking.id]);
  assert.equal(jobs!.n, "1");
  await runDueJobs();
  assert.equal(sent.filter((e) => e.to === "sid@example.com").length, 1);
});

test("a bad, missing, tampered or stale signature is rejected and changes nothing", async () => {
  const p = await startPaid("Tess", 16, 4);
  const payload = completed(p.session);
  assert.equal((await handleStripeWebhook(payload, null)).status, 400);
  assert.equal((await handleStripeWebhook(payload, "t=1,v1=deadbeef")).status, 400);
  assert.equal((await handleStripeWebhook(payload.replace("paid", "paid "), sign(payload))).status, 400, "signature covers the exact body");
  const wrongSecret = stripe().webhooks.generateTestHeaderString({ payload, secret: "whsec_other" });
  assert.equal((await handleStripeWebhook(payload, wrongSecret)).status, 400);
  assert.equal((await handleStripeWebhook(payload, sign(payload, Math.floor(Date.now() / 1000) - 3600))).status, 400, "an hour-old signature is a replay");
  assert.equal(await status(p.booking.id), "pending_payment");
  assert.equal((await one<{ n: string }>("select count(*) as n from inbound_events where event_id = $1", [JSON.parse(payload).id]))!.n, "0", "rejected events are not recorded");
});

test("an unpaid-status or unknown-session event is acknowledged and ignored", async () => {
  const p = await startPaid("Uli", 17, 0);
  assert.equal((await deliver(event("checkout.session.completed", { id: p.session, object: "checkout.session", payment_status: "unpaid" }))).body, "ignored");
  assert.equal(await status(p.booking.id), "pending_payment");
  assert.equal((await deliver(completed("cs_unknown"))).body, "unknown session");
  assert.equal((await deliver(event("customer.created", { id: "cus_1" }))).body, "ignored");
});

test("an expired session releases the slot", async () => {
  const p = await startPaid("Val", 17, 2);
  assert.equal((await deliver(event("checkout.session.expired", { id: p.session, object: "checkout.session" }))).body, "expired");
  assert.equal(await status(p.booking.id), "cancelled");
  assert.equal((await one<{ status: string }>("select status from payments where booking_id = $1", [p.booking.id]))!.status, "failed");
  const again = await data.createBooking({ eventTypeId: paid.id, startAt: p.slot.start, ...guest("Wen") });
  assert.equal(again.booking.status, "pending_payment");
});

test("the hold job frees an unpaid slot and closes the Stripe session; a paid booking is left alone", async () => {
  const p = await startPaid("Xan", 18, 0);
  await expireUnpaidBooking(p.booking.id);
  assert.equal(await status(p.booking.id), "cancelled");
  assert.ok(state.expired.includes(p.session));
  const q = await startPaid("Yul", 18, 2);
  await deliver(completed(q.session));
  await expireUnpaidBooking(q.booking.id);
  assert.equal(await status(q.booking.id), "confirmed");
  assert.ok(!state.expired.includes(q.session));
});

test("the hold job is queued for 35 minutes after booking", async () => {
  const p = await startPaid("Zoe", 18, 4);
  const j = await one<{ run_at: Date }>("select run_at from jobs where kind = 'payment.expire' and payload->>'bookingId' = $1", [p.booking.id]);
  const mins = (j!.run_at.getTime() - Date.now()) / 60_000;
  assert.ok(mins > 34 && mins < 36, String(mins));
});

test("money that arrives after the hold ran out is refunded, and the booking stays cancelled", async () => {
  const p = await startPaid("Abe", 19, 0);
  await expireUnpaidBooking(p.booking.id);
  state.completedSessions.add(p.session);
  const r = await deliver(completed(p.session, "pi_late"));
  assert.equal(r.body, "late payment, refund queued");
  assert.equal(await status(p.booking.id), "cancelled");
  await runDueJobs();
  assert.deepEqual(state.refunds, ["pi_late"]);
  assert.equal((await one<{ status: string }>("select status from payments where booking_id = $1", [p.booking.id]))!.status, "refunded");
  const refundReq = mockServer.requests.find((r) => r.path === "/v1/refunds")!;
  assert.equal(refundReq.headers["idempotency-key"], `refund:${(await one<{ id: string }>("select id from payments where booking_id = $1", [p.booking.id]))!.id}`);
});

test("a refund made in the Stripe dashboard is recorded", async () => {
  const p = await startPaid("Bea", 19, 2);
  await deliver(completed(p.session, "pi_to_refund"));
  assert.equal((await deliver(event("charge.refunded", { id: "ch_1", object: "charge", refunded: true, payment_intent: "pi_to_refund" }))).body, "refund recorded");
  assert.equal((await one<{ status: string }>("select status from payments where booking_id = $1", [p.booking.id]))!.status, "refunded");
});

test("if Stripe is down when starting checkout, the slot can be released at once", async () => {
  state.failCreate = true;
  const { slots } = await firstSlots(paid.id, host.user.id, 20);
  const b = await data.createBooking({ eventTypeId: paid.id, startAt: slots[0].start, ...guest("Cat") });
  await assert.rejects(() => startCheckout({ booking: b.booking, eventType: paid, host: host.user, manageToken: b.manageToken }));
  await data.abandonPendingBooking(b.booking.id, "Payment could not be started");
  assert.equal(await status(b.booking.id), "cancelled");
  const retry = await data.createBooking({ eventTypeId: paid.id, startAt: slots[0].start, ...guest("Cat") });
  assert.equal(retry.booking.status, "pending_payment");
});

test("the guest cancelling an unpaid booking closes the Stripe session", async () => {
  const p = await startPaid("Dan", 20, 3);
  await data.cancelByToken(p.manageToken, null);
  await runDueJobs();
  assert.ok(state.expired.includes(p.session));
});

test("webhooks are refused when no signing secret is configured", async () => {
  const keep = process.env.STRIPE_WEBHOOK_SECRET;
  delete process.env.STRIPE_WEBHOOK_SECRET;
  resetEnvCache();
  assert.equal((await handleStripeWebhook("{}", "t=1,v1=x")).status, 503);
  process.env.STRIPE_WEBHOOK_SECRET = keep;
  resetEnvCache();
});

test("free event types never touch Stripe", async () => {
  const before = mockServer.requests.length;
  const { slots } = await firstSlots(host.eventType.id, host.user.id, 21);
  const b = await data.createBooking({ eventTypeId: host.eventType.id, startAt: slots[0].start, ...guest("Eve") });
  assert.equal(b.booking.status, "confirmed");
  assert.equal(mockServer.requests.length, before);
  assert.equal((await query("select 1 from payments where booking_id = $1", [b.booking.id])).length, 0);
});
