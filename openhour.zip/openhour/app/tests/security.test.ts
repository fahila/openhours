import { closeAll, firstSlots, guest, makeHost, resetDatabase } from "./setup";
import { after, before, test } from "node:test";
import assert from "node:assert/strict";
import * as data from "../lib/data";
import { one, query } from "../lib/db";
import { isAllowedEmail } from "../lib/auth/allow";
import { purgeRateLimits, rateLimited } from "../lib/rate-limit";
import { isRealDate, pickFreeSlug, slugify } from "../lib/validate";
import { bookBody, calendarFlags, cancelBody, schedulePayload, slotsQuery } from "../lib/schemas";

let host: Awaited<ReturnType<typeof makeHost>>;
before(async () => { await resetDatabase(); host = await makeHost("owner@example.com"); });
after(closeAll);

test("rate limit: the attempt after the limit is blocked, other keys are not, and the window expires", async () => {
  for (let i = 0; i < 3; i++) assert.equal(await rateLimited("k:a", 3, 60_000), false, `attempt ${i + 1}`);
  assert.equal(await rateLimited("k:a", 3, 60_000), true, "fourth attempt");
  assert.equal(await rateLimited("k:a", 3, 60_000), true, "hammering stays blocked");
  assert.equal(await rateLimited("k:b", 3, 60_000), false, "a different key is independent");
  await query("update rate_limit_hits set at = now() - interval '2 minutes' where key = 'k:a'");
  assert.equal(await rateLimited("k:a", 3, 60_000), false, "old hits fall out of the window");
});

test("rate limit: concurrent attempts are all counted", async () => {
  const results = await Promise.all(Array.from({ length: 20 }, () => rateLimited("k:burst", 5, 60_000)));
  const n = (await one<{ n: number }>("select count(*)::int as n from rate_limit_hits where key = 'k:burst'"))!.n;
  assert.equal(n, 20);
  assert.ok(results.filter(Boolean).length >= 1, "later attempts are blocked");
});

test("old rate limit rows are purged", async () => {
  await query("insert into rate_limit_hits (key, at) values ('k:old', now() - interval '3 hours')");
  await purgeRateLimits();
  assert.equal((await one<{ n: number }>("select count(*)::int as n from rate_limit_hits where key = 'k:old'"))!.n, 0);
});

test("allow list: case and whitespace do not matter; strangers and the empty list refuse", () => {
  const e = { allowedEmails: ["me@example.com"], devLoginEnabled: false };
  assert.equal(isAllowedEmail(" Me@Example.COM ", e), true);
  assert.equal(isAllowedEmail("you@example.com", e), false);
  assert.equal(isAllowedEmail("me@example.com", { allowedEmails: [], devLoginEnabled: false }), false);
  assert.equal(isAllowedEmail("anyone@example.com", { allowedEmails: [], devLoginEnabled: true }), true);
});

test("malformed ids are 'not found', never a server error", async () => {
  for (const bad of ["not-a-uuid", "1; drop table users", "", "00000000-0000-0000-0000-00000000000"]) {
    assert.equal(await data.getEventType(host.user.id, bad), null);
    assert.equal(await data.getSchedule(host.user.id, bad), null);
    await assert.rejects(() => data.setEventTypeActive(host.user.id, bad, false), data.NotFoundError);
    await assert.rejects(() => data.deleteEventType(host.user.id, bad), data.NotFoundError);
    await assert.rejects(() => data.cancelBookingAsHost(host.user.id, bad, null), data.NotFoundError);
  }
});

test("SQL in a guest's name or email is data, not code", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id);
  const evil = "Robert'); DROP TABLE users;--";
  const b = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, name: evil, email: "bobby@example.com", timeZone: "UTC", answers: { notes: "'; delete from bookings; --" } });
  assert.equal(b.booking.invitees[0].name, evil);
  assert.ok((await one<{ n: number }>("select count(*)::int as n from users"))!.n >= 1);
});

test("request bodies are bounded", () => {
  const ok = { startAt: "2027-01-05T14:00:00.000Z", name: "A", email: "a@example.com", timeZone: "UTC" };
  assert.ok(bookBody.safeParse(ok).success);
  assert.ok(!bookBody.safeParse({ ...ok, name: "x".repeat(201) }).success);
  assert.ok(!bookBody.safeParse({ ...ok, email: "x".repeat(400) }).success);
  assert.ok(!bookBody.safeParse({ ...ok, answers: { n: "x".repeat(2001) } }).success);
  assert.ok(!bookBody.safeParse({ ...ok, answers: Object.fromEntries(Array.from({ length: 21 }, (_, i) => ["k" + i, "v"])) }).success);
  assert.ok(!bookBody.safeParse({ ...ok, startAt: 12345 }).success);
  assert.ok(!bookBody.safeParse(null).success);
  assert.ok(!cancelBody.safeParse({ reason: "x".repeat(501) }).success);
  assert.ok(!slotsQuery.safeParse({ from: "2027-1-5", to: "2027-01-06" }).success);
  assert.ok(!calendarFlags.safeParse({ id: "nope" }).success);
});

test("the schedule payload rejects bad days, times and oversized lists", () => {
  const base = { name: "Work", timeZone: "UTC", rules: [{ dayOfWeek: 1, start: "09:00", end: "17:00" }], overrides: [] };
  assert.ok(schedulePayload.safeParse(base).success);
  assert.ok(!schedulePayload.safeParse({ ...base, rules: [{ dayOfWeek: 7, start: "09:00", end: "17:00" }] }).success);
  assert.ok(!schedulePayload.safeParse({ ...base, rules: [{ dayOfWeek: 1, start: "9am", end: "17:00" }] }).success);
  assert.ok(!schedulePayload.safeParse({ ...base, rules: Array.from({ length: 101 }, () => base.rules[0]) }).success);
  assert.ok(!schedulePayload.safeParse({ ...base, overrides: [{ date: "tomorrow", start: null, end: null }] }).success);
});

test("an ordinary guest email never counts against another guest's limit", async () => {
  assert.equal(await rateLimited("book:email:a@example.com", 5, 3_600_000), false);
  assert.equal(await rateLimited("book:email:b@example.com", 5, 3_600_000), false);
  void guest;
});

test("link names: emoji-only names fall back, clashes get -2, -3, and the length limit holds", () => {
  assert.equal(slugify("☕☕☕"), "");
  assert.equal(pickFreeSlug("", new Set()), "event");
  assert.equal(pickFreeSlug("intro", new Set(["intro"])), "intro-2");
  assert.equal(pickFreeSlug("intro", new Set(["intro", "intro-2"])), "intro-3");
  const long = "a".repeat(59);
  const next = pickFreeSlug(long, new Set([long]));
  assert.ok(next.length <= 59 && next.endsWith("-2"), next);
});

test("dates must exist on the calendar", () => {
  for (const ok of ["2026-02-28", "2028-02-29", "2026-12-31"]) assert.ok(isRealDate(ok), ok);
  for (const bad of ["2026-13-45", "2026-02-29", "2026-00-10", "2026-04-31", "2026-1-5", "tomorrow", ""]) assert.ok(!isRealDate(bad), bad);
  assert.ok(!slotsQuery.safeParse({ from: "2026-13-45", to: "2026-13-46" }).success);
  assert.ok(!schedulePayload.safeParse({ name: "x", timeZone: "UTC", rules: [], overrides: [{ date: "2026-02-30", start: null, end: null }] }).success);
});

test("link names from the address bar never reach the database unless they could be real", async () => {
  for (const bad of ["\u0000", "a\u0000b", "../etc", "UPPER", "a b", "x".repeat(5000), "", "%00", "é"]) {
    assert.equal(await data.getUserBySlug(bad), null, JSON.stringify(bad).slice(0, 30));
    assert.equal(await data.getEventTypeBySlug(host.user.id, bad), null, JSON.stringify(bad).slice(0, 30));
  }
  assert.ok(await data.getUserBySlug(host.user.slug));
});

test("NUL bytes in guest text are stripped instead of crashing the booking", async () => {
  const { et, slots } = await firstSlots(host.eventType.id, host.user.id, 30);
  const b = await data.createBooking({ eventTypeId: et.id, startAt: slots[0].start, name: "Nul\u0000 Guest\r\nBcc: x@y.z", email: "nul@example.com", timeZone: "UTC", answers: { notes: "line1\nline2\u0000", "k\u0000ey": "v" } });
  assert.equal(b.booking.invitees[0].name, "Nul Guest Bcc: x@y.z");
  assert.equal(b.booking.invitees[0].answers.notes, "line1\nline2");
});
