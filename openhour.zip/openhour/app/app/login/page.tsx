import { redirect } from "next/navigation";
import { CalendarCheck } from "lucide-react";
import { GuestShell } from "@/components/booking/shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { getCurrentUser } from "@/lib/auth/session";
import { BRAND } from "@/lib/brand";
import { env } from "@/lib/env";
import { devLoginAction } from "./actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

const MESSAGES: Record<string, string> = {
  not_allowed: "That Google account isn't allowed to sign in here.",
  sign_in_failed: "Sign-in didn't complete. Please try again.",
  not_configured: "Google sign-in isn't set up yet. Add the Google keys to the server settings.",
  deleted: "Your account and its data were deleted.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getCurrentUser()) redirect("/event-types");
  const { error } = await searchParams;
  const e = env();
  const message = error ? MESSAGES[error] : null;
  return (
    <GuestShell>
      <div className="mx-auto max-w-sm rounded-lg border border-border bg-bg p-8 shadow-card">
        <div className="mb-6 flex items-center gap-2 text-lg font-bold"><CalendarCheck aria-hidden className="size-5 text-accent" /> {BRAND.name}</div>
        <h1 className="text-xl">Sign in</h1>
        {message && <p role={error === "deleted" ? "status" : "alert"} className={`mt-4 rounded-md border p-3 text-sm ${error === "deleted" ? "border-success bg-success-subtle text-success" : "border-danger bg-danger-subtle text-danger"}`}>{message}</p>}
        <div className="mt-6 grid gap-4">
          {e.googleEnabled && (
            <a href="/api/auth/google"><Button className="w-full" size="lg">Continue with Google</Button></a>
          )}
          {e.devLoginEnabled && (
            <form action={devLoginAction} className="grid gap-3 rounded-md border border-dashed border-border-input p-3">
              <p className="text-xs font-semibold text-warning">Development only</p>
              <Field label="Email"><Input name="email" type="email" defaultValue="dev@example.com" /></Field>
              <Button type="submit" variant="secondary">Sign in for development</Button>
            </form>
          )}
          {!e.googleEnabled && !e.devLoginEnabled && <p className="text-sm text-text-muted">Sign-in isn't configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, then restart.</p>}
        </div>
      </div>
    </GuestShell>
  );
}
