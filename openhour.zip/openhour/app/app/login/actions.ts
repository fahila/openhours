"use server";

import { redirect } from "next/navigation";
import { startSession } from "@/lib/auth/session";
import { createUserWithDefaults, getUserByEmail } from "@/lib/data";
import { env } from "@/lib/env";
import { EMAIL_RE } from "@/lib/validate";

/** Local development only. Refuses to run unless DEV_LOGIN is on and NODE_ENV is not production. */
export async function devLoginAction(formData: FormData) {
  if (!env().devLoginEnabled) throw new Error("Not available");
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(email)) redirect("/login?error=sign_in_failed");
  const user = (await getUserByEmail(email)) ?? (await createUserWithDefaults({ email, name: email.split("@")[0] }));
  await startSession(user.id);
  redirect("/event-types");
}
