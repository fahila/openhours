import { GuestShell } from "@/components/booking/shell";

export const metadata = { title: "You've left this meeting" };

export default function LeftPage() {
  return (
    <GuestShell>
      <div className="mx-auto max-w-md rounded-lg border border-border bg-bg p-8 text-center shadow-card">
        <h1 className="text-xl">You've left this meeting</h1>
        <p className="mt-2 text-sm text-text-muted">The host has been told. The meeting still goes ahead for the other guests, and your link no longer works.</p>
      </div>
    </GuestShell>
  );
}
