import { NextResponse, after } from "next/server";
import { handleStripeWebhook } from "@/lib/payments/webhook";
import { runDueJobs } from "@/lib/jobs/run";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const raw = await req.text(); // the signature covers the exact bytes, so read the body as text and never re-serialise it
  try {
    const r = await handleStripeWebhook(raw, req.headers.get("stripe-signature"));
    if (r.status === 200) after(() => runDueJobs().catch(() => {}));
    return new NextResponse(r.body, { status: r.status });
  } catch (e) {
    console.error(JSON.stringify({ level: "error", msg: "stripe webhook failed", error: e instanceof Error ? e.message : String(e) }));
    return new NextResponse("Processing failed", { status: 500 }); // Stripe retries on 5xx
  }
}
