import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { exchangeCode, fetchProfile, readPending, redirectUri } from "@/lib/auth/google";
import { isAllowedEmail } from "@/lib/auth/allow";
import { startSession } from "@/lib/auth/session";
import { createUserWithDefaults, findUserByGoogleSub, getUserByEmail, linkGoogleIdentity } from "@/lib/data";
import { env } from "@/lib/env";
import { clientKey, rateLimited } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const back = (error: string) => NextResponse.redirect(new URL(`/login?error=${error}`, env().APP_URL));

export async function GET(req: Request) {
  if (await rateLimited(`auth:${clientKey(req)}`, 20, 60_000)) return new NextResponse("Too many attempts. Wait a minute.", { status: 429 });
  const url = new URL(req.url);
  const jar = await cookies();
  const pending = readPending(jar.get("oauth_pending")?.value, url.searchParams.get("state"), "login");
  jar.delete("oauth_pending");
  const code = url.searchParams.get("code");
  if (url.searchParams.get("error") || !pending || !code) return back("sign_in_failed");

  let profile;
  try {
    const tokens = await exchangeCode(code, pending.verifier, redirectUri("/api/auth/google/callback"));
    profile = await fetchProfile(tokens.access_token);
  } catch {
    return back("sign_in_failed");
  }
  const email = profile.email?.toLowerCase();
  // Only people on the allow list can sign in, and only with an address Google has verified.
  if (!email || !profile.email_verified || !isAllowedEmail(email)) return back("not_allowed");

  let user = await findUserByGoogleSub(profile.sub);
  if (!user) {
    const existing = await getUserByEmail(email);
    if (existing) {
      await linkGoogleIdentity(existing.id, profile.sub);
      user = existing;
    } else {
      user = await createUserWithDefaults({ email, name: profile.name ?? email.split("@")[0], googleSub: profile.sub });
    }
  }
  await startSession(user.id);
  return NextResponse.redirect(new URL("/event-types", env().APP_URL));
}
