import { NextResponse } from "next/server";
import { LOGIN_SCOPES, authUrl, newPending, redirectUri } from "@/lib/auth/google";
import { env } from "@/lib/env";
import { clientKey, rateLimited } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  if (!env().googleEnabled) return NextResponse.redirect(new URL("/login?error=not_configured", env().APP_URL));
  if (await rateLimited(`auth:${clientKey(req)}`, 20, 60_000)) return new NextResponse("Too many attempts. Wait a minute.", { status: 429 });
  const { pending, cookie, challenge } = newPending("login");
  const res = NextResponse.redirect(authUrl({ scopes: LOGIN_SCOPES, redirect: redirectUri("/api/auth/google/callback"), state: pending.state, challenge }));
  res.cookies.set("oauth_pending", cookie, { httpOnly: true, secure: env().isProd, sameSite: "lax", path: "/api", maxAge: 600 });
  return res;
}
