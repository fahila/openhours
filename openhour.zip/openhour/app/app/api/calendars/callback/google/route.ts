import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { exchangeCode, fetchProfile, readPending, redirectUri } from "@/lib/auth/google";
import { getCurrentUser } from "@/lib/auth/session";
import { REQUIRED_SCOPES, saveGoogleConnection } from "@/lib/calendar/connections";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

const to = (code: string) => NextResponse.redirect(new URL(`/integrations?calendar=${code}`, env().APP_URL));

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.redirect(new URL("/login", env().APP_URL));
  const url = new URL(req.url);
  const jar = await cookies();
  const pending = readPending(jar.get("oauth_pending")?.value, url.searchParams.get("state"), "calendar");
  jar.delete("oauth_pending");
  const code = url.searchParams.get("code");
  // the connection is for whoever started it, and only them
  if (url.searchParams.get("error") || !pending || pending.userId !== user.id || !code) return to("failed");
  try {
    const tokens = await exchangeCode(code, pending.verifier, redirectUri("/api/calendars/callback/google"));
    const granted = (tokens.scope ?? "").split(" ");
    // Google lets people untick individual permissions on the consent screen
    if (!REQUIRED_SCOPES.every((s) => granted.includes(s))) return to("missing_scopes");
    if (!tokens.refresh_token) return to("failed");
    const profile = await fetchProfile(tokens.access_token);
    await saveGoogleConnection(user.id, { sub: profile.sub, email: profile.email, refreshToken: tokens.refresh_token, scopes: granted });
    return to("connected");
  } catch {
    return to("failed");
  }
}
