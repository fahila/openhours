import { NextResponse } from "next/server";
import { CALENDAR_SCOPES, authUrl, newPending, redirectUri } from "@/lib/auth/google";
import { getCurrentUser } from "@/lib/auth/session";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.redirect(new URL("/login", env().APP_URL));
  if (!env().googleEnabled) return NextResponse.redirect(new URL("/integrations?calendar=not_configured", env().APP_URL));
  const { pending, cookie, challenge } = newPending("calendar", user.id);
  const res = NextResponse.redirect(authUrl({
    scopes: ["openid", "email", ...CALENDAR_SCOPES],
    redirect: redirectUri("/api/calendars/callback/google"),
    state: pending.state, challenge, offline: true, loginHint: user.email,
  }));
  res.cookies.set("oauth_pending", cookie, { httpOnly: true, secure: env().isProd, sameSite: "lax", path: "/api", maxAge: 600 });
  return res;
}
