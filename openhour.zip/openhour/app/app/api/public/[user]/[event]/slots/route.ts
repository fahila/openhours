import { NextResponse } from "next/server";
import { DateTime } from "luxon";
import { CalendarUnavailableError, findByManageToken, getEventTypeBySlug, getSlots, getUserBySlug } from "@/lib/data";
import { slotsQuery } from "@/lib/schemas";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ user: string; event: string }> }) {
  const { user: userSlug, event: eventSlug } = await ctx.params;
  const url = new URL(req.url);
  const q = slotsQuery.safeParse({ from: url.searchParams.get("from"), to: url.searchParams.get("to"), reschedule: url.searchParams.get("reschedule") });
  if (!q.success || DateTime.fromISO(q.data.from) > DateTime.fromISO(q.data.to)) return NextResponse.json({ error: "bad_range" }, { status: 400 });
  const { from, to } = q.data;
  if (DateTime.fromISO(to).diff(DateTime.fromISO(from), "days").days > 62) return NextResponse.json({ error: "range_too_long" }, { status: 400 });

  const host = await getUserBySlug(userSlug);
  const et = host && (await getEventTypeBySlug(host.id, eventSlug));
  if (!host || !et) return NextResponse.json({ error: "not_found" }, { status: 404 });

  let ignore: string | undefined;
  const reschedule = q.data.reschedule;
  if (reschedule) {
    const m = await findByManageToken(reschedule);
    if (m && m.eventType.id === et.id) ignore = m.booking.id;
  }
  let slots;
  try {
    slots = await getSlots(et, from, to, ignore);
  } catch (e) {
    if (e instanceof CalendarUnavailableError) return NextResponse.json({ error: "calendar_unavailable" }, { status: 503 });
    throw e;
  }
  return NextResponse.json(
    { slots: slots.map((s) => ({ start: s.start, remaining: s.remaining })), hostTimeZone: host.timeZone },
    { headers: { "Cache-Control": "no-store" } },
  );
}
