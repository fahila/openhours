import { NextResponse, after } from "next/server";
import { abandonPendingBooking, createBooking, getEventTypeBySlug, getUserBySlug, CalendarUnavailableError, SlotUnavailableError, ValidationError } from "@/lib/data";
import { env } from "@/lib/env";
import { runDueJobs } from "@/lib/jobs/run";
import { startCheckout } from "@/lib/payments/stripe";
import { clientKey, rateLimited } from "@/lib/rate-limit";
import { bookBody, fieldErrors } from "@/lib/schemas";

const tooMany = (message: string) => NextResponse.json({ error: "rate_limited", message }, { status: 429 });

export async function POST(req: Request, ctx: { params: Promise<{ user: string; event: string }> }) {
  if (await rateLimited(`book:ip:${clientKey(req)}`, 10, 60_000)) return tooMany("Too many attempts. Wait a minute and try again.");
  const { user: userSlug, event: eventSlug } = await ctx.params;
  const host = await getUserBySlug(userSlug);
  const et = host && (await getEventTypeBySlug(host.id, eventSlug));
  if (!host || !et) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (et.requirePayment && !env().stripeEnabled) {
    return NextResponse.json({ error: "payments_unavailable", message: "Payments are not available right now. Please try again later." }, { status: 503 });
  }

  const parsed = bookBody.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "invalid", errors: fieldErrors(parsed.error) }, { status: 422 });
  const body = parsed.data;

  // Every booking sends an email to a stranger-supplied address, and fills the host's calendar. Cap both.
  const email = body.email.trim().toLowerCase();
  if (await rateLimited(`book:email:${email}`, 5, 3_600_000)) return tooMany("That email address has made several bookings recently. Please try again later.");
  if (await rateLimited(`book:host:${host.id}`, 60, 3_600_000)) return tooMany("This page is getting a lot of bookings right now. Please try again in a little while.");

  try {
    const { booking, manageToken } = await createBooking({ eventTypeId: et.id, startAt: body.startAt, name: body.name, email, timeZone: body.timeZone, answers: body.answers });
    if (booking.status === "pending_payment") {
      try {
        const checkoutUrl = await startCheckout({ booking, eventType: et, host, manageToken });
        return NextResponse.json({ manageToken, checkoutUrl }, { status: 201 });
      } catch (e) {
        await abandonPendingBooking(booking.id, "Payment could not be started");
        console.error(JSON.stringify({ level: "error", msg: "checkout start failed", bookingId: booking.id, error: e instanceof Error ? e.message : String(e) }));
        return NextResponse.json({ error: "payment_failed_to_start", message: "We couldn't start the payment. Nothing was charged. Please try again." }, { status: 502 });
      }
    }
    after(() => runDueJobs().catch(() => {}));
    return NextResponse.json({ manageToken }, { status: 201 });
  } catch (e) {
    if (e instanceof SlotUnavailableError) return NextResponse.json({ error: "slot_taken", message: e.message }, { status: 409 });
    if (e instanceof CalendarUnavailableError) return NextResponse.json({ error: "calendar_unavailable", message: e.message }, { status: 503 });
    if (e instanceof ValidationError) return NextResponse.json({ error: "invalid", errors: e.errors }, { status: 422 });
    throw e;
  }
}
