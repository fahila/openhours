import { NextResponse } from "next/server";
import { safeEqual } from "@/lib/crypto";
import { env } from "@/lib/env";
import { runDueJobs } from "@/lib/jobs/run";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Called on a schedule (Vercel Cron, a systemd timer, anything that can send a header). Requires the CRON_SECRET. */
async function handle(req: Request) {
  const secret = env().CRON_SECRET;
  const given = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!secret || !safeEqual(given, secret)) return new NextResponse("Unauthorized", { status: 401 });
  return NextResponse.json(await runDueJobs());
}

export const GET = handle;
export const POST = handle;
