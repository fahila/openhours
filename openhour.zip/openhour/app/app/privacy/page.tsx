import { GuestShell } from "@/components/booking/shell";
import { env } from "@/lib/env";

export const metadata = { title: "How your details are used" };
export const dynamic = "force-dynamic";

export default function PrivacyPage() {
  const e = env();
  return (
    <GuestShell>
      <article className="mx-auto max-w-2xl rounded-lg border border-border bg-bg p-6 shadow-card md:p-8">
        <h1 className="text-xl">How your details are used</h1>
        <div className="mt-4 grid gap-4 text-sm leading-6">
          <p>When you book a time, you give your name, your email address, your time zone and, if you choose to, a note. They are used to arrange that one meeting: to show it to the person you are meeting, put it on their calendar, and send you a confirmation, any reminder and a link to change or cancel.</p>
          <section><h2 className="text-lg">Who handles them</h2>
            <ul className="mt-2 list-disc pl-5">
              <li>The person you are booking with, who sees everything you enter.</li>
              <li>The hosting and database providers that run this site.</li>
              <li>An email service, to send you messages about the meeting.</li>
              <li>Google Calendar, where the meeting is added to the host's calendar (your name, email and note are in the event).</li>
              {e.stripeEnabled && <li>Stripe, if the meeting is paid. Card details go straight to Stripe and never reach this site.</li>}
            </ul>
          </section>
          <section><h2 className="text-lg">What is not done</h2>
            <p className="mt-2">Your details are not sold, used for advertising, or shared with anyone beyond the list above. This site sets no tracking cookies and has no analytics.</p>
          </section>
          <section><h2 className="text-lg">Changing or removing them</h2>
            <p className="mt-2">You can cancel or move the meeting at any time from the link in your confirmation email. To have your details removed afterwards, ask the person you booked with.</p>
          </section>
        </div>
      </article>
    </GuestShell>
  );
}
