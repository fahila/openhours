import { notFound, redirect } from "next/navigation";
import { BookingFlow } from "@/components/booking/booking-flow";
import { GuestShell } from "@/components/booking/shell";
import { findByManageToken } from "@/lib/data";
import { LOCATION_LABELS } from "@/lib/types";

export const dynamic = "force-dynamic";

const priceLabel = (cents: number | null, currency: string | null) =>
  cents != null && currency ? `${new Intl.NumberFormat("en", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100)} to book` : null;

export const metadata = { title: "Pick a new time" };

export default async function ReschedulePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const m = await findByManageToken(token);
  if (!m) notFound();
  if (m.booking.status !== "confirmed" || Date.parse(m.booking.startAt) < Date.now()) redirect(`/m/${token}`);
  const { eventType: et, host } = m;
  return (
    <GuestShell>
      <BookingFlow
        host={{ name: host.name, slug: host.slug, timeZone: host.timeZone }}
        event={{ slug: et.slug, name: et.name, durationMin: et.durationMin, description: et.description, kind: et.kind, colorIndex: et.colorIndex, priceLabel: et.requirePayment ? priceLabel(et.priceCents, et.currency) : null, locationLabel: et.locationValue ?? LOCATION_LABELS[et.locationType] }}
        nowIso={new Date().toISOString()}
        mode={{ type: "reschedule", token, guestName: m.invitee.name, currentStart: m.booking.startAt }}
      />
    </GuestShell>
  );
}
