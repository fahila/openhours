import { NextResponse, after } from "next/server";
import { CalendarUnavailableError, NotFoundError, rescheduleByToken, SlotUnavailableError, ValidationError } from "@/lib/data";
import { runDueJobs } from "@/lib/jobs/run";
import { clientKey, rateLimited } from "@/lib/rate-limit";
import { fieldErrors, rescheduleBody } from "@/lib/schemas";

export async function POST(req: Request, ctx: { params: Promise<{ token: string }> }) {
  if (await rateLimited(`manage:ip:${clientKey(req)}`, 20, 60_000)) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const { token } = await ctx.params;
  const parsed = rescheduleBody.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "invalid", errors: fieldErrors(parsed.error) }, { status: 422 });
  try {
    const { manageToken } = await rescheduleByToken(token, parsed.data.startAt);
    after(() => runDueJobs().catch(() => {}));
    return NextResponse.json({ manageToken });
  } catch (e) {
    if (e instanceof NotFoundError) return NextResponse.json({ error: "not_found" }, { status: 404 });
    if (e instanceof SlotUnavailableError) return NextResponse.json({ error: "slot_taken", message: e.message }, { status: 409 });
    if (e instanceof CalendarUnavailableError) return NextResponse.json({ error: "calendar_unavailable", message: e.message }, { status: 503 });
    if (e instanceof ValidationError) return NextResponse.json({ error: "invalid", errors: e.errors }, { status: 422 });
    throw e;
  }
}
