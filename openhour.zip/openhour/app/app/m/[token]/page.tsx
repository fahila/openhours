import Link from "next/link";
import { notFound } from "next/navigation";
import { BookingSummary } from "@/components/booking/summary";
import { CancelMyMeeting } from "@/components/booking/manage-actions";
import { GuestShell } from "@/components/booking/shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { findByManageToken } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your meeting" };

export default async function ManagePage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const m = await findByManageToken(token);
  if (!m) notFound();
  const cancelled = m.booking.status === "cancelled";
  const past = !cancelled && Date.parse(m.booking.startAt) < Date.now();
  return (
    <GuestShell>
      <div className="mx-auto max-w-lg rounded-lg border border-border bg-bg p-6 shadow-card md:p-8">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h1 className="text-xl">Your meeting</h1>
          {cancelled ? <Badge tone="danger">Cancelled</Badge> : past ? <Badge>Finished</Badge> : <Badge tone="success">Confirmed</Badge>}
        </div>
        <div className="mt-6 border-t border-border pt-6"><BookingSummary m={m} /></div>
        {cancelled && m.booking.cancelReason && <p className="mt-4 break-words text-sm text-text-muted">Reason: {m.booking.cancelReason}</p>}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          {!cancelled && !past && (
            <>
              <Link href={`/reschedule/${token}`}><Button>Pick another time</Button></Link>
              <CancelMyMeeting token={token} />
            </>
          )}
          {(cancelled || past) && (
            <Link href={`/${m.host.slug}/${m.eventType.slug}`}><Button>Book a new time</Button></Link>
          )}
        </div>
      </div>
    </GuestShell>
  );
}
