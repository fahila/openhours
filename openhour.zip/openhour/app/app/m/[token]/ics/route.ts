import { BRAND } from "@/lib/brand";
import { calendarIdentity, findByManageToken } from "@/lib/data";
import { LOCATION_LABELS } from "@/lib/types";

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\;").replace(/,/g, "\\,").replace(/\r?\n/g, "\\n");
const stamp = (iso: string) => new Date(iso).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");

export async function GET(_req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const m = await findByManageToken(token);
  if (!m || m.booking.status !== "confirmed") return new Response("Not found", { status: 404 });
  const where = m.eventType.locationValue || LOCATION_LABELS[m.eventType.locationType];
  const cal = await calendarIdentity(m.booking.id);
  const lines = [
    "BEGIN:VCALENDAR", "VERSION:2.0", `PRODID:-//${BRAND.name}//EN`, "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${cal.uid}@${BRAND.icsDomain}`,
    `SEQUENCE:${cal.sequence}`,
    `DTSTAMP:${stamp(m.booking.createdAt)}`,
    `DTSTART:${stamp(m.booking.startAt)}`,
    `DTEND:${stamp(m.booking.endAt)}`,
    `SUMMARY:${esc(`${m.eventType.name} with ${m.host.name}`)}`,
    `LOCATION:${esc(where)}`,
    "END:VEVENT", "END:VCALENDAR",
  ];
  return new Response(lines.join("\r\n") + "\r\n", {
    headers: { "Content-Type": "text/calendar; charset=utf-8", "Content-Disposition": 'attachment; filename="meeting.ics"', "Cache-Control": "no-store" },
  });
}
