import { NextResponse, after } from "next/server";
import { cancelByToken, NotFoundError, ValidationError } from "@/lib/data";
import { runDueJobs } from "@/lib/jobs/run";
import { clientKey, rateLimited } from "@/lib/rate-limit";
import { cancelBody, fieldErrors } from "@/lib/schemas";

export async function POST(req: Request, ctx: { params: Promise<{ token: string }> }) {
  if (await rateLimited(`manage:ip:${clientKey(req)}`, 20, 60_000)) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const { token } = await ctx.params;
  const parsed = cancelBody.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: "invalid", errors: fieldErrors(parsed.error) }, { status: 422 });
  try {
    const outcome = await cancelByToken(token, parsed.data.reason ?? null);
    after(() => runDueJobs().catch(() => {}));
    return NextResponse.json({ ok: true, left: outcome === "left" });
  } catch (e) {
    if (e instanceof NotFoundError) return NextResponse.json({ error: "not_found" }, { status: 404 });
    if (e instanceof ValidationError) return NextResponse.json({ error: "invalid", errors: e.errors }, { status: 422 });
    throw e;
  }
}
