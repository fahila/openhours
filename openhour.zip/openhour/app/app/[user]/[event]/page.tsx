import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { BookingFlow } from "@/components/booking/booking-flow";
import { GuestShell } from "@/components/booking/shell";
import { getEventTypeBySlug, getUserBySlug, releaseUnpaidByToken } from "@/lib/data";
import { LOCATION_LABELS } from "@/lib/types";

export const dynamic = "force-dynamic";

const priceLabel = (cents: number | null, currency: string | null) =>
  cents != null && currency ? `${new Intl.NumberFormat("en", { style: "currency", currency: currency.toUpperCase() }).format(cents / 100)} to book` : null;


async function load(userSlug: string, eventSlug: string) {
  const host = await getUserBySlug(userSlug);
  const et = host && (await getEventTypeBySlug(host.id, eventSlug));
  return host && et ? { host, et } : null;
}

export async function generateMetadata({ params }: { params: Promise<{ user: string; event: string }> }): Promise<Metadata> {
  const p = await params;
  const found = await load(p.user, p.event);
  return { title: found ? `${found.et.name} with ${found.host.name}` : "Not found" };
}

export default async function BookingPage({ params, searchParams }: { params: Promise<{ user: string; event: string }>; searchParams: Promise<{ payment?: string; m?: string }> }) {
  const p = await params;
  const q = await searchParams;
  const found = await load(p.user, p.event);
  if (!found) notFound();
  const { host, et } = found;
  // coming back from Stripe without paying: release the unpaid hold and say so
  const backedOut = q.payment === "cancelled" && typeof q.m === "string" ? await releaseUnpaidByToken(q.m) : false;
  return (
    <GuestShell>
      <BookingFlow
        host={{ name: host.name, slug: host.slug, timeZone: host.timeZone }}
        event={{
          slug: et.slug, name: et.name, durationMin: et.durationMin, description: et.description, kind: et.kind, colorIndex: et.colorIndex, priceLabel: et.requirePayment ? priceLabel(et.priceCents, et.currency) : null,
          locationLabel: et.locationValue && et.locationType !== "google_meet" && et.locationType !== "zoom" ? et.locationValue : LOCATION_LABELS[et.locationType],
        }}
        nowIso={new Date().toISOString()}
        mode={{ type: "book" }}
        notice={backedOut || q.payment === "cancelled" ? "Payment cancelled. You haven't been charged, and the time is free again." : null}
      />
    </GuestShell>
  );
}
