import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Clock, MapPin } from "lucide-react";
import { GuestShell } from "@/components/booking/shell";
import { EmptyState } from "@/components/ui/empty-state";
import { getUserBySlug, listPublicEventTypes } from "@/lib/data";
import { LOCATION_LABELS } from "@/lib/types";
import { cn } from "@/lib/cn";

export const dynamic = "force-dynamic";

const bar: Record<number, string> = { 1: "border-t-event-1", 2: "border-t-event-2", 3: "border-t-event-3", 4: "border-t-event-4", 5: "border-t-event-5", 6: "border-t-event-6", 7: "border-t-event-7", 8: "border-t-event-8" };

export async function generateMetadata({ params }: { params: Promise<{ user: string }> }): Promise<Metadata> {
  const host = await getUserBySlug((await params).user);
  return { title: host ? `Book time with ${host.name}` : "Not found" };
}

export default async function HostProfile({ params }: { params: Promise<{ user: string }> }) {
  const { user } = await params;
  const host = await getUserBySlug(user);
  if (!host) notFound();
  const types = await listPublicEventTypes(host.id);
  return (
    <GuestShell>
      <header className="mb-8 text-center">
        <h1 className="break-words text-xl">{host.name}</h1>
        {host.welcomeMessage && <p className="mx-auto mt-2 max-w-md break-words text-text-muted">{host.welcomeMessage}</p>}
      </header>
      {types.length === 0 ? (
        <EmptyState title="Nothing to book right now" body={`${host.name} has no open event types. Check back later.`} />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2">
          {types.map((t) => (
            <li key={t.id}>
              <Link
                href={`/${host.slug}/${t.slug}`}
                className={cn("block h-full rounded-lg border border-border border-t-4 bg-bg p-5 shadow-card hover:bg-accent-subtle", bar[t.colorIndex])}
              >
                <h2 className="break-words text-lg">{t.name}</h2>
                <p className="mt-2 flex items-center gap-1 text-sm text-text-muted"><Clock aria-hidden className="size-4" /> {t.durationMin} min</p>
                <p className="mt-1 flex items-start gap-1 break-words text-sm text-text-muted"><MapPin aria-hidden className="mt-0.5 size-4 shrink-0" /> {t.locationType === "in_person" && t.locationValue ? t.locationValue : LOCATION_LABELS[t.locationType]}</p>
                {t.description && <p className="mt-3 line-clamp-3 break-words text-sm text-text-muted">{t.description}</p>}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </GuestShell>
  );
}
