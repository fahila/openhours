import Link from "next/link";
import { GuestShell } from "@/components/booking/shell";

export default function NotFound() {
  return (
    <GuestShell>
      <div className="mx-auto max-w-md rounded-lg border border-border bg-bg p-8 text-center shadow-card">
        <h1 className="text-xl">We can't find that page</h1>
        <p className="mt-2 text-sm text-text-muted">The link may be mistyped, turned off, or for a meeting that no longer exists.</p>
        <Link href="/" className="mt-4 inline-block text-sm font-semibold text-accent underline">Go to the start</Link>
      </div>
    </GuestShell>
  );
}
