import Link from "next/link";
import { notFound } from "next/navigation";
import { CircleCheck, Download } from "lucide-react";
import { BookingSummary } from "@/components/booking/summary";
import { CancelMyMeeting } from "@/components/booking/manage-actions";
import { GuestShell } from "@/components/booking/shell";
import { Button } from "@/components/ui/button";
import { PaymentWait } from "@/components/booking/payment-wait";
import { findByManageToken } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata = { title: "You're booked" };

export default async function BookedPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const m = await findByManageToken(token);
  if (!m) notFound();
  const cancelled = m.booking.status === "cancelled";
  if (m.booking.status === "pending_payment") {
    return (
      <GuestShell>
        <div className="mx-auto max-w-lg rounded-lg border border-border bg-bg p-6 shadow-card md:p-8">
          <PaymentWait />
          <div className="mt-6 border-t border-border pt-6"><BookingSummary m={m} /></div>
        </div>
      </GuestShell>
    );
  }
  return (
    <GuestShell>
      <div className="mx-auto max-w-lg rounded-lg border border-border bg-bg p-6 shadow-card md:p-8">
        <div className="flex items-center gap-2 text-success">
          <CircleCheck aria-hidden className="size-6" />
          <h1 className="text-xl text-text">{cancelled ? "This meeting was cancelled" : "You're booked"}</h1>
        </div>
        {!cancelled && <p className="mt-2 text-sm text-text-muted">A calendar invite is on its way to {m.invitee.email}. Keep this page to change your plans.</p>}
        {!cancelled && m.eventType.confirmationMessage && (
          <p className="mt-4 whitespace-pre-line break-words rounded-md bg-surface p-3 text-sm">{m.eventType.confirmationMessage}</p>
        )}
        <div className="mt-6 border-t border-border pt-6"><BookingSummary m={m} /></div>
        {!cancelled && (
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <a href={`/m/${token}/ics`} download><Button variant="secondary"><Download aria-hidden className="size-4" /> Add to calendar</Button></a>
            <Link href={`/reschedule/${token}`}><Button variant="secondary">Pick another time</Button></Link>
            <CancelMyMeeting token={token} />
          </div>
        )}
      </div>
    </GuestShell>
  );
}
