"use client";

import { useState } from "react";
import { Copy, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, FieldRow, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState } from "@/components/ui/empty-state";
import { EventTypeCard } from "@/components/ui/event-type-card";
import { MonthCalendar } from "@/components/ui/month-calendar";
import { SlotList, type Slot } from "@/components/ui/slot-list";
import { TimezoneSelect } from "@/components/ui/timezone-select";

const TODAY = "2026-11-02";
const AVAILABLE = new Set(["2026-11-03", "2026-11-04", "2026-11-05", "2026-11-06", "2026-11-09", "2026-11-10", "2026-11-12", "2026-11-13", "2026-11-16", "2026-11-17"]);
const SLOTS: Slot[] = [
  { start: "2026-11-04T14:00:00Z" },
  { start: "2026-11-04T14:30:00Z", taken: true },
  { start: "2026-11-04T15:00:00Z" },
  { start: "2026-11-04T16:30:00Z" },
];

const sectionCls = "grid gap-4 border-t border-border py-8 md:grid-cols-[200px_1fr]";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className={sectionCls}>
      <h2 className="text-lg">{title}</h2>
      <div className="min-w-0">{children}</div>
    </section>
  );
}

export function Showcase() {
  const [month, setMonth] = useState("2026-11-01");
  const [day, setDay] = useState<string | null>("2026-11-04");
  const [slot, setSlot] = useState<string | null>("2026-11-04T15:00:00Z");
  const [tz, setTz] = useState("America/New_York");
  const [h12, setH12] = useState(true);
  const [on, setOn] = useState(true);

  return (
    <main className="mx-auto max-w-[1120px] px-4 py-10">
      <h1 className="text-display">Design system</h1>
      <p className="mt-2 max-w-xl text-text-muted">Primitives for the scheduling app. Values come from tokens.json; swap them in replica-brand.</p>

      <Section title="Button">
        <div className="flex flex-wrap items-center gap-3">
          <Button>Primary</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="danger">Cancel meeting</Button>
          <Button disabled>Disabled</Button>
          <Button loading>Saving</Button>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <Button size="sm">Small</Button>
          <Button size="md">Medium</Button>
          <Button size="lg">Large</Button>
        </div>
      </Section>

      <Section title="Form fields">
        <div className="grid max-w-xl gap-4">
          <FieldRow>
            <Field label="Name" required><Input placeholder="Ada Lovelace" /></Field>
            <Field label="Email" required error="Enter a valid email address."><Input type="email" defaultValue="ada@" /></Field>
          </FieldRow>
          <Field label="Event location" hint="Shown to guests in the confirmation."><Select defaultValue="meet"><option value="meet">Google Meet</option><option value="zoom">Zoom</option><option value="phone">Phone call</option></Select></Field>
          <Field label="Anything to share before we meet?"><Textarea /></Field>
          <Field label="Disabled field"><Input disabled defaultValue="Can't edit this" /></Field>
        </div>
      </Section>

      <Section title="Badge and switch">
        <div className="flex flex-wrap items-center gap-3">
          <Badge>Neutral</Badge><Badge tone="accent">Viewed</Badge><Badge tone="success">Confirmed</Badge><Badge tone="warning">Pending payment</Badge><Badge tone="danger">Cancelled</Badge>
        </div>
        <label className="mt-4 flex items-center gap-3 text-sm font-semibold">
          <Switch label="Event type active" checked={on} onCheckedChange={setOn} /> Event type active
        </label>
      </Section>

      <Section title="Event type card">
        <div className="grid gap-4 sm:grid-cols-2">
          <EventTypeCard name="30 minute intro" durationMin={30} location="Google Meet" colorIndex={1} kind="one_on_one" active
            actions={<><Button size="sm" variant="secondary"><Copy aria-hidden className="size-4" /> Copy link</Button><Button size="sm" variant="ghost"><Pencil aria-hidden className="size-4" /> Edit</Button></>} />
          <EventTypeCard name="Office hours" durationMin={60} location="In person" colorIndex={3} kind="group" active={false} />
        </div>
      </Section>

      <Section title="Booking widget">
        <div className="grid gap-6 rounded-lg border border-border bg-bg p-6 shadow-card md:grid-cols-[auto_200px]">
          <div>
            <MonthCalendar month={month} today={TODAY} selected={day} available={AVAILABLE} onSelect={setDay} onMonthChange={setMonth} />
            <div className="mt-4 flex max-w-sm flex-col gap-2">
              <label htmlFor="tz" className="text-sm font-semibold">Time zone</label>
              <TimezoneSelect id="tz" value={tz} onChange={setTz} />
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!h12} onChange={(e) => setH12(!e.target.checked)} className="size-4 accent-accent" /> 24-hour time</label>
            </div>
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold">Wednesday, November 4</p>
            <SlotList slots={SLOTS} timeZone={tz} hour12={h12} selected={slot} onSelect={setSlot} />
          </div>
        </div>
      </Section>

      <Section title="Tabs">
        <Tabs defaultValue="upcoming">
          <TabsList><TabsTrigger value="upcoming">Upcoming</TabsTrigger><TabsTrigger value="past">Past</TabsTrigger></TabsList>
          <TabsContent value="upcoming" className="pt-4 text-sm text-text-muted">2 meetings this week.</TabsContent>
          <TabsContent value="past" className="pt-4 text-sm text-text-muted">No past meetings.</TabsContent>
        </Tabs>
      </Section>

      <Section title="Dialog">
        <Dialog>
          <DialogTrigger asChild><Button variant="secondary">Cancel this meeting</Button></DialogTrigger>
          <DialogContent title="Cancel this meeting?" description="Both of you get an email and the calendar event is removed.">
            <Field label="Reason (optional)"><Textarea /></Field>
            <div className="mt-4 flex justify-end gap-2">
              <DialogClose asChild><Button variant="ghost">Keep it</Button></DialogClose>
              <DialogClose asChild><Button variant="danger">Cancel meeting</Button></DialogClose>
            </div>
          </DialogContent>
        </Dialog>
      </Section>

      <Section title="Empty state">
        <EmptyState level={3} title="No event types yet" body="Create one to get a link guests can book from." action={<Button>New event type</Button>} />
      </Section>
    </main>
  );
}
