import { DeleteAccountForm, ProfileForm, SessionControls } from "@/components/host/settings-forms";
import { requireUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await requireUser();
  return (
    <div className="grid gap-10">
      <h1 className="text-xl">Settings</h1>
      <section aria-labelledby="profile" className="grid gap-4"><h2 id="profile" className="text-lg">Profile</h2><ProfileForm user={user} /></section>
      <section aria-labelledby="sessions" className="grid gap-4"><h2 id="sessions" className="text-lg">Sign out</h2><p className="text-sm text-text-muted">Signed in as {user.email}.</p><SessionControls /></section>
      <section aria-labelledby="danger" className="grid gap-4 border-t border-border pt-8"><h2 id="danger" className="text-lg text-danger">Delete account</h2><DeleteAccountForm email={user.email} /></section>
    </div>
  );
}
