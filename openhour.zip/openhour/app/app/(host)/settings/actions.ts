"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser, endAllSessions, endSession } from "@/lib/auth/session";
import { revokeAllConnections } from "@/lib/calendar/connections";
import { deleteUser, updateUser, ValidationError } from "@/lib/data";
import { cleanLine, cleanText } from "@/lib/validate";

export interface SettingsState {
  errors: Record<string, string>;
  saved?: boolean;
}

export async function saveProfileAction(_prev: SettingsState, fd: FormData): Promise<SettingsState> {
  const user = await requireUser();
  const name = cleanLine(String(fd.get("name") ?? ""));
  const slug = String(fd.get("slug") ?? "").trim().toLowerCase();
  const timeZone = String(fd.get("timeZone") ?? "");
  const welcome = cleanText(String(fd.get("welcomeMessage") ?? "")).trim();
  const errors: Record<string, string> = {};
  if (!name || name.length > 120) errors.name = "Enter your name (up to 120 characters).";
  try { new Intl.DateTimeFormat("en", { timeZone }); } catch { errors.timeZone = "Pick a time zone from the list."; }
  if (welcome.length > 500) errors.welcomeMessage = "Keep the welcome message under 500 characters.";
  if (Object.keys(errors).length) return { errors };
  try {
    await updateUser(user.id, { name, slug, timeZone, welcomeMessage: welcome || null });
  } catch (e) {
    if (e instanceof ValidationError) return { errors: e.errors };
    throw e;
  }
  revalidatePath("/", "layout");
  return { errors: {}, saved: true };
}

export async function signOutAction() {
  await endSession();
  redirect("/login");
}

export async function signOutEverywhereAction() {
  const user = await requireUser();
  await endAllSessions(user.id);
  redirect("/login");
}

export async function deleteAccountAction(_prev: SettingsState, fd: FormData): Promise<SettingsState> {
  const user = await requireUser();
  if (String(fd.get("confirm") ?? "").trim().toLowerCase() !== user.email.toLowerCase()) {
    return { errors: { confirm: "Type your email address exactly to confirm." } };
  }
  await revokeAllConnections(user.id);
  await deleteUser(user.id);
  await endAllSessions(user.id);
  redirect("/login?error=deleted");
}
