import { AvailabilityForm } from "@/components/host/availability-form";
import { listSchedules } from "@/lib/data";
import { requireUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function AvailabilityPage() {
  const user = await requireUser();
  const schedule = (await listSchedules(user.id)).find((s) => s.isDefault)!;
  return (
    <div>
      <h1 className="mb-6 text-xl">Availability</h1>
      <AvailabilityForm key={schedule.id} schedule={schedule} />
    </div>
  );
}
