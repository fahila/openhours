"use server";

import { revalidatePath } from "next/cache";
import { saveSchedule, ValidationError } from "@/lib/data";
import { schedulePayload } from "@/lib/schemas";
import { requireUser } from "@/lib/auth/session";

export interface AvailabilityState {
  errors: Record<string, string>;
  saved?: boolean;
}

export async function saveAvailabilityAction(id: string, _prev: AvailabilityState, fd: FormData): Promise<AvailabilityState> {
  const user = await requireUser();
  let raw: unknown;
  try {
    raw = JSON.parse(String(fd.get("payload")));
  } catch {
    return { errors: { _: "Something went wrong reading the form. Reload and try again." } };
  }
  const parsed = schedulePayload.safeParse(raw);
  if (!parsed.success) return { errors: { _: "Some times look wrong. Use the time pickers and try again." } };
  const payload = parsed.data;
  try {
    await saveSchedule(user.id, id, { name: payload.name.trim(), timeZone: payload.timeZone, rules: payload.rules, overrides: payload.overrides });
  } catch (e) {
    if (e instanceof ValidationError) return { errors: e.errors };
    throw e;
  }
  revalidatePath("/availability");
  return { errors: {}, saved: true };
}
