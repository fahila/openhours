import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S15" title="Routing forms" note="Routing forms are a could-have and not planned for the first release." />;
}
