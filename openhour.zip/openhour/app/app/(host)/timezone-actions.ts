"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth/session";
import { listSchedules, saveSchedule, updateUser } from "@/lib/data";

/** Move the profile and the default hours to one zone together, so "9 to 5" means 9 to 5 where the host lives. */
export async function adoptTimeZoneAction(timeZone: string): Promise<{ error?: string }> {
  const user = await requireUser();
  try { new Intl.DateTimeFormat("en", { timeZone }); } catch { return { error: "Unknown time zone." }; }
  await updateUser(user.id, { timeZone });
  const def = (await listSchedules(user.id)).find((s) => s.isDefault);
  if (def) await saveSchedule(user.id, def.id, { name: def.name, timeZone, rules: def.rules, overrides: def.overrides });
  revalidatePath("/", "layout");
  return {};
}
