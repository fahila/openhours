import type { ReactNode } from "react";
import Link from "next/link";
import { CalendarCheck } from "lucide-react";
import { HostNav } from "@/components/host/nav";
import { BRAND } from "@/lib/brand";
import { TimezonePrompt } from "@/components/host/timezone-prompt";
import { requireUser } from "@/lib/auth/session";

export const metadata = { robots: { index: false, follow: false } };

export default async function HostLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  return (
    <div className="min-h-screen md:grid md:grid-cols-[240px_1fr]">
      <aside className="border-b border-border bg-surface p-3 md:border-b-0 md:border-r md:p-4">
        <div className="mb-3 flex items-center justify-between md:mb-6">
          <Link href="/event-types" className="flex items-center gap-2 text-lg font-bold">
            <CalendarCheck aria-hidden className="size-5 text-accent" /> {BRAND.name}
          </Link>
        </div>
        <HostNav />
        <div className="mt-6 hidden text-sm md:block">
          <p className="break-words font-semibold">{user.name}</p>
          <Link href={`/${user.slug}`} className="text-accent underline">Your booking page</Link>
        </div>
      </aside>
      <main className="min-w-0 px-4 py-6 md:px-8 md:py-8">
        <div className="mx-auto max-w-[1120px]">
          <TimezonePrompt accountZone={user.timeZone} />
          {children}
        </div>
      </main>
    </div>
  );
}
