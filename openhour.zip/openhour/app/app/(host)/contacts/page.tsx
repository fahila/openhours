import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S16" title="Contacts" note="Contacts are a could-have and not planned for the first release." />;
}
