import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S18" title="Team admin" note="Team management is out of scope while this is a single-host tool." />;
}
