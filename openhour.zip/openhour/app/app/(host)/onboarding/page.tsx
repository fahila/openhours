import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S02" title="Connect your calendar" note="Calendar connection needs Google sign-in, which arrives with the backend." />;
}
