"use server";

import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { runDueJobs } from "@/lib/jobs/run";
import { cancelBookingAsHost } from "@/lib/data";
import { requireUser } from "@/lib/auth/session";
import { hostCancel } from "@/lib/schemas";

export async function cancelMeetingAction(bookingId: string, reason: string) {
  const user = await requireUser();
  const input = hostCancel.parse({ bookingId, reason });
  await cancelBookingAsHost(user.id, input.bookingId, input.reason || null);
  revalidatePath("/meetings");
  after(() => runDueJobs().catch(() => {}));
}
