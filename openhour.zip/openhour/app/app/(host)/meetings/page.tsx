import { DateTime } from "luxon";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CancelMeeting } from "@/components/host/cancel-meeting";
import { listBookings } from "@/lib/data";
import { requireUser } from "@/lib/auth/session";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

type Row = Awaited<ReturnType<typeof listBookings>>[number];

function MeetingList({ rows, zone, upcoming }: { rows: Row[]; zone: string; upcoming: boolean }) {
  if (rows.length === 0) {
    return (
      <EmptyState
        title={upcoming ? "Nothing booked yet" : "No past meetings"}
        body={upcoming ? "When someone books one of your event types it shows up here." : "Finished and cancelled meetings are listed here."}
      />
    );
  }
  return (
    <ul className="divide-y divide-border rounded-lg border border-border">
      {rows.map((b) => {
        const start = DateTime.fromISO(b.startAt, { zone });
        const end = DateTime.fromISO(b.endAt, { zone });
        const who = b.invitees.map((i) => i.name).join(", ");
        return (
          <li key={b.id} className="grid gap-2 p-4 sm:grid-cols-[200px_1fr_auto] sm:items-center">
            <div>
              <p className="font-semibold">{start.toFormat("ccc, LLL d")}</p>
              <p className="text-sm text-text-muted">{start.toFormat("h:mm a")} to {end.toFormat("h:mm a")}</p>
            </div>
            <div className="min-w-0">
              <p className="break-words font-semibold">{who}</p>
              <p className="break-words text-sm text-text-muted">{b.eventType?.name ?? "Deleted event type"}{b.invitees.length === 1 ? ` · ${b.invitees[0].email}` : ` · ${b.invitees.length} guests`}</p>
              {b.invitees.filter((i) => i.answers.notes).map((i) => (
                <p key={i.id} className="mt-1 whitespace-pre-line break-words rounded-md bg-surface px-2 py-1 text-sm">
                  <span className="font-semibold">{b.invitees.length > 1 ? `${i.name}: ` : "Note: "}</span>{i.answers.notes}
                </p>
              ))}
              {b.status === "cancelled" && b.cancelReason && <p className="break-words text-sm text-text-muted">Reason: {b.cancelReason}</p>}
            </div>
            <div className="flex items-center gap-2">
              {b.payment?.status === "paid" && <Badge tone="success">Paid {money(b.payment.amountCents, b.payment.currency)}</Badge>}
              {b.payment?.status === "refunded" && <Badge>Refunded {money(b.payment.amountCents, b.payment.currency)}</Badge>}
              {b.status === "pending_payment" && <Badge tone="warning">Waiting for payment</Badge>}
              {b.status === "cancelled" ? <Badge tone="danger">Cancelled</Badge> : upcoming ? <CancelMeeting id={b.id} label={who} /> : <Badge>Done</Badge>}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

export default async function MeetingsPage() {
  const user = await requireUser();
  const [upcoming, past] = await Promise.all([listBookings(user.id, "upcoming"), listBookings(user.id, "past")]);
  return (
    <div>
      <h1 className="text-xl">Meetings</h1>
      <p className="mt-1 text-sm text-text-muted">Times are shown in {user.timeZone.replaceAll("_", " ")}.</p>
      <Tabs defaultValue="upcoming" className="mt-6">
        <TabsList>
          <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
          <TabsTrigger value="past">Past and cancelled ({past.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming" className="pt-4"><MeetingList rows={upcoming} zone={user.timeZone} upcoming /></TabsContent>
        <TabsContent value="past" className="pt-4"><MeetingList rows={past} zone={user.timeZone} upcoming={false} /></TabsContent>
      </Tabs>
    </div>
  );
}
