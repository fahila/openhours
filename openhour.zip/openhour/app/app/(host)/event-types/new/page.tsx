import { EventTypeForm } from "@/components/host/event-type-form";
import { listSchedules } from "@/lib/data";
import { requireUser } from "@/lib/auth/session";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export default async function NewEventTypePage() {
  const user = await requireUser();
  return (
    <div>
      <h1 className="mb-6 text-xl">New event type</h1>
      <EventTypeForm paymentsEnabled={env().stripeEnabled} eventType={null} schedules={await listSchedules(user.id)} />
    </div>
  );
}
