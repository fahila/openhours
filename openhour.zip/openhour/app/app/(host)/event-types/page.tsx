import Link from "next/link";
import { Pencil, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { EventTypeCard } from "@/components/ui/event-type-card";
import { ActiveSwitch, CopyLinkButton } from "@/components/host/event-type-actions";
import { listEventTypes } from "@/lib/data";
import { LOCATION_LABELS } from "@/lib/types";
import { requireUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function EventTypesPage() {
  const user = await requireUser();
  const types = await listEventTypes(user.id);
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl">Event types</h1>
          <p className="mt-1 text-sm text-text-muted">Each one gets its own booking link.</p>
        </div>
        <Link href="/event-types/new">
          <Button><Plus aria-hidden className="size-4" /> New event type</Button>
        </Link>
      </div>

      <div className="mt-6">
        {types.length === 0 ? (
          <EmptyState
            title="No event types yet"
            body="Create one to get a link people can book from."
            action={<Link href="/event-types/new"><Button>New event type</Button></Link>}
          />
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {types.map((t) => (
              <li key={t.id}>
                <EventTypeCard
                  name={t.name}
                  durationMin={t.durationMin}
                  location={t.locationValue && t.locationType === "in_person" ? t.locationValue : LOCATION_LABELS[t.locationType]}
                  colorIndex={t.colorIndex}
                  kind={t.kind}
                  headingLevel={2}
                  active={t.active}
                  actions={
                    <>
                      <CopyLinkButton path={`/${user.slug}/${t.slug}`} />
                      <Link href={`/event-types/${t.id}`}>
                        <Button size="sm" variant="ghost"><Pencil aria-hidden className="size-4" /> Edit<span className="sr-only"> {t.name}</span></Button>
                      </Link>
                      <span className="ml-auto"><ActiveSwitch id={t.id} name={t.name} active={t.active} /></span>
                    </>
                  }
                />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
