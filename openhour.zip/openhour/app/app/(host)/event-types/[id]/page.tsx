import { notFound } from "next/navigation";
import { EventTypeForm } from "@/components/host/event-type-form";
import { getEventType, listSchedules } from "@/lib/data";
import { requireUser } from "@/lib/auth/session";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export default async function EditEventTypePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser();
  const et = await getEventType(user.id, id);
  if (!et) notFound();
  return (
    <div>
      <h1 className="mb-6 break-words text-xl">Edit: {et.name}</h1>
      <EventTypeForm paymentsEnabled={env().stripeEnabled} eventType={et} schedules={await listSchedules(user.id)} />
    </div>
  );
}
