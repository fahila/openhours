"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { deleteEventType, listEventTypes, saveEventType, setEventTypeActive, ValidationError } from "@/lib/data";
import { parseEventType, pickFreeSlug, type Errors } from "@/lib/validate";
import { requireUser } from "@/lib/auth/session";

export interface FormState {
  errors: Errors;
  values?: Record<string, string>;
}

export async function saveEventTypeAction(id: string | null, _prev: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const values = Object.fromEntries([...fd.entries()].filter(([, v]) => typeof v === "string")) as Record<string, string>;
  const { value, errors } = parseEventType(fd);
  if (!value) return { errors, values };
  // The host left the link name empty, so we choose it: add -2, -3 ... instead of reporting a clash they never typed.
  if (!String(fd.get("slug") ?? "").trim()) {
    const taken = new Set((await listEventTypes(user.id)).filter((e) => e.id !== id).map((e) => e.slug));
    value.slug = pickFreeSlug(value.slug, taken);
  }
  try {
    await saveEventType(user.id, id, value);
  } catch (e) {
    if (e instanceof ValidationError) return { errors: e.errors, values };
    throw e;
  }
  revalidatePath("/event-types");
  redirect("/event-types");
}

export async function toggleActiveAction(id: string, active: boolean) {
  const user = await requireUser();
  await setEventTypeActive(user.id, id, active);
  revalidatePath("/event-types");
}

export async function deleteEventTypeAction(id: string): Promise<FormState> {
  const user = await requireUser();
  try {
    await deleteEventType(user.id, id);
  } catch (e) {
    if (e instanceof ValidationError) return { errors: e.errors };
    throw e;
  }
  revalidatePath("/event-types");
  redirect("/event-types");
}
