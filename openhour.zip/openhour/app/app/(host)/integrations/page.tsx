import { CalendarConnection } from "@/components/host/calendar-settings";
import { Button } from "@/components/ui/button";
import { requireUser } from "@/lib/auth/session";
import { listConnections } from "@/lib/calendar/connections";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

const NOTICES: Record<string, { tone: "ok" | "bad"; text: string }> = {
  connected: { tone: "ok", text: "Calendar connected. Pick which calendars block time and which one receives bookings." },
  failed: { tone: "bad", text: "We couldn't finish connecting. Please try again." },
  missing_scopes: { tone: "bad", text: "Google needs all three calendar permissions ticked on the consent screen. Try again and leave them all on." },
  not_configured: { tone: "bad", text: "Google isn't set up on this server yet. Add the Google keys first." },
};

export default async function IntegrationsPage({ searchParams }: { searchParams: Promise<{ calendar?: string }> }) {
  const user = await requireUser();
  const { calendar } = await searchParams;
  const conns = await listConnections(user.id);
  const notice = calendar ? NOTICES[calendar] : null;
  const e = env();
  return (
    <div className="grid max-w-3xl gap-6">
      <div>
        <h1 className="text-xl">Integrations</h1>
        <p className="mt-1 text-sm text-text-muted">Connect a calendar so guests only see times you're actually free, and new bookings land on it.</p>
      </div>
      {notice && (
        <p role={notice.tone === "ok" ? "status" : "alert"} className={`rounded-md border p-3 text-sm ${notice.tone === "ok" ? "border-success bg-success-subtle text-success" : "border-danger bg-danger-subtle text-danger"}`}>{notice.text}</p>
      )}
      <section aria-labelledby="cals" className="grid gap-4">
        <h2 id="cals" className="text-lg">Calendars</h2>
        {conns.length === 0 && <p className="rounded-md border border-dashed border-border-input bg-surface p-4 text-sm text-text-muted">No calendar connected. Until you connect one, guests see all your open hours without checking for clashes.</p>}
        {conns.map((c) => <CalendarConnection key={c.id} conn={c} />)}
        <div>
          {e.googleEnabled
            ? <a href="/api/calendars/connect/google"><Button variant={conns.length ? "secondary" : "primary"}>{conns.length ? "Connect another Google account" : "Connect Google Calendar"}</Button></a>
            : <p className="text-sm text-text-muted">Google keys aren't set on this server, so calendars can't be connected yet.</p>}
        </div>
      </section>
      <section aria-labelledby="pay" className="grid gap-2">
        <h2 id="pay" className="text-lg">Payments</h2>
        <p className="text-sm text-text-muted">{e.stripeEnabled ? "Stripe is connected. Turn on payment for an event type in its settings." : "Stripe isn't configured on this server. Add the Stripe keys to take payment at booking."}</p>
      </section>
    </div>
  );
}
