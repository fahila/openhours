"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth/session";
import { calendarFlags, uuid } from "@/lib/schemas";
import { disconnect, setCalendarFlags, syncCalendarList } from "@/lib/calendar/connections";

export async function setCalendarFlagsAction(calendarId: string, flags: { checkConflicts?: boolean; isBookingTarget?: boolean }) {
  const user = await requireUser();
  const input = calendarFlags.parse({ id: calendarId, ...flags });
  await setCalendarFlags(user.id, input.id, { checkConflicts: input.checkConflicts, isBookingTarget: input.isBookingTarget });
  revalidatePath("/integrations");
}

export async function disconnectAction(connectionId: string) {
  const user = await requireUser();
  await disconnect(user.id, uuid.parse(connectionId));
  revalidatePath("/integrations");
}

export async function refreshCalendarsAction(connectionId: string): Promise<{ error?: string }> {
  const user = await requireUser();
  try {
    await syncCalendarList(user.id, connectionId);
  } catch {
    return { error: "We couldn't reach Google. Try again in a moment." };
  }
  revalidatePath("/integrations");
  return {};
}
