import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S13" title="Workflows" note="Reminders and follow-ups need email sending, which arrives with the backend." />;
}
