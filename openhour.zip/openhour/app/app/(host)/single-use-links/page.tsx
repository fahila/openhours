import { StubPage } from "@/components/stub-page";

export default function Page() {
  return <StubPage id="S07" title="One-time links" note="Single-use and one-off links come with the should-have milestone." />;
}
