# Pricing: not applicable for own use, no evidence for a public price

## Short version

Nothing is being sold, so there is no price to set. This file records what is missing so a price can be set later without guessing.

## The original's public pricing

**Not read.** The original's pricing page and every review source were blocked by this sandbox's network policy (`recon.md` lists the pricing page as "not opened"). Tier names and prices turned up in third-party summaries during recon, and those sources disagree with each other. Third-party summaries are not a citable price, so no table is given. A pricing comparison needs: the original's pricing page URL and the date it was read, plus two or three alternatives, each with URL and date. Prices change, so the date is part of the data.

## What reviewers said about price and billing

0 reviews collected, so nothing to count. (`fixes.md` explains the block.)

## Model, if it is ever sold

Not decided. Options to weigh once the evidence exists: a free plan for one calendar and a paid plan, flat or per seat, monthly with annual at about two months free; at most three tiers named for who they are for.

Billing complaints the skill asks to fix in the product, and where the app stands:

| complaint to avoid | this app today |
| --- | --- |
| hard to cancel | no subscription exists to cancel |
| surprise per-seat jumps | no seats or plans exist |
| unclear renewal emails | no renewals exist |

These are not wins over the original, only absence of the feature. They become real requirements the moment subscriptions are added.

## Stripe

Stripe is in the app only for guests paying the host at booking (Checkout, test mode, signed webhooks, 35-minute hold, refund on late payment). The owner sets a price per event type in the app; no Stripe products or prices need to exist for that. If subscriptions are ever added, the owner creates the Stripe products and prices; this session never creates accounts or handles live keys.
