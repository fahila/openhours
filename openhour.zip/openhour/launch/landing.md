# Landing page: draft, not built

**Not built on purpose.** The skill builds the landing page on the positioning angle in `fixes.md`. That file has no angle: the entrepreneur step found 0 reviews because every review source was blocked, so there are no "hate" themes to put in a problem section and no fixes to lead the feature list with. The scope you chose is also "own business use, not for sale". For that, the useful public pages already exist: each host's booking page, the privacy page, and the sign-in page. `/` redirects to the signed-in dashboard.

A page written now would have to invent a reason to switch. That is the thing this skill says not to do, so this file holds a skeleton to fill once there is evidence, plus the few sentences that are true today.

## Sentences that are true today

- Openhour is a booking page for one owner's calendar. Guests see only times the owner is free, pick one, and it lands in the owner's Google Calendar with a Meet link.
- It checks the owner's calendar live, applies buffers, daily and weekly limits, notice and date overrides, and handles daylight saving per guest.
- Guests can book, reschedule and cancel from links in their email; the owner can take payment at booking through Stripe Checkout.
- It runs on the owner's own database and keys. Details are used only to arrange the meeting (`/privacy`).

Not claimable yet: anything about real Google, Resend or Stripe behaviour (mock-verified only, see `manual-checklist.md`), Zoom links, embeds, polls, routing forms, team scheduling.

## Skeleton, per the skill

| section | content | blocked on |
| --- | --- | --- |
| Hero | the angle as a headline, one line, one button, a real screenshot | the angle (`fixes.md`) |
| The problem | top two hate themes, paraphrased, no reviewer quotes | reviews |
| How it works | 1 set your hours, 2 share your link, 3 guests pick a time and it appears in your calendar | none: can be written now |
| Features | lead with the fixes from `fixes.md`, parity second | the fix plan |
| Pricing | the table in `pricing.md` | a decision to sell |
| FAQ | real objections; "can I import from other tools?" only if an importer exists (none does) | evidence of real objections |
| Final call to action | one button | the hero |

Proof section: stays empty. No testimonials, counts, ratings or logos exist, and none will be invented.

## When to build it

After `/replica-entrepreneur` has run on real reviews (100+, 3+ sources) and `fixes.md` has a recommended angle. Then build it in the app (public route, noindex off) in the brand voice from `brand.md` and run the contrast check on it.
