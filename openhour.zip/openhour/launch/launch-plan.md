# Launch plan: private use, small

Scope is the owner's own business, so this is a checklist for going live for yourself, not a public launch. Public-launch items are listed at the end as parked.

## Before the first real booking

1. Do the real-service run in `manual-checklist.md`: Google OAuth and Calendar, Resend, Stripe test mode. Until it passes, those paths are verified only against a local mock.
2. `/replica-deploy` for hosting, production database, env vars and DNS (the owner creates the accounts and puts keys in the host's settings).
3. Turn on error tracking and basic uptime monitoring (the owner picks and signs up for the tool).
4. Check the privacy page names every processor actually used (host, database, Resend, Stripe, Google).
5. Book yourself from a second email address, reschedule it, cancel it, and read each email as the guest would.

## First users

Your first real guests are your own clients. Ask the first ten, by hand, how booking felt: where they hesitated, whether the time zone was right, whether the email made sense. Write the answers down; they are real evidence for later.

## Parked: only if you decide to sell

These need evidence that does not exist yet.

- A waitlist and a beta list, with analytics.
- Where the original's unhappy users talk: unknown until the review research runs (the Reddit and community threads come from it).
- A Product Hunt or Hacker News post that leads with a fix: there is no fix list yet.
- App Store and Google Play: web only, so no listing. `listing.json` is a placeholder that passes `listing.py` (0 errors, 3 warnings for empty optional fields, original's name absent) and should not be submitted anywhere.
